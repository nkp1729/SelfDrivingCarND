
## Vehicle Detection and Tracking
### Neilkunal Panchal
Vehicle Detection Project

The goals / steps of this project are the following:

- Perform a Histogram of Oriented Gradients (HOG) feature extraction on a labeled training set of images and train a classifier Linear SVM classifier
- Optionally, you can also apply a color transform and append binned color features, as well as histograms of color, to your HOG feature vector. 
- Note: for those first two steps don't forget to normalize your features and randomize a selection for training and testing.
- Implement a sliding-window technique and use your trained classifier to search for vehicles in images.
- Run your pipeline on a video stream (start with the test_video.mp4 and later implement on full project_video.mp4) and create a heat map of recurring detections frame by frame to reject outliers and follow detected vehicles.
- Estimate a bounding box for vehicles detected.

Rubric Points

Here I will consider the rubric points individually and describe how I addressed each point in my implementation.

---

Writeup / README

1. Provide a Writeup / README that includes all the rubric points and how you addressed each one.  You can submit your writeup as markdown or pdf.  Here is a template writeup for this project you can use as a guide and a starting point.

You're reading it!






```python
import matplotlib.pyplot as plt
import cv2
import numpy as np
import matplotlib.image as mpimg
from scipy.ndimage.measurements import label
from moviepy.editor import VideoFileClip
from random import shuffle
from IPython.display import HTML
import glob
from sklearn.model_selection import GridSearchCV

#from skimage.feature import hog
#from skimage import color, exposure
# images are divided up into vehicles and non-vehicles
%matplotlib inline
```

# Load Images
Firstly the images are loaded in. These are then split into car and non-car images.
Examples of the car and non car images are shown below


```python


images = glob.glob('/home/neilkunal/Desktop/vehicles/*/*/*/*.jpeg')
imagesv = glob.glob('/home/neilkunal/Desktop/vehicles/non-vehicles_smallset/*/*/*.jpeg')
imagesNonV = glob.glob('/home/neilkunal/Desktop/vehicles/vehicles_smallset/*/*/*.jpeg')
shuffle(imagesv)
shuffle(imagesNonV)
cars = []
notcars = []

for image in imagesv:
    notcars.append(image)
for image in imagesNonV:
    cars.append(image)
        
# Define a function to return some characteristics of the dataset 
def data_look(car_list, notcar_list):
    data_dict = {}
    # Define a key in data_dict "n_cars" and store the number of car images
    data_dict["n_cars"] = len(car_list)
    # Define a key "n_notcars" and store the number of notcar images
    data_dict["n_notcars"] = len(notcar_list)
    # Read in a test image, either car or notcar
    example_img = mpimg.imread(car_list[0])
    # Define a key "image_shape" and store the test image shape 3-tuple
    data_dict["image_shape"] = example_img.shape
    # Define a key "data_type" and store the data type of the test image.
    data_dict["data_type"] = example_img.dtype
    # Return data_dict
    return data_dict
    
data_info = data_look(cars, notcars)

print('Your function returned a count of', 
      data_info["n_cars"], ' cars and', 
      data_info["n_notcars"], ' non-cars')
print('of size: ',data_info["image_shape"], ' and data type:', 
      data_info["data_type"])
# Just for fun choose random car / not-car indices and plot example images   
car_ind = np.random.randint(0, len(cars))
notcar_ind = np.random.randint(0, len(notcars))
    
# Read in car / not-car images
car_image = mpimg.imread(cars[car_ind])
notcar_image = mpimg.imread(notcars[notcar_ind])


# Plot the examples
fig = plt.figure()
plt.subplot(121)
plt.imshow(car_image)
plt.title('Example Car Image')
plt.subplot(122)
plt.imshow(notcar_image)
plt.title('Example Not-car Image')
plt.show()

```

    Your function returned a count of 1196  cars and 1125  non-cars
    of size:  (64, 64, 3)  and data type: uint8



![png](output_3_1.png)


# Histogram of Oriented Gradients (HOG)

## 1. Explain how (and identify where in your code) you extracted HOG features from the training images.

I  explored different color spaces and different skimage.hog() parameters (orientations, pixels_per_cell, and cells_per_block).  I grabbed random images from each of the two classes and displayed them to get a feel for what the skimage.hog() output looks like.

Here is an example using the YCrCb color space and HOG parameters of orientations=9, pixels_per_cell=(8, 8) and cells_per_block=(2, 2):




```python
from skimage.feature import hog
def get_hog_features(img, orient, pix_per_cell, cell_per_block, vis=False, feature_vec=True):
    if vis == True:
        features, hog_image = hog(img, orientations=orient, pixels_per_cell=(pix_per_cell, pix_per_cell),
                                  cells_per_block=(cell_per_block, cell_per_block), transform_sqrt=False, 
                                  visualise=True, feature_vector=False)
        return features, hog_image
    else:      
        features = hog(img, orientations=orient, pixels_per_cell=(pix_per_cell, pix_per_cell),
                       cells_per_block=(cell_per_block, cell_per_block), transform_sqrt=False, 
                       visualise=False, feature_vector=feature_vec)
        return features

ind = np.random.randint(0, len(cars))
# Read in the image
image = mpimg.imread(cars[ind])
gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
# Define HOG parameters
orient = 9
pix_per_cell = 8
cell_per_block = 2
# Call our function with vis=True to see an image output
features, hog_image = get_hog_features(gray, orient, 
                        pix_per_cell, cell_per_block, 
                        vis=True, feature_vec=False)


# Plot the examples
fig = plt.figure(figsize = (10,15))
plt.subplot(121)
plt.imshow(image, cmap='gray')
plt.title('Example Car Image')
plt.subplot(122)
plt.imshow(hog_image, cmap='gray')
plt.title('HOG Visualization')
plt.show()

```


![png](output_5_0.png)



```python
#draw_boxes uses cv2.rectangle to draw rectangles
def draw_boxes(img, bboxes, colour= (0,0,255), thickness= 5):
    for (corner1,corner2) in bboxes: 
        cv2.rectangle(img, corner1, corner2 , colour, thickness)
    return img
```


```python
template_list = plt.imread('/home/neilkunal/Documents/cutouts/cutout1.jpg') 
def find_matches(img, template_list):
    # Define an empty list to take bbox coords
    bbox_list = []
    # Define matching method
    # Other options include: cv2.TM_CCORR_NORMED', 'cv2.TM_CCOEFF', 'cv2.TM_CCORR',
    #         'cv2.TM_SQDIFF', 'cv2.TM_SQDIFF_NORMED'
    method = cv2.TM_CCOEFF_NORMED
    # Iterate through template list
    for temp in template_list:
        # Read in templates one by one
        tmp = mpimg.imread(temp)
        # Use cv2.matchTemplate() to search the image
        result = cv2.matchTemplate(img, tmp, method)
        # Use cv2.minMaxLoc() to extract the location of the best match
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
        # Determine a bounding box for the match
        w, h = (tmp.shape[1], tmp.shape[0])
        if method in [cv2.TM_SQDIFF, cv2.TM_SQDIFF_NORMED]:
            top_left = min_loc
        else:
            top_left = max_loc
        bottom_right = (top_left[0] + w, top_left[1] + h)
        # Append bbox position to list
        bbox_list.append((top_left, bottom_right))
        # Return the list of bounding boxes
        
    return bbox_list
import matplotlib.image as mpimg

image = mpimg.imread('/home/neilkunal/Documents/cutouts/bbox-example-image.jpg')
#image = mpimg.imread('temp-matching-example-2.jpg')
templist = ['/home/neilkunal/Documents/cutouts/cutout1.jpg', '/home/neilkunal/Documents/cutouts/cutout2.jpg', '/home/neilkunal/Documents/cutouts/cutout3.jpg',
            '/home/neilkunal/Documents/cutouts/cutout4.jpg', '/home/neilkunal/Documents/cutouts/cutout5.jpg', '/home/neilkunal/Documents/cutouts/cutout6.jpg']

bboxes = find_matches(image, templist)
result = draw_boxes(image, bboxes)
plt.imshow(result)
plt.show()
```


![png](output_7_0.png)



```python
import matplotlib.image as mpimg
import numpy as np

# Read in the image
image = plt.imread(templist[0])

# Take histograms in R, G, and B
rhist = np.histogram(image[:,:,0], bins=32, range=(0, 256))
ghist = np.histogram(image[:,:,1], bins=32, range=(0, 256))
bhist = np.histogram(image[:,:,2], bins=32, range=(0, 256))

bin_edges = rhist[1]
bin_centers = (bin_edges[1:]  + bin_edges[0:len(bin_edges)-1])/2
```

# Colour Histogram function
The *color_hist* function computes a histogram of the reg freen and blue channels for a given image. An example of a random image is shown below. This function is a method of fingerprinting cars from images.


```python
def color_hist(img, nbins=32, bins_range=(0, 256)):
    # Compute the histogram of the RGB channels separately
    rhist = np.histogram(img[:,:,0], bins=nbins, range=bins_range)
    ghist = np.histogram(img[:,:,1], bins=nbins, range=bins_range)
    bhist = np.histogram(img[:,:,2], bins=nbins, range=bins_range)
    # Generating bin centers
    bin_edges = rhist[1]
    bin_centers = (bin_edges[1:]  + bin_edges[0:len(bin_edges)-1])/2
    # Concatenate the histograms into a single feature vector
    hist_features = np.concatenate((rhist[0], ghist[0], bhist[0]))
    # Return the individual histograms, bin_centers and feature vector
    return rhist, ghist, bhist, bin_centers, hist_features
    
rh, gh, bh, bincen, feature_vec = color_hist(image, nbins=32, bins_range=(0, 256))

# Plot a figure with all three bar charts
if rh is not None:
    fig = plt.figure(figsize=(12,3))
    plt.subplot(131)
    plt.bar(bincen, rh[0])
    plt.xlim(0, 256)
    plt.title('R Histogram')
    plt.subplot(132)
    plt.bar(bincen, gh[0])
    plt.xlim(0, 256)
    plt.title('G Histogram')
    plt.subplot(133)
    plt.bar(bincen, bh[0])
    plt.xlim(0, 256)
    plt.title('B Histogram')
    fig.tight_layout()
    plt.show()
else:
    print('Your function is returning None for at least one variable...')
```


![png](output_10_0.png)



```python
from mpl_toolkits.mplot3d import Axes3D

def plot3d(pixels, colors_rgb,
        axis_labels=list("RGB"), axis_limits=((0, 255), (0, 255), (0, 255))):
    """Plot pixels in 3D."""

    # Create figure and 3D axes
    fig = plt.figure(figsize=(8, 8))
    ax = Axes3D(fig)

    # Set axis limits
    ax.set_xlim(*axis_limits[0])
    ax.set_ylim(*axis_limits[1])
    ax.set_zlim(*axis_limits[2])

    # Set axis labels and sizes
    ax.tick_params(axis='both', which='major', labelsize=14, pad=8)
    ax.set_xlabel(axis_labels[0], fontsize=16, labelpad=16)
    ax.set_ylabel(axis_labels[1], fontsize=16, labelpad=16)
    ax.set_zlabel(axis_labels[2], fontsize=16, labelpad=16)

    # Plot pixel values with colors given in colors_rgb
    ax.scatter(
        pixels[:, :, 0].ravel(),
        pixels[:, :, 1].ravel(),
        pixels[:, :, 2].ravel(),
        c=colors_rgb.reshape((-1, 3)), edgecolors='none')

    return ax  # return Axes3D object for further manipulation

```




```python
small_img = cv2.resize(image, (32, 32))
print(small_img.shape)
(32, 32, 3)
```

    (32, 32, 3)





    (32, 32, 3)




```python
feature_vec = small_img.ravel()
print(feature_vec.shape)
(3072,)
```

    (3072,)





    (3072,)



# Binning Spatial colour features

the *bin_spatial* function takes and image returns a feature vector. This is achieved by converting the colour space by the input *color_space* and chosing the pixel resoulution to resize. An axample of an image converted to RGB feature vector of size *3072* is shown below.


```python
def bin_spatial(img, color_space='RGB', size=(32, 32)):
    # Convert image to new color space (if specified)
    if color_space != 'RGB':
        if color_space == 'HSV':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        elif color_space == 'LUV':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2LUV)
        elif color_space == 'HLS':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2HLS)
        elif color_space == 'YUV':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2YUV)
        elif color_space == 'YCrCb':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2YCrCb)
    else: feature_image = np.copy(img)             
    # Use cv2.resize().ravel() to create the feature vector
    features = cv2.resize(feature_image, size).ravel() 
    # Return the feature vector
    return features
img = cv2.imread('/home/neilkunal/Desktop/test_img.jpg')

features = bin_spatial(img, color_space='RGB', size=(32, 32))
print(features)
```

    [52 71 86 ..., 80 73 78]



```python
img = cv2.imread('/home/neilkunal/Desktop/test_img.jpg')
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
k = 32
img = cv2.resize(img, (k,k))
plt.imshow(img)
plt.show()
print(img.shape)
```


![png](output_17_0.png)


    (32, 32, 3)



```python
feature_vec = img.ravel()
print(feature_vec.shape)

```

    (3072,)


The image below shows a histogram of orientated gradients applied to the same downsampled image.


```python

pix_per_cell = 8
cell_per_block = 8
orient = 6
#path = '/home/neilkunal/Documents/KK.jpg'
#img = plt.imread(path)
img = cv2.imread('/home/neilkunal/Desktop/test_img.jpg')
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
features, hog_image = hog(img, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
plt.imshow(hog_image)
plt.show()
```


![png](output_20_0.png)



```python

```




```python
from sklearn.preprocessing import StandardScaler

def color_hist(img, nbins=32, bins_range=(0, 256)):
    # Compute the histogram of the color channels separately
    channel1_hist = np.histogram(img[:,:,0], bins=nbins, range=bins_range)
    channel2_hist = np.histogram(img[:,:,1], bins=nbins, range=bins_range)
    channel3_hist = np.histogram(img[:,:,2], bins=nbins, range=bins_range)
    # Concatenate the histograms into a single feature vector
    hist_features = np.concatenate((channel1_hist[0], channel2_hist[0], channel3_hist[0]))
    # Return the individual histograms, bin_centers and feature vector
    return hist_features


def extract_features(imgs, cspace='RGB', spatial_size=(32, 32),
                        hist_bins=32, hist_range=(0, 256)):
    # Create a list to append feature vectors to
    features = []
    # Iterate through the list of images
    for file in imgs:
        # Read in each one by one
        image = mpimg.imread(file)
        # apply color conversion if other than 'RGB'
        if cspace != 'RGB':
            if cspace == 'HSV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
            elif cspace == 'LUV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2LUV)
            elif cspace == 'HLS':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2HLS)
            elif cspace == 'YUV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2YUV)
        else: feature_image = np.copy(image)      
        # Apply bin_spatial() to get spatial color features
        spatial_features = bin_spatial(feature_image, size=spatial_size)
        # Apply color_hist() also with a color space option now
        hist_features = color_hist(feature_image, nbins=hist_bins, bins_range=hist_range)
        # Append the new feature vector to the features list
        features.append(np.concatenate((spatial_features, hist_features)))
    # Return list of feature vectors
    return features


        
car_features = extract_features(cars, cspace='RGB', spatial_size=(32, 32),
                        hist_bins=32, hist_range=(0, 256))
notcar_features = extract_features(notcars, cspace='RGB', spatial_size=(32, 32),
                        hist_bins=32, hist_range=(0, 256))

if len(car_features) > 0:
    # Create an array stack of feature vectors
    X = np.vstack((car_features, notcar_features)).astype(np.float64)                        
    # Fit a per-column scaler
    X_scaler = StandardScaler().fit(X)
    # Apply the scaler to X
    scaled_X = X_scaler.transform(X)
    car_ind = np.random.randint(0, len(cars))
    # Plot an example of raw and scaled features
    fig = plt.figure(figsize=(12,4))
    plt.subplot(131)
    plt.imshow(mpimg.imread(cars[car_ind]))
    plt.title('Original Image')
    plt.subplot(132)
    plt.plot(X[car_ind])
    plt.title('Raw Features')
    plt.subplot(133)
    plt.plot(scaled_X[car_ind])
    plt.title('Normalized Features')
    fig.tight_layout()
    plt.show()
else: 
    print('Your function only returns empty feature vectors...')
```


![png](output_23_0.png)


# Support Vector Classifier

After extracting features. A support vector machine classifier is trained and tested in the car and non car images. 



```python
import time
from sklearn.svm import LinearSVC, SVC
from sklearn.preprocessing import StandardScaler
# NOTE: the next import is only valid 
# for scikit-learn version <= 0.17
# if you are using scikit-learn >= 0.18 then use this:
# from sklearn.model_selection import train_test_split
from sklearn.cross_validation import train_test_split



# performs under different binning scenarios
spatial = 6
histbin = 64

car_features = extract_features(cars, cspace='RGB', spatial_size=(spatial, spatial),
                        hist_bins=histbin, hist_range=(0, 256))
notcar_features = extract_features(notcars, cspace='RGB', spatial_size=(spatial, spatial),
                        hist_bins=histbin, hist_range=(0, 256))

# Create an array stack of feature vectors
X = np.vstack((car_features, notcar_features)).astype(np.float64)                        
# Fit a per-column scaler
X_scaler = StandardScaler().fit(X)
# Apply the scaler to X
scaled_X = X_scaler.transform(X)

# Define the labels vector
y = np.hstack((np.ones(len(car_features)), np.zeros(len(notcar_features))))


# Split up data into randomized training and test sets
rand_state = np.random.randint(0, 100)
X_train, X_test, y_train, y_test = train_test_split(
    scaled_X, y, test_size=0.2, random_state=rand_state)

print('Using spatial binning of:',spatial,
    'and', histbin,'histogram bins')
print('Feature vector length:', len(X_train[0]))
# Use a linear SVC 
svc = SVC()
parameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
clf = GridSearchCV(svc, parameters)
# Check the training time for the SVC
t=time.time()
clf.fit(X_train, y_train)
t2 = time.time()
print(round(t2-t, 2), 'Seconds to train SVC...')
# Check the score of the SVC
print('Test Accuracy of SVC = ', round(clf.score(X_test, y_test), 4))
# Check the prediction time for a single sample
t=time.time()
n_predict = 10
print('My SVC predicts: ', clf.predict(X_test[0:n_predict]))
print('For these',n_predict, 'labels: ', y_test[0:n_predict])
t2 = time.time()
print(round(t2-t, 5), 'Seconds to predict', n_predict,'labels with SVC')
```

    Using spatial binning of: 6 and 64 histogram bins
    Feature vector length: 300
    3.15 Seconds to train SVC...
    Test Accuracy of SVC =  0.9935
    My SVC predicts:  [ 0.  1.  1.  0.  0.  0.  1.  1.  1.  1.]
    For these 10 labels:  [ 0.  1.  1.  0.  0.  0.  1.  1.  1.  1.]
    0.00218 Seconds to predict 10 labels with SVC


# Describe how (and identify where in your code) you trained a classifier using your selected HOG features (and color features if you used them).
Here the *get_hog_features* function is called to generate a histogram of gradients from the input image. Subsequently this function is then used with the *extract_features* function to generate features from a combination of spatial binning and histogram of gradients. This is then used to classify cars and non cars using a support vector classfier.


```python

from skimage.feature import hog
# NOTE: the next import is only valid for scikit-learn version <= 0.17
# for scikit-learn >= 0.18 use:
# from sklearn.model_selection import train_test_split
from sklearn.cross_validation import train_test_split

# Define a function to return HOG features and visualization
def get_hog_features(img, orient, pix_per_cell, cell_per_block, 
                        vis=False, feature_vec=True):
    # Call with two outputs if vis==True
    if vis == True:
        features, hog_image = hog(img, orientations=orient, pixels_per_cell=(pix_per_cell, pix_per_cell),
                                  cells_per_block=(cell_per_block, cell_per_block), transform_sqrt=True, 
                                  visualise=vis, feature_vector=feature_vec)
        return features, hog_image
    # Otherwise call with one output
    else:      
        features = hog(img, orientations=orient, pixels_per_cell=(pix_per_cell, pix_per_cell),
                       cells_per_block=(cell_per_block, cell_per_block), transform_sqrt=True, 
                       visualise=vis, feature_vector=feature_vec)
        return features

# Define a function to extract features from a list of images
# Have this function call bin_spatial() and color_hist()
def extract_features(imgs, cspace='RGB', orient=9, 
                        pix_per_cell=8, cell_per_block=2, hog_channel=0):
    # Create a list to append feature vectors to
    features = []
    # Iterate through the list of images
    for file in imgs:
        # Read in each one by one
        image = mpimg.imread(file)
        # apply color conversion if other than 'RGB'
        if cspace != 'RGB':
            if cspace == 'HSV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
            elif cspace == 'LUV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2LUV)
            elif cspace == 'HLS':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2HLS)
            elif cspace == 'YUV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2YUV)
            elif cspace == 'YCrCb':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2YCrCb)
        else: feature_image = np.copy(image)      

        # Call get_hog_features() with vis=False, feature_vec=True
        if hog_channel == 'ALL':
            hog_features = []
            for channel in range(feature_image.shape[2]):
                hog_features.append(get_hog_features(feature_image[:,:,channel], 
                                    orient, pix_per_cell, cell_per_block, 
                                    vis=False, feature_vec=True))
            hog_features = np.ravel(hog_features)        
        else:
            hog_features = get_hog_features(feature_image[:,:,hog_channel], orient, 
                        pix_per_cell, cell_per_block, vis=False, feature_vec=True)
        # Append the new feature vector to the features list
        features.append(hog_features)
    # Return list of feature vectors
    return features



# Reduce the sample size because HOG features are slow to compute
# The quiz evaluator times out after 13s of CPU time
sample_size = 500
cars = cars[0:sample_size]
notcars = notcars[0:sample_size]

### TODO: Tweak these parameters and see how the results change.
colorspace = 'RGB' # Can be RGB, HSV, LUV, HLS, YUV, YCrCb
orient = 9
pix_per_cell = 8
cell_per_block = 2
hog_channel = 0 # Can be 0, 1, 2, or "ALL"

t=time.time()
car_features = extract_features(cars, cspace=colorspace, orient=orient, 
                        pix_per_cell=pix_per_cell, cell_per_block=cell_per_block, 
                        hog_channel=hog_channel)
notcar_features = extract_features(notcars, cspace=colorspace, orient=orient, 
                        pix_per_cell=pix_per_cell, cell_per_block=cell_per_block, 
                        hog_channel=hog_channel)
t2 = time.time()
print(round(t2-t, 2), 'Seconds to extract HOG features...')
# Create an array stack of feature vectors
X = np.vstack((car_features, notcar_features)).astype(np.float64)                        
# Fit a per-column scaler
X_scaler = StandardScaler().fit(X)
# Apply the scaler to X
scaled_X = X_scaler.transform(X)

# Define the labels vector
y = np.hstack((np.ones(len(car_features)), np.zeros(len(notcar_features))))


# Split up data into randomized training and test sets
rand_state = np.random.randint(0, 100)
X_train, X_test, y_train, y_test = train_test_split(
    scaled_X, y, test_size=0.2, random_state=rand_state)

print('Using:',orient,'orientations',pix_per_cell,
    'pixels per cell and', cell_per_block,'cells per block')
print('Feature vector length:', len(X_train[0]))
# Use a linear SVC 
svc = SVC()
parameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
clf = GridSearchCV(svc, parameters)

# Check the training time for the SVC
t=time.time()
clf.fit(X_train, y_train)
t2 = time.time()
print(round(t2-t, 2), 'Seconds to train SVC...')
# Check the score of the SVC
print('Test Accuracy of SVC = ', round(clf.score(X_test, y_test), 4))
# Check the prediction time for a single sample
t=time.time()
n_predict = 10
print('My SVC predicts: ', clf.predict(X_test[0:n_predict]))
print('For these',n_predict, 'labels: ', y_test[0:n_predict])
t2 = time.time()
print(round(t2-t, 5), 'Seconds to predict', n_predict,'labels with SVC')
```

    1.71 Seconds to extract HOG features...
    Using: 9 orientations 8 pixels per cell and 2 cells per block
    Feature vector length: 1764
    9.9 Seconds to train SVC...
    Test Accuracy of SVC =  0.97
    My SVC predicts:  [ 0.  1.  1.  1.  0.  1.  0.  0.  1.  0.]
    For these 10 labels:  [ 0.  1.  1.  1.  0.  1.  0.  0.  1.  0.]
    0.01016 Seconds to predict 10 labels with SVC


# Sliding window implementation

The following implementation shows the *sliding_window* function. This tankes input of the intial and final coordinate on the image, a window dimention tuple and an overlap region. An example of a (64,64) window with a 0.5 overlap is shown below.


```python
def draw_boxes(img, bboxes, color=(0, 0, 255), thick=6):
    # Make a copy of the image
    imcopy = np.copy(img)
    # Iterate through the bounding boxes
    for bbox in bboxes:
        # Draw a rectangle given bbox coordinates
        cv2.rectangle(imcopy, bbox[0], bbox[1], color, thick)
    # Return the image copy with boxes drawn
    return imcopy
    
    
# Define a function that takes an image,
# start and stop positions in both x and y, 
# window size (x and y dimensions),  
# and overlap fraction (for both x and y)
def slide_window(img, x_start_stop=[None, None], y_start_stop=[None, None], xy_window=(64, 64), xy_overlap=(0.5, 0.5)):
    # If x and/or y start/stop positions not defined, set to image size
    if x_start_stop[0] == None:
        x_start_stop[0] = 0
    if x_start_stop[1] == None:
        x_start_stop[1] = img.shape[1]
    if y_start_stop[0] == None:
        y_start_stop[0] = 0
    if y_start_stop[1] == None:
        y_start_stop[1] = img.shape[0]
    # Compute the span of the region to be searched    
    xspan = x_start_stop[1] - x_start_stop[0]
    yspan = y_start_stop[1] - y_start_stop[0]
    # Compute the number of pixels per step in x/y
    nx_pix_per_step = np.int(xy_window[0]*(1 - xy_overlap[0]))
    ny_pix_per_step = np.int(xy_window[1]*(1 - xy_overlap[1]))
    # Compute the number of windows in x/y
    nx_buffer = np.int(xy_window[0]*(xy_overlap[0]))
    ny_buffer = np.int(xy_window[1]*(xy_overlap[1]))
    nx_windows = np.int((xspan-nx_buffer)/nx_pix_per_step) 
    ny_windows = np.int((yspan-ny_buffer)/ny_pix_per_step) 
    # Initialize a list to append window positions to
    window_list = []
    # Loop through finding x and y window positions
    # Note: you could vectorize this step, but in practice
    # you'll be considering windows one by one with your
    # classifier, so looping makes sense
    for ys in range(ny_windows):
        for xs in range(nx_windows):
            # Calculate window position
            startx = xs*nx_pix_per_step + x_start_stop[0]
            endx = startx + xy_window[0]
            starty = ys*ny_pix_per_step + y_start_stop[0]
            endy = starty + xy_window[1]
            # Append window position to list
            window_list.append(((startx, starty), (endx, endy)))
    # Return the list of windows
    return window_list

path = 'test_images/test6.jpg'
image = plt.imread(path)
windows = slide_window(image, x_start_stop=[None, None], y_start_stop=[400, 660], xy_window=(64, 64), xy_overlap=(0.5, 0.5))
                       
window_img = draw_boxes(image, windows, color=(0, 255, 255), thick=6)                    
plt.imshow(window_img)
plt.show()
```


![png](output_29_0.png)


# Extracting Features from an Image

Sliding Window Search

1. Describe how (and identify where in your code) you implemented a sliding window search.  How did you decide what scales to search and how much to overlap windows?

The *search_windows* function takes as imput an image and list of windows. The output is a list of positive detections.





```python
# Define a function to extract features from a single image window
# This function is very similar to extract_features()
# just for a single image rather than list of images
def single_img_features(img, color_space='RGB', spatial_size=(32, 32),
                        hist_bins=32, orient=9, 
                        pix_per_cell=8, cell_per_block=2, hog_channel=0,
                        spatial_feat=True, hist_feat=True, hog_feat=True):    
    #1) Define an empty list to receive features
    img_features = []
    #2) Apply color conversion if other than 'RGB'
    if color_space != 'RGB':
        if color_space == 'HSV':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        elif color_space == 'LUV':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2LUV)
        elif color_space == 'HLS':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2HLS)
        elif color_space == 'YUV':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2YUV)
        elif color_space == 'YCrCb':
            feature_image = cv2.cvtColor(img, cv2.COLOR_RGB2YCrCb)
    else: feature_image = np.copy(img)      
    #3) Compute spatial features if flag is set
    if spatial_feat == True:
        spatial_features = bin_spatial(feature_image, size=spatial_size)
        #4) Append features to list
        img_features.append(spatial_features)
    #5) Compute histogram features if flag is set
    if hist_feat == True:
        hist_features = color_hist(feature_image, nbins=hist_bins)
        #6) Append features to list
        img_features.append(hist_features)
    #7) Compute HOG features if flag is set
    if hog_feat == True:
        if hog_channel == 'ALL':
            hog_features = []
            for channel in range(feature_image.shape[2]):
                hog_features.extend(get_hog_features(feature_image[:,:,channel], 
                                    orient, pix_per_cell, cell_per_block, 
                                    vis=False, feature_vec=True))      
        else:
            hog_features = get_hog_features(feature_image[:,:,hog_channel], orient, 
                        pix_per_cell, cell_per_block, vis=False, feature_vec=True)
        #8) Append features to list
        img_features.append(hog_features)

    #9) Return concatenated array of features
    return np.concatenate(img_features)

# Define a function you will pass an image 
# and the list of windows to be searched (output of slide_windows())
def search_windows(img, windows, clf, scaler, color_space='RGB', 
                   spatial_size=(32, 32), hist_bins=32, orient=9, 
                   pix_per_cell=8, cell_per_block=2, hog_channel=0,
                   spatial_feat=True, hist_feat=True, hog_feat=True):

    #1) Create an empty list to receive positive detection windows
    on_windows = []
    #2) Iterate over all windows in the list
    for window in windows:
        #3) Extract the test window from original image
        test_img = cv2.resize(img[window[0][1]:window[1][1], window[0][0]:window[1][0]], (64, 64))      
        #4) Extract features for that window using single_img_features()
        features = single_img_features(test_img, color_space=color_space, 
                            spatial_size=spatial_size, hist_bins=hist_bins, 
                            orient=orient, pix_per_cell=pix_per_cell, 
                            cell_per_block=cell_per_block, 
                            hog_channel=hog_channel, spatial_feat=spatial_feat, 
                            hist_feat=hist_feat, hog_feat=hog_feat)
        #5) Scale extracted features to be fed to classifier
        test_features = scaler.transform(np.array(features).reshape(1, -1))
        #6) Predict using your classifier
        prediction = clf.predict(test_features)
        #7) If positive (prediction == 1) then save the window
        if prediction == 1:
            on_windows.append(window)
    #8) Return windows for positive detections
    return on_windows

```

The image below demonstrates the output of the searcha and sliding window detector with the trained SVC classifier. The colour space of *YCrCb*, HOG orientation of *10*, *pix_per_cell = 8*, and *xy_overlap=(.7,.7)* are shown to display agreeable results.


```python
sample_size = 500
cars = cars[0:sample_size]
notcars = notcars[0:sample_size]

draw_image = np.copy(image)


color_space = 'YCrCb' # Can be RGB, HSV, LUV, HLS, YUV, YCrCb
orient = 10  # HOG orientations
pix_per_cell = 8 # HOG pixels per cell
cell_per_block = 2 # HOG cells per block
hog_channel = 'ALL' # Can be 0, 1, 2, or "ALL"
spatial_size = (32, 32) # Spatial binning dimensions
hist_bins = 64   # Number of histogram bins
spatial_feat = True # Spatial features on or off
hist_feat = True # Histogram features on or off
hog_feat = True # HOG features on or off
y_start_stop = [400, 656] # Min and max in y to search in slide_window()
xy_window=(128,128)
xy_overlap=(.7,.7)

def extract_features(imgs, color_space='YCrCb', spatial_size=(32, 32),
                        hist_bins=32, orient=9, 
                        pix_per_cell=10, cell_per_block=2, hog_channel=0,
                        spatial_feat=True, hist_feat=True, hog_feat=True):
    # Create a list to append feature vectors to
    features = []
    # Iterate through the list of images
    for file in imgs:
        file_features = []
        # Read in each one by one
        image = mpimg.imread(file)
        # apply color conversion if other than 'RGB'
        if color_space != 'RGB':
            if color_space == 'HSV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
            elif color_space == 'LUV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2LUV)
            elif color_space == 'HLS':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2HLS)
            elif color_space == 'YUV':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2YUV)
            elif color_space == 'YCrCb':
                feature_image = cv2.cvtColor(image, cv2.COLOR_RGB2YCrCb)
        else: feature_image = np.copy(image)      

        if spatial_feat == True:
            spatial_features = bin_spatial(feature_image, size=spatial_size)
            file_features.append(spatial_features)
        if hist_feat == True:
            # Apply color_hist()
            hist_features = color_hist(feature_image, nbins=hist_bins)
            file_features.append(hist_features)
        if hog_feat == True:
        # Call get_hog_features() with vis=False, feature_vec=True
            if hog_channel == 'ALL':
                hog_features = []
                for channel in range(feature_image.shape[2]):
                    hog_features.append(get_hog_features(feature_image[:,:,channel], 
                                        orient, pix_per_cell, cell_per_block, 
                                        vis=False, feature_vec=True))
                hog_features = np.ravel(hog_features)        
            else:
                hog_features = get_hog_features(feature_image[:,:,hog_channel], orient, 
                            pix_per_cell, cell_per_block, vis=False, feature_vec=True)
            # Append the new feature vector to the features list
            file_features.append(hog_features)
        features.append(np.concatenate(file_features))
    # Return list of feature vectors
    return features

car_features = extract_features(cars, color_space=color_space, \
                        spatial_size=spatial_size, hist_bins=hist_bins, \
                        orient=orient, pix_per_cell=pix_per_cell, \
                        cell_per_block=cell_per_block, \
                        hog_channel=hog_channel, spatial_feat=spatial_feat, \
                        hist_feat=hist_feat, hog_feat=hog_feat)
notcar_features = extract_features(notcars, color_space=color_space, \
                        spatial_size=spatial_size, hist_bins=hist_bins, \
                        orient=orient, pix_per_cell=pix_per_cell, \
                        cell_per_block=cell_per_block, \
                        hog_channel=hog_channel, spatial_feat=spatial_feat, \
                        hist_feat=hist_feat, hog_feat=hog_feat)

X = np.vstack((car_features, notcar_features)).astype(np.float64)                        
# Fit a per-column scaler
X_scaler = StandardScaler().fit(X)
# Apply the scaler to X
scaled_X = X_scaler.transform(X)

# Define the labels vector
y = np.hstack((np.ones(len(car_features)), np.zeros(len(notcar_features))))


# Split up data into randomized training and test sets
rand_state = np.random.randint(0, 100)
X_train, X_test, y_train, y_test = train_test_split(
    scaled_X, y, test_size=0.2, random_state=rand_state)

print('Using:',orient,'orientations',pix_per_cell,
    'pixels per cell and', cell_per_block,'cells per block')
print('Feature vector length:', len(X_train[0]))
# Use a linear SVC 
svc = SVC()
parameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
clf = GridSearchCV(svc, parameters)
# Check the training time for the SVC
t=time.time()
clf.fit(X_train, y_train)
t2 = time.time()
print(round(t2-t, 2), 'Seconds to train SVC...')
# Check the score of the SVC
print('Test Accuracy of SVC = ', round(clf.score(X_test, y_test), 4))
# Check the prediction time for a single sample
t=time.time()

windows = slide_window(image, x_start_stop=[600, None], y_start_stop=y_start_stop, 
                    xy_window=(128, 128), xy_overlap=(0.7, 0.7))

                      
                           

hot_windows = search_windows(image, windows, clf, X_scaler, color_space=color_space, 
                        spatial_size=spatial_size, hist_bins=hist_bins, 
                        orient=orient, pix_per_cell=pix_per_cell, 
                        cell_per_block=cell_per_block, 
                        hog_channel=hog_channel, spatial_feat=spatial_feat, 
                        hist_feat=hist_feat, hog_feat=hog_feat)                       

window_img = draw_boxes(draw_image, hot_windows, color=(0, 0, 255), thick=6)                    

plt.imshow(window_img)
plt.show()

```

    Using: 10 orientations 8 pixels per cell and 2 cells per block
    Feature vector length: 9144
    47.27 Seconds to train SVC...
    Test Accuracy of SVC =  0.995



![png](output_33_1.png)



```python
windows = slide_window(image, x_start_stop=[600, None], y_start_stop=y_start_stop, 
                    xy_window=(128, 128), xy_overlap=(0.7, 0.7))

                      
                           

hot_windows = search_windows(image, windows, clf, X_scaler, color_space=color_space, 
                        spatial_size=spatial_size, hist_bins=hist_bins, 
                        orient=orient, pix_per_cell=pix_per_cell, 
                        cell_per_block=cell_per_block, 
                        hog_channel=hog_channel, spatial_feat=spatial_feat, 
                        hist_feat=hist_feat, hog_feat=hog_feat)                       

window_img = draw_boxes(draw_image, hot_windows, color=(0, 0, 255), thick=6)                    

plt.imshow(window_img)
plt.show()

```


![png](output_34_0.png)


The detector is tested in the test images and the results are shown below. Here it can be seen that there is little false positives. However the white car in the 3rd figure is not correctly identified.


```python
for i in range(1,6):
    
    fname = 'test_images/test{}.jpg'.format(i)
    image = mpimg.imread(fname)
    draw_image = np.copy(image)



    windows = slide_window(image, x_start_stop=[600, None], y_start_stop=[300,656], 
                    xy_window=(64, 64), xy_overlap=(0.7, 0.7))
    
    windows2 = slide_window(image, x_start_stop=[600, None], y_start_stop=[300,656], 
                    xy_window=(128, 128), xy_overlap=(0.7, 0.7))
        
    windows3 = slide_window(image, x_start_stop=[600, None], y_start_stop=[300,656], 
                    xy_window=(80, 80), xy_overlap=(0.7, 0.7))
    
    
    windows = windows + windows2+ windows3
                
                           

    hot_windows = search_windows(image, windows, clf, X_scaler, color_space=color_space, 
                        spatial_size=spatial_size, hist_bins=hist_bins, 
                        orient=orient, pix_per_cell=pix_per_cell, 
                        cell_per_block=cell_per_block, 
                        hog_channel=hog_channel, spatial_feat=spatial_feat, 
                        hist_feat=hist_feat, hog_feat=hog_feat)                       

    window_img = draw_boxes(draw_image, hot_windows, color=(0, 0, 255), thick=6)    
    
    f, (ax1, ax2) = plt.subplots(1, 2, figsize=(18,9))
    plt.tight_layout()
    ax1.imshow(draw_image)
    ax1.set_title('Original Image', fontsize=30)
    ax2.imshow(window_img)
    ax2.set_title('Cars found', fontsize=30)
    plt.savefig('output_images/windows.png', bbox_inches="tight")
```


![png](output_36_0.png)



![png](output_36_1.png)



![png](output_36_2.png)



![png](output_36_3.png)



![png](output_36_4.png)



The *add_heat* function takes as input a an image and a list of boxes and returns a heatmap.




```python
def add_heat(heatmap, bbox_list):
    # Iterate through list of bboxes
    for box in bbox_list:
        # Add += 1 for all pixels inside each bbox
        # Assuming each "box" takes the form ((x1, y1), (x2, y2))
        heatmap[box[0][1]:box[1][1], box[0][0]:box[1][0]] += 1

    # Return updated heatmap
    return heatmap
```


```python
def apply_threshold(heatmap, threshold):
    # Zero out pixels below the threshold
    heatmap[heatmap <= threshold] = 0
    # Return thresholded map
    return heatmap
def convert_color(img, conv='RGB2YCrCb'):
    if conv == 'RGB2YCrCb':
        return cv2.cvtColor(img, cv2.COLOR_RGB2YCrCb)
    if conv == 'BGR2YCrCb':
        return cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    if conv == 'RGB2LUV':
        return cv2.cvtColor(img, cv2.COLOR_RGB2LUV)
```


```python
def draw_labeled_bboxes(img, labels):
    # Iterate through all detected cars
    for car_number in range(1, labels[1]+1):
        # Find pixels with each car_number label value
        nonzero = (labels[0] == car_number).nonzero()
        # Identify x and y values of those pixels
        nonzeroy = np.array(nonzero[0])
        nonzerox = np.array(nonzero[1])
        # Define a bounding box based on min/max x and y
        bbox = ((np.min(nonzerox), np.min(nonzeroy)), (np.max(nonzerox), np.max(nonzeroy)))
        # Draw the box on the image
        cv2.rectangle(img, bbox[0], bbox[1], (255,0,0), 8)
    # Return the image
    return img
```

The *find_cars* function is a pipeline function which takes and image and returns detections of cars on the image. An example of the function applied to a random image can be seen below. 


```python
def find_cars(img, ystart, ystop, scale, svc, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins):
    
    draw_img = np.copy(img)
    img = img.astype(np.float32)/255
    
    img_tosearch = img[ystart:ystop,:,:]
    ctrans_tosearch = convert_color(img_tosearch, conv='RGB2YCrCb')
    if scale != 1:
        imshape = ctrans_tosearch.shape
        ctrans_tosearch = cv2.resize(ctrans_tosearch, (np.int(imshape[1]/scale), np.int(imshape[0]/scale)))
        
    ch1 = ctrans_tosearch[:,:,0]
    ch2 = ctrans_tosearch[:,:,1]
    ch3 = ctrans_tosearch[:,:,2]

    # Define blocks and steps as above
    nxblocks = (ch1.shape[1] // pix_per_cell) - cell_per_block + 1
    nyblocks = (ch1.shape[0] // pix_per_cell) - cell_per_block + 1 
    nfeat_per_block = orient*cell_per_block**2
    
    # 64 was the orginal sampling rate, with 8 cells and 8 pix per cell
    window = 64
    nblocks_per_window = (window // pix_per_cell) - cell_per_block + 1
    cells_per_step = 2  # Instead of overlap, define how many cells to step
    nxsteps = (nxblocks - nblocks_per_window) // cells_per_step
    nysteps = (nyblocks - nblocks_per_window) // cells_per_step
    
    # Compute individual channel HOG features for the entire image
    hog1 = get_hog_features(ch1, orient, pix_per_cell, cell_per_block, feature_vec=False)
    hog2 = get_hog_features(ch2, orient, pix_per_cell, cell_per_block, feature_vec=False)
    hog3 = get_hog_features(ch3, orient, pix_per_cell, cell_per_block, feature_vec=False)
    
    for xb in range(nxsteps):
        for yb in range(nysteps):
            ypos = yb*cells_per_step
            xpos = xb*cells_per_step
            # Extract HOG for this patch
            hog_feat1 = hog1[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_feat2 = hog2[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_feat3 = hog3[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_features = np.hstack((hog_feat1, hog_feat2, hog_feat3))

            xleft = xpos*pix_per_cell
            ytop = ypos*pix_per_cell

            # Extract the image patch
            subimg = cv2.resize(ctrans_tosearch[ytop:ytop+window, xleft:xleft+window], (64,64))
          
            # Get color features
            spatial_features = bin_spatial(subimg, size=spatial_size)
            hist_features = color_hist(subimg, nbins=hist_bins)

            # Scale features and make a prediction
            test_features = X_scaler.transform(np.hstack((spatial_features, hist_features, hog_features)).reshape(1, -1))    
            #test_features = X_scaler.transform(np.hstack((shape_feat, hist_feat)).reshape(1, -1))    
            test_prediction = svc.predict(test_features)
            
            if test_prediction == 1:
                xbox_left = np.int(xleft*scale)
                ytop_draw = np.int(ytop*scale)
                win_draw = np.int(window*scale)
                cv2.rectangle(draw_img,(xbox_left, ytop_draw+ystart),(xbox_left+win_draw,ytop_draw+win_draw+ystart),(0,0,255),6) 
                
    return draw_img
    
ystart = 100
ystop = 256
scale = 1.5
    
out_img = find_cars(result, ystart, ystop, scale, clf, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins)

plt.imshow(out_img)
```




    <matplotlib.image.AxesImage at 0x7feb096c1518>




![png](output_42_1.png)


The *find_cars_box* function behaves similarly to the *find_cars* function but returns a list of boxes instead.


```python
def find_cars_box(img, ystart, ystop, scale, svc, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins):
    
    draw_img = np.copy(img)
 #   img = img.astype(np.float32)/255
    img_tosearch = img[ystart:ystop,:]
        
    ctrans_tosearch = convert_color(img_tosearch, conv='RGB2YCrCb')
    if scale != 1:
        imshape = ctrans_tosearch.shape
        ctrans_tosearch = cv2.resize(ctrans_tosearch, (np.int(imshape[1]/scale), np.int(imshape[0]/scale)))
        
    ch1 = ctrans_tosearch[:,:,0]
    ch2 = ctrans_tosearch[:,:,1]
    ch3 = ctrans_tosearch[:,:,2]

    # Define blocks and steps as above
    nxblocks = (ch1.shape[1] // pix_per_cell) - cell_per_block + 1
    nyblocks = (ch1.shape[0] // pix_per_cell) - cell_per_block + 1 
    nfeat_per_block = orient*cell_per_block**2
    
    # 64 was the orginal sampling rate, with 8 cells and 8 pix per cell
    window = 64
    nblocks_per_window = (window // pix_per_cell) - cell_per_block + 1
    cells_per_step = 3  # Instead of overlap, define how many cells to step
    nxsteps = (nxblocks - nblocks_per_window) // cells_per_step
    nysteps = (nyblocks - nblocks_per_window) // cells_per_step
    
    # Compute individual channel HOG features for the entire image
    hog1 = get_hog_features(ch1, orient, pix_per_cell, cell_per_block, feature_vec=False)
    hog2 = get_hog_features(ch2, orient, pix_per_cell, cell_per_block, feature_vec=False)
    hog3 = get_hog_features(ch3, orient, pix_per_cell, cell_per_block, feature_vec=False)
    
    bbox_list=[] #https://github.com/preritj/Vechicle-Detection-Tracking
    for xb in range(nxsteps):
        for yb in range(nysteps):
            ypos = yb*cells_per_step
            xpos = xb*cells_per_step
            # Extract HOG for this patch
            hog_feat1 = hog1[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_feat2 = hog2[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_feat3 = hog3[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_features = np.hstack((hog_feat1, hog_feat2, hog_feat3))

            xleft = xpos*pix_per_cell
            ytop = ypos*pix_per_cell

            # Extract the image patch
            subimg = cv2.resize(ctrans_tosearch[ytop:ytop+window, xleft:xleft+window], (64,64))

            # Get color features
            spatial_features = bin_spatial(subimg, size=spatial_size)
            hist_features = color_hist(subimg, nbins=hist_bins)

            # Scale features and make a prediction
            test_features = X_scaler.transform(np.hstack((spatial_features,
                                                          hist_features,
                                                          hog_features)).reshape(1, -1))  
            
            # Scale features and make a prediction  
            test_prediction = svc.predict(test_features)
            
            if test_prediction == 1:
                xbox_left = np.int(xleft*scale)
                ytop_draw = np.int(ytop*scale)
                win_draw = np.int(window*scale)
                cv2.rectangle(draw_img,(xbox_left, ytop_draw+ystart),
                              (xbox_left+win_draw,ytop_draw+win_draw+ystart),
                              (255,0,0),8)
                bbox_list.append(((xbox_left, ytop_draw+ystart), #github.com/preritj
                                  (xbox_left+win_draw,ytop_draw+win_draw+ystart)))
                
    
    return bbox_list
```

# 2. Describe how (and identify where in your code) you implemented some kind of filter for false positives and some method for combining overlapping bounding boxes.

## I recorded the positions of positive detections in each frame of the video.  From the positive detections I created a heatmap and then thresholded that map to identify vehicle positions.  I then used scipy.ndimage.measurements.label() to identify individual blobs in the heatmap.  I then assumed each blob corresponded to a vehicle.  I constructed bounding boxes to cover the area of each blob detected.  

Here's an example result showing the heatmap from a series of frames of video, the result of scipy.ndimage.measurements.label() and the bounding boxes then overlaid on the last frame of video:

Here are six frames and their corresponding heatmaps:



The implementation below demonstrated the *heat_map* method applied after *find_cars_box* to show the detection of the cars applied to the test images.


```python
for i in range(2,7):
    
    fname = 'test_images/test{}.jpg'.format(i)
    img = mpimg.imread(fname)
    

    orient=10
    pix_per_cell=8
    cell_per_block=2
    spatial_size=(32, 32)
    hist_bins=64
    
    bbox_list = []
    
    
    ystart = 380
    ystop = 550
  #  xstart, xstop = 700,1230
    scale = 1.0
    bbox_list.append(find_cars_box(img, ystart, ystop,scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 385
    ystop = 550
  #  xstart, xstop = 700,1230
    scale = 1.25
    bbox_list.append(find_cars_box(img, ystart, ystop,scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
        
    ystart = 350
    ystop = 600
 #   xstart, xstop = 700,1230
    scale = 1.5
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 2.0
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 2.25
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 2.5
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 3.0
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
       
    # Copied from 'jeremy-shannon'
    bbox_list = [item for sublist in bbox_list for item in sublist] 
    #print(bbox_list)
    
    out_img = draw_boxes(img, bbox_list, color=(0, 0, 255), thick=6) 
    
    heat = np.zeros_like(img[:,:,0]).astype(np.float)
    heat = add_heat(heat, bbox_list)
    heat = apply_threshold(heat, 1.3)  

    # Find final boxes from heatmap using label function
    labels = label(heat)
    new_img = draw_labeled_bboxes(np.copy(img), labels)

    f, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18,9))
    plt.tight_layout()
    ax1.imshow(out_img)
    ax1.set_title('Search Boxes', fontsize=30)
    ax2.imshow(heat, cmap='hot')
    ax2.set_title('Heat Map', fontsize=30)
    ax3.imshow(new_img)
    ax3.set_title('Bounding Boxes', fontsize=30)
    #plt.savefig('output_images/heat_map1.png', bbox_inches="tight")
```


![png](output_46_0.png)



![png](output_46_1.png)



![png](output_46_2.png)



![png](output_46_3.png)



![png](output_46_4.png)


The *process_image* method is a pipeline function for detecing vehicles. This will subsequently be applied to video datasets.


```python
def process_image(img):

    orient=10
    pix_per_cell=8
    cell_per_block=2
    spatial_size=(32, 32)
    hist_bins=64
    
    bbox_list = []
    
    ystart = 380
    ystop = 550
  #  xstart, xstop = 700,1230
    scale = 1.0
    bbox_list.append(find_cars_box(img, ystart, ystop,scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 385
    ystop = 550
  #  xstart, xstop = 700,1230
    scale = 1.25
    bbox_list.append(find_cars_box(img, ystart, ystop,scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
        
    ystart = 350
    ystop = 600
 #   xstart, xstop = 700,1230
    scale = 1.5
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 2.0
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 2.25
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 2.5
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
    
    ystart = 400
    ystop = 656
  #  xstart, xstop = 700,1230
    scale = 3.0
    bbox_list.append(find_cars_box(img, ystart, ystop, scale, clf, X_scaler,
                                    orient, pix_per_cell, cell_per_block,
                                    spatial_size, hist_bins))
       
    # Copied from 'jeremy-shannon'
    bbox_list = [item for sublist in bbox_list for item in sublist] 
    #print(bbox_list)
    
    out_img = draw_boxes(img, bbox_list, color=(0, 0, 255), thick=6) 
    
    heat = np.zeros_like(img[:,:,0]).astype(np.float)
    heat = add_heat(heat, bbox_list)
    heat = apply_threshold(heat, 1.3)  


    # Find final boxes from heatmap using label function
    labels = label(heat)
    new_img = draw_labeled_bboxes(np.copy(img), labels)
    
    return new_img
```


```python
test_output = "test_images/test_output.mp4"
clip = VideoFileClip("test_video.mp4")
test_clip = clip.fl_image(process_image)
%time test_clip.write_videofile(test_output, audio=False)
```

    [MoviePy] >>>> Building video test_images/test_output.mp4
    [MoviePy] Writing video test_images/test_output.mp4


     97%|█████████▋| 38/39 [01:33<00:02,  2.45s/it]


    [MoviePy] Done.
    [MoviePy] >>>> Video ready: test_images/test_output.mp4 
    
    CPU times: user 1min 53s, sys: 252 ms, total: 1min 53s
    Wall time: 1min 33s



```python
output = "test_images/project_output.mp4"
clip = VideoFileClip("project_video.mp4")
clip = clip.fl_image(process_image)
%time clip.write_videofile(output, audio=False)
```

    [MoviePy] >>>> Building video test_images/project_output.mp4
    [MoviePy] Writing video test_images/project_output.mp4


    
      0%|          | 0/1261 [00:00<?, ?it/s][A
      0%|          | 1/1261 [00:03<1:15:16,  3.58s/it][A
      0%|          | 2/1261 [00:07<1:15:20,  3.59s/it][A
      0%|          | 3/1261 [00:10<1:15:23,  3.60s/it][A
      0%|          | 4/1261 [00:14<1:15:24,  3.60s/it][A
      0%|          | 5/1261 [00:18<1:15:25,  3.60s/it][A
      0%|          | 6/1261 [00:21<1:15:14,  3.60s/it][A
      1%|          | 7/1261 [00:25<1:15:27,  3.61s/it][A
      1%|          | 8/1261 [00:28<1:15:42,  3.63s/it][A
      1%|          | 9/1261 [00:32<1:15:05,  3.60s/it][A
      1%|          | 10/1261 [00:35<1:14:43,  3.58s/it][A
      1%|          | 11/1261 [00:39<1:15:40,  3.63s/it][A
      1%|          | 12/1261 [00:43<1:16:23,  3.67s/it][A
      1%|          | 13/1261 [00:47<1:15:45,  3.64s/it][A
      1%|          | 14/1261 [00:50<1:15:17,  3.62s/it][A
      1%|          | 15/1261 [00:54<1:14:56,  3.61s/it][A
      1%|▏         | 16/1261 [00:57<1:14:36,  3.60s/it][A
      1%|▏         | 17/1261 [01:01<1:14:12,  3.58s/it][A
      1%|▏         | 18/1261 [01:04<1:13:50,  3.56s/it][A
      2%|▏         | 19/1261 [01:08<1:14:39,  3.61s/it][A
      2%|▏         | 20/1261 [01:12<1:14:02,  3.58s/it][A
      2%|▏         | 21/1261 [01:15<1:13:52,  3.57s/it][A
      2%|▏         | 22/1261 [01:19<1:13:49,  3.57s/it][A
      2%|▏         | 23/1261 [01:22<1:13:37,  3.57s/it][A
      2%|▏         | 24/1261 [01:26<1:13:35,  3.57s/it][A
      2%|▏         | 25/1261 [01:29<1:13:30,  3.57s/it][A
      2%|▏         | 26/1261 [01:33<1:13:31,  3.57s/it][A
      2%|▏         | 27/1261 [01:37<1:13:27,  3.57s/it][A
      2%|▏         | 28/1261 [01:40<1:13:10,  3.56s/it][A
      2%|▏         | 29/1261 [01:44<1:13:20,  3.57s/it][A
      2%|▏         | 30/1261 [01:47<1:13:15,  3.57s/it][A
      2%|▏         | 31/1261 [01:51<1:13:10,  3.57s/it][A
      3%|▎         | 32/1261 [01:54<1:12:56,  3.56s/it][A
      3%|▎         | 33/1261 [01:58<1:12:50,  3.56s/it][A
      3%|▎         | 34/1261 [02:02<1:13:03,  3.57s/it][A
      3%|▎         | 35/1261 [02:05<1:13:04,  3.58s/it][A
      3%|▎         | 36/1261 [02:09<1:13:05,  3.58s/it][A
      3%|▎         | 37/1261 [02:12<1:12:46,  3.57s/it][A
      3%|▎         | 38/1261 [02:16<1:12:59,  3.58s/it][A
      3%|▎         | 39/1261 [02:19<1:12:41,  3.57s/it][A
      3%|▎         | 40/1261 [02:23<1:12:22,  3.56s/it][A
      3%|▎         | 41/1261 [02:26<1:12:06,  3.55s/it][A
      3%|▎         | 42/1261 [02:30<1:11:58,  3.54s/it][A
      3%|▎         | 43/1261 [02:34<1:12:31,  3.57s/it][A
      3%|▎         | 44/1261 [02:37<1:12:38,  3.58s/it][A
      4%|▎         | 45/1261 [02:41<1:12:32,  3.58s/it][A
      4%|▎         | 46/1261 [02:44<1:12:12,  3.57s/it][A
      4%|▎         | 47/1261 [02:48<1:12:21,  3.58s/it][A
      4%|▍         | 48/1261 [02:51<1:12:12,  3.57s/it][A
      4%|▍         | 49/1261 [02:55<1:12:21,  3.58s/it][A
      4%|▍         | 50/1261 [02:59<1:12:15,  3.58s/it][A
      4%|▍         | 51/1261 [03:02<1:12:06,  3.58s/it][A
      4%|▍         | 52/1261 [03:06<1:11:58,  3.57s/it][A
      4%|▍         | 53/1261 [03:09<1:11:43,  3.56s/it][A
      4%|▍         | 54/1261 [03:13<1:11:44,  3.57s/it][A
      4%|▍         | 55/1261 [03:16<1:11:33,  3.56s/it][A
      4%|▍         | 56/1261 [03:20<1:11:34,  3.56s/it][A
      5%|▍         | 57/1261 [03:24<1:11:25,  3.56s/it][A
      5%|▍         | 58/1261 [03:27<1:11:31,  3.57s/it][A
      5%|▍         | 59/1261 [03:31<1:11:31,  3.57s/it][A
      5%|▍         | 60/1261 [03:34<1:11:33,  3.57s/it][A
      5%|▍         | 61/1261 [03:38<1:11:33,  3.58s/it][A
      5%|▍         | 62/1261 [03:41<1:11:11,  3.56s/it][A
      5%|▍         | 63/1261 [03:45<1:11:13,  3.57s/it][A
      5%|▌         | 64/1261 [03:49<1:11:04,  3.56s/it][A
      5%|▌         | 65/1261 [03:52<1:10:49,  3.55s/it][A
      5%|▌         | 66/1261 [03:56<1:11:03,  3.57s/it][A
      5%|▌         | 67/1261 [03:59<1:11:03,  3.57s/it][A
      5%|▌         | 68/1261 [04:03<1:10:57,  3.57s/it][A
      5%|▌         | 69/1261 [04:06<1:10:59,  3.57s/it][A
      6%|▌         | 70/1261 [04:10<1:10:55,  3.57s/it][A
      6%|▌         | 71/1261 [04:14<1:11:09,  3.59s/it][A
      6%|▌         | 72/1261 [04:17<1:10:50,  3.57s/it][A
      6%|▌         | 73/1261 [04:21<1:10:59,  3.59s/it][A
      6%|▌         | 74/1261 [04:24<1:10:58,  3.59s/it][A
      6%|▌         | 75/1261 [04:28<1:10:46,  3.58s/it][A
      6%|▌         | 76/1261 [04:32<1:10:36,  3.58s/it][A
      6%|▌         | 77/1261 [04:35<1:10:28,  3.57s/it][A
      6%|▌         | 78/1261 [04:39<1:10:17,  3.57s/it][A
      6%|▋         | 79/1261 [04:42<1:10:01,  3.55s/it][A
      6%|▋         | 80/1261 [04:46<1:09:59,  3.56s/it][A
      6%|▋         | 81/1261 [04:49<1:09:51,  3.55s/it][A
      7%|▋         | 82/1261 [04:53<1:10:04,  3.57s/it][A
      7%|▋         | 83/1261 [04:56<1:09:58,  3.56s/it][A
      7%|▋         | 84/1261 [05:00<1:09:58,  3.57s/it][A
      7%|▋         | 85/1261 [05:04<1:09:47,  3.56s/it][A
      7%|▋         | 86/1261 [05:07<1:09:41,  3.56s/it][A
      7%|▋         | 87/1261 [05:11<1:09:39,  3.56s/it][A
      7%|▋         | 88/1261 [05:14<1:09:54,  3.58s/it][A
      7%|▋         | 89/1261 [05:18<1:10:02,  3.59s/it][A
      7%|▋         | 90/1261 [05:21<1:09:47,  3.58s/it][A
      7%|▋         | 91/1261 [05:25<1:09:52,  3.58s/it][A
      7%|▋         | 92/1261 [05:29<1:09:18,  3.56s/it][A
      7%|▋         | 93/1261 [05:32<1:09:16,  3.56s/it][A
      7%|▋         | 94/1261 [05:36<1:09:24,  3.57s/it][A
      8%|▊         | 95/1261 [05:39<1:08:57,  3.55s/it][A
      8%|▊         | 96/1261 [05:43<1:08:54,  3.55s/it][A
      8%|▊         | 97/1261 [05:46<1:09:09,  3.56s/it][A
      8%|▊         | 98/1261 [05:50<1:09:24,  3.58s/it][A
      8%|▊         | 99/1261 [05:54<1:09:17,  3.58s/it][A
      8%|▊         | 100/1261 [05:57<1:09:22,  3.59s/it][A
      8%|▊         | 101/1261 [06:01<1:09:30,  3.60s/it][A
      8%|▊         | 102/1261 [06:04<1:09:07,  3.58s/it][A
      8%|▊         | 103/1261 [06:08<1:08:55,  3.57s/it][A
      8%|▊         | 104/1261 [06:11<1:08:48,  3.57s/it][A
      8%|▊         | 105/1261 [06:15<1:08:59,  3.58s/it][A
      8%|▊         | 106/1261 [06:19<1:08:52,  3.58s/it][A
      8%|▊         | 107/1261 [06:22<1:08:41,  3.57s/it][A
      9%|▊         | 108/1261 [06:26<1:08:36,  3.57s/it][A
      9%|▊         | 109/1261 [06:29<1:08:20,  3.56s/it][A
      9%|▊         | 110/1261 [06:33<1:08:14,  3.56s/it][A
      9%|▉         | 111/1261 [06:36<1:08:18,  3.56s/it][A
      9%|▉         | 112/1261 [06:40<1:08:14,  3.56s/it][A
      9%|▉         | 113/1261 [06:44<1:08:19,  3.57s/it][A
      9%|▉         | 114/1261 [06:47<1:08:13,  3.57s/it][A
      9%|▉         | 115/1261 [06:51<1:08:04,  3.56s/it][A
      9%|▉         | 116/1261 [06:54<1:07:58,  3.56s/it][A
      9%|▉         | 117/1261 [06:58<1:07:59,  3.57s/it][A
      9%|▉         | 118/1261 [07:01<1:08:00,  3.57s/it][A
      9%|▉         | 119/1261 [07:05<1:07:51,  3.56s/it][A
     10%|▉         | 120/1261 [07:08<1:08:00,  3.58s/it][A
     10%|▉         | 121/1261 [07:12<1:07:58,  3.58s/it][A
     10%|▉         | 122/1261 [07:16<1:07:54,  3.58s/it][A
     10%|▉         | 123/1261 [07:19<1:08:32,  3.61s/it][A
     10%|▉         | 124/1261 [07:23<1:08:46,  3.63s/it][A
     10%|▉         | 125/1261 [07:27<1:08:33,  3.62s/it][A
     10%|▉         | 126/1261 [07:30<1:08:18,  3.61s/it][A
     10%|█         | 127/1261 [07:34<1:07:56,  3.59s/it][A
     10%|█         | 128/1261 [07:37<1:07:57,  3.60s/it][A
     10%|█         | 129/1261 [07:41<1:07:53,  3.60s/it][A
     10%|█         | 130/1261 [07:45<1:07:40,  3.59s/it][A
     10%|█         | 131/1261 [07:48<1:07:30,  3.58s/it][A
     10%|█         | 132/1261 [07:52<1:07:16,  3.58s/it][A
     11%|█         | 133/1261 [07:55<1:07:44,  3.60s/it][A
     11%|█         | 134/1261 [07:59<1:07:41,  3.60s/it][A
     11%|█         | 135/1261 [08:03<1:07:32,  3.60s/it][A
     11%|█         | 136/1261 [08:06<1:07:32,  3.60s/it][A
     11%|█         | 137/1261 [08:10<1:07:33,  3.61s/it][A
     11%|█         | 138/1261 [08:13<1:07:24,  3.60s/it][A
     11%|█         | 139/1261 [08:17<1:07:26,  3.61s/it][A
     11%|█         | 140/1261 [08:21<1:07:08,  3.59s/it][A
     11%|█         | 141/1261 [08:24<1:07:03,  3.59s/it][A
     11%|█▏        | 142/1261 [08:28<1:06:44,  3.58s/it][A
     11%|█▏        | 143/1261 [08:31<1:06:47,  3.58s/it][A
     11%|█▏        | 144/1261 [08:35<1:07:01,  3.60s/it][A
     11%|█▏        | 145/1261 [08:38<1:06:48,  3.59s/it][A
     12%|█▏        | 146/1261 [08:42<1:06:56,  3.60s/it][A
     12%|█▏        | 147/1261 [08:46<1:06:58,  3.61s/it][A
     12%|█▏        | 148/1261 [08:49<1:06:44,  3.60s/it][A
     12%|█▏        | 149/1261 [08:53<1:06:39,  3.60s/it][A
     12%|█▏        | 150/1261 [08:56<1:06:26,  3.59s/it][A
     12%|█▏        | 151/1261 [09:00<1:06:14,  3.58s/it][A
     12%|█▏        | 152/1261 [09:04<1:06:14,  3.58s/it][A
     12%|█▏        | 153/1261 [09:07<1:06:01,  3.58s/it][A
     12%|█▏        | 154/1261 [09:11<1:06:40,  3.61s/it][A
     12%|█▏        | 155/1261 [09:14<1:06:31,  3.61s/it][A
     12%|█▏        | 156/1261 [09:18<1:06:36,  3.62s/it][A
     12%|█▏        | 157/1261 [09:22<1:06:22,  3.61s/it][A
     13%|█▎        | 158/1261 [09:25<1:06:10,  3.60s/it][A
     13%|█▎        | 159/1261 [09:29<1:06:43,  3.63s/it][A
     13%|█▎        | 160/1261 [09:33<1:06:40,  3.63s/it][A
     13%|█▎        | 161/1261 [09:36<1:06:11,  3.61s/it][A
     13%|█▎        | 162/1261 [09:40<1:06:07,  3.61s/it][A
     13%|█▎        | 163/1261 [09:43<1:06:03,  3.61s/it][A
     13%|█▎        | 164/1261 [09:47<1:06:03,  3.61s/it][A
     13%|█▎        | 165/1261 [09:51<1:05:57,  3.61s/it][A
     13%|█▎        | 166/1261 [09:54<1:05:45,  3.60s/it][A
     13%|█▎        | 167/1261 [09:58<1:05:43,  3.60s/it][A
     13%|█▎        | 168/1261 [10:01<1:05:30,  3.60s/it][A
     13%|█▎        | 169/1261 [10:05<1:05:28,  3.60s/it][A
     13%|█▎        | 170/1261 [10:09<1:05:25,  3.60s/it][A
     14%|█▎        | 171/1261 [10:12<1:05:25,  3.60s/it][A
     14%|█▎        | 172/1261 [10:16<1:05:45,  3.62s/it][A
     14%|█▎        | 173/1261 [10:19<1:05:23,  3.61s/it][A
     14%|█▍        | 174/1261 [10:23<1:05:07,  3.60s/it][A
     14%|█▍        | 175/1261 [10:27<1:04:50,  3.58s/it][A
     14%|█▍        | 176/1261 [10:30<1:04:41,  3.58s/it][A
     14%|█▍        | 177/1261 [10:34<1:04:45,  3.58s/it][A
     14%|█▍        | 178/1261 [10:37<1:04:32,  3.58s/it][A
     14%|█▍        | 179/1261 [10:41<1:04:18,  3.57s/it][A
     14%|█▍        | 180/1261 [10:44<1:04:15,  3.57s/it][A
     14%|█▍        | 181/1261 [10:48<1:04:13,  3.57s/it][A
     14%|█▍        | 182/1261 [10:52<1:04:02,  3.56s/it][A
     15%|█▍        | 183/1261 [10:55<1:04:25,  3.59s/it][A
     15%|█▍        | 184/1261 [10:59<1:04:09,  3.57s/it][A
     15%|█▍        | 185/1261 [11:02<1:04:06,  3.57s/it][A
     15%|█▍        | 186/1261 [11:06<1:03:54,  3.57s/it][A
     15%|█▍        | 187/1261 [11:09<1:04:00,  3.58s/it][A
     15%|█▍        | 188/1261 [11:13<1:03:47,  3.57s/it][A
     15%|█▍        | 189/1261 [11:17<1:03:38,  3.56s/it][A
     15%|█▌        | 190/1261 [11:20<1:03:25,  3.55s/it][A
     15%|█▌        | 191/1261 [11:24<1:03:18,  3.55s/it][A
     15%|█▌        | 192/1261 [11:27<1:03:29,  3.56s/it][A
     15%|█▌        | 193/1261 [11:31<1:03:44,  3.58s/it][A
     15%|█▌        | 194/1261 [11:34<1:03:33,  3.57s/it][A
     15%|█▌        | 195/1261 [11:38<1:04:26,  3.63s/it][A
     16%|█▌        | 196/1261 [11:42<1:04:00,  3.61s/it][A
     16%|█▌        | 197/1261 [11:45<1:03:56,  3.61s/it][A
     16%|█▌        | 198/1261 [11:49<1:03:48,  3.60s/it][A
     16%|█▌        | 199/1261 [11:52<1:03:36,  3.59s/it][A
     16%|█▌        | 200/1261 [11:56<1:03:38,  3.60s/it][A
     16%|█▌        | 201/1261 [12:00<1:03:23,  3.59s/it][A
     16%|█▌        | 202/1261 [12:03<1:03:35,  3.60s/it][A
     16%|█▌        | 203/1261 [12:07<1:04:13,  3.64s/it][A
     16%|█▌        | 204/1261 [12:11<1:03:53,  3.63s/it][A
     16%|█▋        | 205/1261 [12:14<1:03:45,  3.62s/it][A
     16%|█▋        | 206/1261 [12:18<1:03:32,  3.61s/it][A
     16%|█▋        | 207/1261 [12:21<1:03:24,  3.61s/it][A
     16%|█▋        | 208/1261 [12:25<1:03:16,  3.60s/it][A
     17%|█▋        | 209/1261 [12:29<1:03:08,  3.60s/it][A
     17%|█▋        | 210/1261 [12:32<1:02:46,  3.58s/it][A
     17%|█▋        | 211/1261 [12:36<1:02:47,  3.59s/it][A
     17%|█▋        | 212/1261 [12:39<1:02:34,  3.58s/it][A
     17%|█▋        | 213/1261 [12:43<1:02:26,  3.57s/it][A
     17%|█▋        | 214/1261 [12:46<1:02:24,  3.58s/it][A
     17%|█▋        | 215/1261 [12:50<1:02:20,  3.58s/it][A
     17%|█▋        | 216/1261 [12:54<1:02:16,  3.58s/it][A
     17%|█▋        | 217/1261 [12:57<1:02:01,  3.56s/it][A
     17%|█▋        | 218/1261 [13:01<1:02:02,  3.57s/it][A
     17%|█▋        | 219/1261 [13:04<1:01:56,  3.57s/it][A
     17%|█▋        | 220/1261 [13:08<1:01:53,  3.57s/it][A
     18%|█▊        | 221/1261 [13:11<1:01:36,  3.55s/it][A
     18%|█▊        | 222/1261 [13:15<1:01:37,  3.56s/it][A
     18%|█▊        | 223/1261 [13:19<1:01:46,  3.57s/it][A
     18%|█▊        | 224/1261 [13:22<1:01:38,  3.57s/it][A
     18%|█▊        | 225/1261 [13:26<1:01:31,  3.56s/it][A
     18%|█▊        | 226/1261 [13:29<1:01:13,  3.55s/it][A
     18%|█▊        | 227/1261 [13:33<1:01:11,  3.55s/it][A
     18%|█▊        | 228/1261 [13:36<1:01:13,  3.56s/it][A
     18%|█▊        | 229/1261 [13:40<1:01:03,  3.55s/it][A
     18%|█▊        | 230/1261 [13:43<1:01:13,  3.56s/it][A
     18%|█▊        | 231/1261 [13:47<1:02:02,  3.61s/it][A
     18%|█▊        | 232/1261 [13:51<1:01:37,  3.59s/it][A
     18%|█▊        | 233/1261 [13:54<1:01:09,  3.57s/it][A
     19%|█▊        | 234/1261 [13:58<1:01:04,  3.57s/it][A
     19%|█▊        | 235/1261 [14:01<1:01:14,  3.58s/it][A
     19%|█▊        | 236/1261 [14:05<1:01:03,  3.57s/it][A
     19%|█▉        | 237/1261 [14:09<1:01:04,  3.58s/it][A
     19%|█▉        | 238/1261 [14:12<1:00:59,  3.58s/it][A
     19%|█▉        | 239/1261 [14:16<1:01:10,  3.59s/it][A
     19%|█▉        | 240/1261 [14:19<1:01:12,  3.60s/it][A
     19%|█▉        | 241/1261 [14:23<1:01:09,  3.60s/it][A
     19%|█▉        | 242/1261 [14:26<1:00:58,  3.59s/it][A
     19%|█▉        | 243/1261 [14:30<1:00:58,  3.59s/it][A
     19%|█▉        | 244/1261 [14:34<1:00:56,  3.60s/it][A
     19%|█▉        | 245/1261 [14:37<1:00:48,  3.59s/it][A
     20%|█▉        | 246/1261 [14:41<1:00:28,  3.57s/it][A
     20%|█▉        | 247/1261 [14:44<1:00:58,  3.61s/it][A
     20%|█▉        | 248/1261 [14:48<1:00:47,  3.60s/it][A
     20%|█▉        | 249/1261 [14:52<1:00:54,  3.61s/it][A
     20%|█▉        | 250/1261 [14:55<1:01:14,  3.63s/it][A
     20%|█▉        | 251/1261 [14:59<1:01:56,  3.68s/it][A
     20%|█▉        | 252/1261 [15:03<1:02:12,  3.70s/it][A
     20%|██        | 253/1261 [15:07<1:02:34,  3.72s/it][A
     20%|██        | 254/1261 [15:10<1:02:10,  3.70s/it][A
     20%|██        | 255/1261 [15:14<1:02:19,  3.72s/it][A
     20%|██        | 256/1261 [15:18<1:01:48,  3.69s/it][A
     20%|██        | 257/1261 [15:21<1:01:06,  3.65s/it][A
     20%|██        | 258/1261 [15:25<1:00:53,  3.64s/it][A
     21%|██        | 259/1261 [15:29<1:00:45,  3.64s/it][A
     21%|██        | 260/1261 [15:32<1:00:23,  3.62s/it][A
     21%|██        | 261/1261 [15:36<1:00:05,  3.61s/it][A
     21%|██        | 262/1261 [15:39<59:57,  3.60s/it]  [A
     21%|██        | 263/1261 [15:43<59:52,  3.60s/it][A
     21%|██        | 264/1261 [15:46<59:31,  3.58s/it][A
     21%|██        | 265/1261 [15:50<59:30,  3.58s/it][A
     21%|██        | 266/1261 [15:54<59:25,  3.58s/it][A
     21%|██        | 267/1261 [15:57<59:20,  3.58s/it][A
     21%|██▏       | 268/1261 [16:01<59:10,  3.58s/it][A
     21%|██▏       | 269/1261 [16:04<59:05,  3.57s/it][A
     21%|██▏       | 270/1261 [16:08<59:05,  3.58s/it][A
     21%|██▏       | 271/1261 [16:11<59:05,  3.58s/it][A
     22%|██▏       | 272/1261 [16:15<59:01,  3.58s/it][A
     22%|██▏       | 273/1261 [16:19<59:02,  3.59s/it][A
     22%|██▏       | 274/1261 [16:22<59:26,  3.61s/it][A
     22%|██▏       | 275/1261 [16:26<59:29,  3.62s/it][A
     22%|██▏       | 276/1261 [16:30<59:25,  3.62s/it][A
     22%|██▏       | 277/1261 [16:33<59:07,  3.61s/it][A
     22%|██▏       | 278/1261 [16:37<59:07,  3.61s/it][A
     22%|██▏       | 279/1261 [16:40<58:55,  3.60s/it][A
     22%|██▏       | 280/1261 [16:44<58:48,  3.60s/it][A
     22%|██▏       | 281/1261 [16:48<58:47,  3.60s/it][A
     22%|██▏       | 282/1261 [16:51<58:43,  3.60s/it][A
     22%|██▏       | 283/1261 [16:55<58:38,  3.60s/it][A
     23%|██▎       | 284/1261 [16:58<58:36,  3.60s/it][A
     23%|██▎       | 285/1261 [17:02<58:19,  3.59s/it][A
     23%|██▎       | 286/1261 [17:05<58:14,  3.58s/it][A
     23%|██▎       | 287/1261 [17:09<57:58,  3.57s/it][A
     23%|██▎       | 288/1261 [17:13<57:56,  3.57s/it][A
     23%|██▎       | 289/1261 [17:16<57:51,  3.57s/it][A
     23%|██▎       | 290/1261 [17:20<57:40,  3.56s/it][A
     23%|██▎       | 291/1261 [17:23<57:59,  3.59s/it][A
     23%|██▎       | 292/1261 [17:27<58:00,  3.59s/it][A
     23%|██▎       | 293/1261 [17:31<58:19,  3.62s/it][A
     23%|██▎       | 294/1261 [17:34<58:20,  3.62s/it][A
     23%|██▎       | 295/1261 [17:38<58:12,  3.62s/it][A
     23%|██▎       | 296/1261 [17:41<57:58,  3.60s/it][A
     24%|██▎       | 297/1261 [17:45<57:48,  3.60s/it][A
     24%|██▎       | 298/1261 [17:49<57:43,  3.60s/it][A
     24%|██▎       | 299/1261 [17:52<57:42,  3.60s/it][A
     24%|██▍       | 300/1261 [17:56<57:31,  3.59s/it][A
     24%|██▍       | 301/1261 [17:59<57:23,  3.59s/it][A
     24%|██▍       | 302/1261 [18:03<57:16,  3.58s/it][A
     24%|██▍       | 303/1261 [18:07<57:05,  3.58s/it][A
     24%|██▍       | 304/1261 [18:10<57:07,  3.58s/it][A
     24%|██▍       | 305/1261 [18:14<57:02,  3.58s/it][A
     24%|██▍       | 306/1261 [18:17<57:06,  3.59s/it][A
     24%|██▍       | 307/1261 [18:21<57:07,  3.59s/it][A
     24%|██▍       | 308/1261 [18:24<56:51,  3.58s/it][A
     25%|██▍       | 309/1261 [18:28<56:47,  3.58s/it][A
     25%|██▍       | 310/1261 [18:32<56:57,  3.59s/it][A
     25%|██▍       | 311/1261 [18:35<56:44,  3.58s/it][A
     25%|██▍       | 312/1261 [18:39<56:42,  3.59s/it][A
     25%|██▍       | 313/1261 [18:42<56:37,  3.58s/it][A
     25%|██▍       | 314/1261 [18:46<56:42,  3.59s/it][A
     25%|██▍       | 315/1261 [18:50<56:32,  3.59s/it][A
     25%|██▌       | 316/1261 [18:53<56:31,  3.59s/it][A
     25%|██▌       | 317/1261 [18:57<56:38,  3.60s/it][A
     25%|██▌       | 318/1261 [19:00<56:28,  3.59s/it][A
     25%|██▌       | 319/1261 [19:04<56:15,  3.58s/it][A
     25%|██▌       | 320/1261 [19:08<56:24,  3.60s/it][A
     25%|██▌       | 321/1261 [19:11<56:10,  3.59s/it][A
     26%|██▌       | 322/1261 [19:15<56:08,  3.59s/it][A
     26%|██▌       | 323/1261 [19:18<56:06,  3.59s/it][A
     26%|██▌       | 324/1261 [19:22<56:07,  3.59s/it][A
     26%|██▌       | 325/1261 [19:25<55:54,  3.58s/it][A
     26%|██▌       | 326/1261 [19:29<55:56,  3.59s/it][A
     26%|██▌       | 327/1261 [19:33<55:45,  3.58s/it][A
     26%|██▌       | 328/1261 [19:36<55:46,  3.59s/it][A
     26%|██▌       | 329/1261 [19:40<55:52,  3.60s/it][A
     26%|██▌       | 330/1261 [19:43<55:52,  3.60s/it][A
     26%|██▌       | 331/1261 [19:47<55:54,  3.61s/it][A
     26%|██▋       | 332/1261 [19:51<55:53,  3.61s/it][A
     26%|██▋       | 333/1261 [19:54<55:46,  3.61s/it][A
     26%|██▋       | 334/1261 [19:58<55:39,  3.60s/it][A
     27%|██▋       | 335/1261 [20:01<55:34,  3.60s/it][A
     27%|██▋       | 336/1261 [20:05<55:30,  3.60s/it][A
     27%|██▋       | 337/1261 [20:09<55:24,  3.60s/it][A
     27%|██▋       | 338/1261 [20:12<55:23,  3.60s/it][A
     27%|██▋       | 339/1261 [20:16<55:25,  3.61s/it][A
     27%|██▋       | 340/1261 [20:19<55:18,  3.60s/it][A
     27%|██▋       | 341/1261 [20:23<55:07,  3.59s/it][A
     27%|██▋       | 342/1261 [20:27<55:02,  3.59s/it][A
     27%|██▋       | 343/1261 [20:30<54:54,  3.59s/it][A
     27%|██▋       | 344/1261 [20:34<54:59,  3.60s/it][A
     27%|██▋       | 345/1261 [20:37<54:48,  3.59s/it][A
     27%|██▋       | 346/1261 [20:41<54:44,  3.59s/it][A
     28%|██▊       | 347/1261 [20:45<54:28,  3.58s/it][A
     28%|██▊       | 348/1261 [20:48<54:31,  3.58s/it][A
     28%|██▊       | 349/1261 [20:52<54:51,  3.61s/it][A
     28%|██▊       | 350/1261 [20:55<54:46,  3.61s/it][A
     28%|██▊       | 351/1261 [20:59<54:28,  3.59s/it][A
     28%|██▊       | 352/1261 [21:03<54:11,  3.58s/it][A
     28%|██▊       | 353/1261 [21:06<54:09,  3.58s/it][A
     28%|██▊       | 354/1261 [21:10<54:07,  3.58s/it][A
     28%|██▊       | 355/1261 [21:13<54:02,  3.58s/it][A
     28%|██▊       | 356/1261 [21:17<53:59,  3.58s/it][A
     28%|██▊       | 357/1261 [21:20<53:57,  3.58s/it][A
     28%|██▊       | 358/1261 [21:24<53:58,  3.59s/it][A
     28%|██▊       | 359/1261 [21:28<53:40,  3.57s/it][A
     29%|██▊       | 360/1261 [21:31<53:30,  3.56s/it][A
     29%|██▊       | 361/1261 [21:35<53:40,  3.58s/it][A
     29%|██▊       | 362/1261 [21:38<53:32,  3.57s/it][A
     29%|██▉       | 363/1261 [21:42<53:25,  3.57s/it][A
     29%|██▉       | 364/1261 [21:45<53:20,  3.57s/it][A
     29%|██▉       | 365/1261 [21:49<53:29,  3.58s/it][A
     29%|██▉       | 366/1261 [21:53<53:32,  3.59s/it][A
     29%|██▉       | 367/1261 [21:56<53:37,  3.60s/it][A
     29%|██▉       | 368/1261 [22:00<53:25,  3.59s/it][A
     29%|██▉       | 369/1261 [22:03<53:31,  3.60s/it][A
     29%|██▉       | 370/1261 [22:07<53:19,  3.59s/it][A
     29%|██▉       | 371/1261 [22:11<53:18,  3.59s/it][A
     30%|██▉       | 372/1261 [22:14<53:26,  3.61s/it][A
     30%|██▉       | 373/1261 [22:18<53:17,  3.60s/it][A
     30%|██▉       | 374/1261 [22:21<53:12,  3.60s/it][A
     30%|██▉       | 375/1261 [22:25<53:10,  3.60s/it][A
     30%|██▉       | 376/1261 [22:29<53:08,  3.60s/it][A
     30%|██▉       | 377/1261 [22:32<52:57,  3.59s/it][A
     30%|██▉       | 378/1261 [22:36<52:54,  3.60s/it][A
     30%|███       | 379/1261 [22:39<52:41,  3.58s/it][A
     30%|███       | 380/1261 [22:43<53:23,  3.64s/it][A
     30%|███       | 381/1261 [22:47<53:05,  3.62s/it][A
     30%|███       | 382/1261 [22:50<53:02,  3.62s/it][A
     30%|███       | 383/1261 [22:54<52:51,  3.61s/it][A
     30%|███       | 384/1261 [22:58<52:52,  3.62s/it][A
     31%|███       | 385/1261 [23:01<52:58,  3.63s/it][A
     31%|███       | 386/1261 [23:05<52:40,  3.61s/it][A
     31%|███       | 387/1261 [23:08<52:33,  3.61s/it][A
     31%|███       | 388/1261 [23:12<52:20,  3.60s/it][A
     31%|███       | 389/1261 [23:16<52:09,  3.59s/it][A
     31%|███       | 390/1261 [23:19<52:00,  3.58s/it][A
     31%|███       | 391/1261 [23:23<51:58,  3.58s/it][A
     31%|███       | 392/1261 [23:26<52:05,  3.60s/it][A
     31%|███       | 393/1261 [23:30<52:32,  3.63s/it][A
     31%|███       | 394/1261 [23:34<53:11,  3.68s/it][A
     31%|███▏      | 395/1261 [23:38<53:45,  3.73s/it][A
     31%|███▏      | 396/1261 [23:41<53:44,  3.73s/it][A
     31%|███▏      | 397/1261 [23:45<53:16,  3.70s/it][A
     32%|███▏      | 398/1261 [23:49<52:38,  3.66s/it][A
     32%|███▏      | 399/1261 [23:52<52:18,  3.64s/it][A
     32%|███▏      | 400/1261 [23:56<51:52,  3.62s/it][A
     32%|███▏      | 401/1261 [23:59<51:30,  3.59s/it][A
     32%|███▏      | 402/1261 [24:03<51:26,  3.59s/it][A
     32%|███▏      | 403/1261 [24:06<51:09,  3.58s/it][A
     32%|███▏      | 404/1261 [24:10<51:01,  3.57s/it][A
     32%|███▏      | 405/1261 [24:14<51:15,  3.59s/it][A
     32%|███▏      | 406/1261 [24:17<51:18,  3.60s/it][A
     32%|███▏      | 407/1261 [24:21<51:15,  3.60s/it][A
     32%|███▏      | 408/1261 [24:24<51:09,  3.60s/it][A
     32%|███▏      | 409/1261 [24:28<51:00,  3.59s/it][A
     33%|███▎      | 410/1261 [24:32<50:55,  3.59s/it][A
     33%|███▎      | 411/1261 [24:35<50:53,  3.59s/it][A
     33%|███▎      | 412/1261 [24:39<50:49,  3.59s/it][A
     33%|███▎      | 413/1261 [24:42<50:39,  3.58s/it][A
     33%|███▎      | 414/1261 [24:46<50:36,  3.58s/it][A
     33%|███▎      | 415/1261 [24:49<50:23,  3.57s/it][A
     33%|███▎      | 416/1261 [24:53<50:24,  3.58s/it][A
     33%|███▎      | 417/1261 [24:57<50:13,  3.57s/it][A
     33%|███▎      | 418/1261 [25:00<50:59,  3.63s/it][A
     33%|███▎      | 419/1261 [25:04<51:20,  3.66s/it][A
     33%|███▎      | 420/1261 [25:08<51:16,  3.66s/it][A
     33%|███▎      | 421/1261 [25:12<51:27,  3.68s/it][A
     33%|███▎      | 422/1261 [25:15<51:40,  3.69s/it][A
     34%|███▎      | 423/1261 [25:19<51:47,  3.71s/it][A
     34%|███▎      | 424/1261 [25:23<51:34,  3.70s/it][A
     34%|███▎      | 425/1261 [25:26<51:45,  3.71s/it][A
     34%|███▍      | 426/1261 [25:30<52:05,  3.74s/it][A
     34%|███▍      | 427/1261 [25:34<51:17,  3.69s/it][A
     34%|███▍      | 428/1261 [25:37<50:40,  3.65s/it][A
     34%|███▍      | 429/1261 [25:41<50:15,  3.62s/it][A
     34%|███▍      | 430/1261 [25:44<49:55,  3.60s/it][A
     34%|███▍      | 431/1261 [25:48<49:42,  3.59s/it][A
     34%|███▍      | 432/1261 [25:52<49:33,  3.59s/it][A
     34%|███▍      | 433/1261 [25:55<49:19,  3.57s/it][A
     34%|███▍      | 434/1261 [25:59<49:32,  3.59s/it][A
     34%|███▍      | 435/1261 [26:03<50:41,  3.68s/it][A
     35%|███▍      | 436/1261 [26:06<51:01,  3.71s/it][A
     35%|███▍      | 437/1261 [26:10<51:05,  3.72s/it][A
     35%|███▍      | 438/1261 [26:14<50:55,  3.71s/it][A
     35%|███▍      | 439/1261 [26:18<50:57,  3.72s/it][A
     35%|███▍      | 440/1261 [26:21<50:41,  3.71s/it][A
     35%|███▍      | 441/1261 [26:25<50:42,  3.71s/it][A
     35%|███▌      | 442/1261 [26:29<50:47,  3.72s/it][A
     35%|███▌      | 443/1261 [26:32<50:44,  3.72s/it][A
     35%|███▌      | 444/1261 [26:36<50:53,  3.74s/it][A
     35%|███▌      | 445/1261 [26:40<50:49,  3.74s/it][A
     35%|███▌      | 446/1261 [26:44<50:34,  3.72s/it][A
     35%|███▌      | 447/1261 [26:47<50:29,  3.72s/it][A
     36%|███▌      | 448/1261 [26:51<50:19,  3.71s/it][A
     36%|███▌      | 449/1261 [26:55<50:57,  3.77s/it][A
     36%|███▌      | 450/1261 [26:59<50:42,  3.75s/it][A
     36%|███▌      | 451/1261 [27:02<50:22,  3.73s/it][A
     36%|███▌      | 452/1261 [27:06<50:16,  3.73s/it][A
     36%|███▌      | 453/1261 [27:10<50:48,  3.77s/it][A
     36%|███▌      | 454/1261 [27:14<51:05,  3.80s/it][A
     36%|███▌      | 455/1261 [27:18<51:17,  3.82s/it][A
     36%|███▌      | 456/1261 [27:22<51:07,  3.81s/it][A
     36%|███▌      | 457/1261 [27:25<50:48,  3.79s/it][A
     36%|███▋      | 458/1261 [27:29<50:22,  3.76s/it][A
     36%|███▋      | 459/1261 [27:33<50:02,  3.74s/it][A
     36%|███▋      | 460/1261 [27:37<50:59,  3.82s/it][A
     37%|███▋      | 461/1261 [27:40<50:52,  3.82s/it][A
     37%|███▋      | 462/1261 [27:44<49:55,  3.75s/it][A
     37%|███▋      | 463/1261 [27:48<49:31,  3.72s/it][A
     37%|███▋      | 464/1261 [27:51<49:07,  3.70s/it][A
     37%|███▋      | 465/1261 [27:55<48:23,  3.65s/it][A
     37%|███▋      | 466/1261 [27:58<47:57,  3.62s/it][A
     37%|███▋      | 467/1261 [28:02<48:01,  3.63s/it][A
     37%|███▋      | 468/1261 [28:06<47:56,  3.63s/it][A
     37%|███▋      | 469/1261 [28:09<48:09,  3.65s/it][A
     37%|███▋      | 470/1261 [28:13<48:26,  3.67s/it][A
     37%|███▋      | 471/1261 [28:17<48:56,  3.72s/it][A
     37%|███▋      | 472/1261 [28:21<49:22,  3.76s/it][A
     38%|███▊      | 473/1261 [28:25<49:59,  3.81s/it][A
     38%|███▊      | 474/1261 [28:29<50:33,  3.85s/it][A
     38%|███▊      | 475/1261 [28:32<49:48,  3.80s/it][A
     38%|███▊      | 476/1261 [28:36<48:54,  3.74s/it][A
     38%|███▊      | 477/1261 [28:40<49:18,  3.77s/it][A
     38%|███▊      | 478/1261 [28:44<50:03,  3.84s/it][A
     38%|███▊      | 479/1261 [28:48<49:57,  3.83s/it][A
     38%|███▊      | 480/1261 [28:51<49:47,  3.83s/it][A
     38%|███▊      | 481/1261 [28:55<49:10,  3.78s/it][A
     38%|███▊      | 482/1261 [28:59<48:33,  3.74s/it][A
     38%|███▊      | 483/1261 [29:03<48:57,  3.78s/it][A
     38%|███▊      | 484/1261 [29:06<49:13,  3.80s/it][A
     38%|███▊      | 485/1261 [29:10<49:13,  3.81s/it][A
     39%|███▊      | 486/1261 [29:14<48:50,  3.78s/it][A
     39%|███▊      | 487/1261 [29:18<49:03,  3.80s/it][A
     39%|███▊      | 488/1261 [29:22<49:29,  3.84s/it][A
     39%|███▉      | 489/1261 [29:26<49:37,  3.86s/it][A
     39%|███▉      | 490/1261 [29:29<49:17,  3.84s/it][A
     39%|███▉      | 491/1261 [29:33<49:20,  3.84s/it][A
     39%|███▉      | 492/1261 [29:37<49:09,  3.84s/it][A
     39%|███▉      | 493/1261 [29:41<49:12,  3.84s/it][A
     39%|███▉      | 494/1261 [29:45<48:48,  3.82s/it][A
     39%|███▉      | 495/1261 [29:49<48:35,  3.81s/it][A
     39%|███▉      | 496/1261 [29:52<48:18,  3.79s/it][A
     39%|███▉      | 497/1261 [29:56<49:04,  3.85s/it][A
     39%|███▉      | 498/1261 [30:00<48:24,  3.81s/it][A
     40%|███▉      | 499/1261 [30:04<48:21,  3.81s/it][A
     40%|███▉      | 500/1261 [30:07<47:42,  3.76s/it][A
     40%|███▉      | 501/1261 [30:11<47:38,  3.76s/it][A
     40%|███▉      | 502/1261 [30:15<47:56,  3.79s/it][A
     40%|███▉      | 503/1261 [30:19<47:55,  3.79s/it][A
     40%|███▉      | 504/1261 [30:23<47:48,  3.79s/it][A
     40%|████      | 505/1261 [30:26<47:46,  3.79s/it][A
     40%|████      | 506/1261 [30:30<47:41,  3.79s/it][A
     40%|████      | 507/1261 [30:34<47:23,  3.77s/it][A
     40%|████      | 508/1261 [30:38<47:09,  3.76s/it][A
     40%|████      | 509/1261 [30:42<47:18,  3.78s/it][A
     40%|████      | 510/1261 [30:45<47:26,  3.79s/it][A
     41%|████      | 511/1261 [30:49<47:13,  3.78s/it][A
     41%|████      | 512/1261 [30:53<46:53,  3.76s/it][A
     41%|████      | 513/1261 [30:57<46:46,  3.75s/it][A
     41%|████      | 514/1261 [31:00<46:45,  3.76s/it][A
     41%|████      | 515/1261 [31:04<46:12,  3.72s/it][A
     41%|████      | 516/1261 [31:08<46:04,  3.71s/it][A
     41%|████      | 517/1261 [31:11<46:02,  3.71s/it][A
     41%|████      | 518/1261 [31:15<45:47,  3.70s/it][A
     41%|████      | 519/1261 [31:19<45:22,  3.67s/it][A
     41%|████      | 520/1261 [31:22<45:31,  3.69s/it][A
     41%|████▏     | 521/1261 [31:26<45:14,  3.67s/it][A
     41%|████▏     | 522/1261 [31:30<45:03,  3.66s/it][A
     41%|████▏     | 523/1261 [31:33<45:14,  3.68s/it][A
     42%|████▏     | 524/1261 [31:37<45:02,  3.67s/it][A
     42%|████▏     | 525/1261 [31:41<45:35,  3.72s/it][A
     42%|████▏     | 526/1261 [31:45<45:35,  3.72s/it][A
     42%|████▏     | 527/1261 [31:48<45:25,  3.71s/it][A
     42%|████▏     | 528/1261 [31:52<45:28,  3.72s/it][A
     42%|████▏     | 529/1261 [31:56<45:24,  3.72s/it][A
     42%|████▏     | 530/1261 [31:59<45:23,  3.73s/it][A
     42%|████▏     | 531/1261 [32:03<45:09,  3.71s/it][A
     42%|████▏     | 532/1261 [32:07<44:46,  3.69s/it][A
     42%|████▏     | 533/1261 [32:10<44:38,  3.68s/it][A
     42%|████▏     | 534/1261 [32:14<44:50,  3.70s/it][A
     42%|████▏     | 535/1261 [32:18<44:58,  3.72s/it][A
     43%|████▎     | 536/1261 [32:22<44:55,  3.72s/it][A
     43%|████▎     | 537/1261 [32:25<44:50,  3.72s/it][A
     43%|████▎     | 538/1261 [32:29<44:49,  3.72s/it][A
     43%|████▎     | 539/1261 [32:33<44:59,  3.74s/it][A
     43%|████▎     | 540/1261 [32:37<45:11,  3.76s/it][A
     43%|████▎     | 541/1261 [32:40<45:07,  3.76s/it][A
     43%|████▎     | 542/1261 [32:44<45:06,  3.76s/it][A
     43%|████▎     | 543/1261 [32:48<45:10,  3.77s/it][A
     43%|████▎     | 544/1261 [32:52<45:12,  3.78s/it][A
     43%|████▎     | 545/1261 [32:56<45:08,  3.78s/it][A
     43%|████▎     | 546/1261 [32:59<45:27,  3.81s/it][A
     43%|████▎     | 547/1261 [33:03<45:13,  3.80s/it][A
     43%|████▎     | 548/1261 [33:07<44:58,  3.79s/it][A
     44%|████▎     | 549/1261 [33:11<45:17,  3.82s/it][A
     44%|████▎     | 550/1261 [33:15<44:55,  3.79s/it][A
     44%|████▎     | 551/1261 [33:18<44:48,  3.79s/it][A
     44%|████▍     | 552/1261 [33:22<44:45,  3.79s/it][A
     44%|████▍     | 553/1261 [33:26<44:42,  3.79s/it][A
     44%|████▍     | 554/1261 [33:30<44:53,  3.81s/it][A
     44%|████▍     | 555/1261 [33:34<44:41,  3.80s/it][A
     44%|████▍     | 556/1261 [33:37<44:53,  3.82s/it][A
     44%|████▍     | 557/1261 [33:41<44:36,  3.80s/it][A
     44%|████▍     | 558/1261 [33:45<44:21,  3.79s/it][A
     44%|████▍     | 559/1261 [33:49<43:59,  3.76s/it][A
     44%|████▍     | 560/1261 [33:52<43:50,  3.75s/it][A
     44%|████▍     | 561/1261 [33:56<43:32,  3.73s/it][A
     45%|████▍     | 562/1261 [34:00<43:28,  3.73s/it][A
     45%|████▍     | 563/1261 [34:04<43:26,  3.73s/it][A
     45%|████▍     | 564/1261 [34:07<42:41,  3.67s/it][A
     45%|████▍     | 565/1261 [34:11<42:34,  3.67s/it][A
     45%|████▍     | 566/1261 [34:14<42:44,  3.69s/it][A
     45%|████▍     | 567/1261 [34:18<43:04,  3.72s/it][A
     45%|████▌     | 568/1261 [34:22<43:15,  3.75s/it][A
     45%|████▌     | 569/1261 [34:26<43:18,  3.75s/it][A
     45%|████▌     | 570/1261 [34:30<43:17,  3.76s/it][A
     45%|████▌     | 571/1261 [34:33<43:06,  3.75s/it][A
     45%|████▌     | 572/1261 [34:37<43:04,  3.75s/it][A
     45%|████▌     | 573/1261 [34:41<43:09,  3.76s/it][A
     46%|████▌     | 574/1261 [34:45<43:06,  3.76s/it][A
     46%|████▌     | 575/1261 [34:48<43:09,  3.77s/it][A
     46%|████▌     | 576/1261 [34:52<42:54,  3.76s/it][A
     46%|████▌     | 577/1261 [34:56<42:02,  3.69s/it][A
     46%|████▌     | 578/1261 [34:59<41:28,  3.64s/it][A
     46%|████▌     | 579/1261 [35:03<41:13,  3.63s/it][A
     46%|████▌     | 580/1261 [35:06<41:02,  3.62s/it][A
     46%|████▌     | 581/1261 [35:10<40:40,  3.59s/it][A
     46%|████▌     | 582/1261 [35:14<40:27,  3.58s/it][A
     46%|████▌     | 583/1261 [35:17<40:24,  3.58s/it][A
     46%|████▋     | 584/1261 [35:21<40:16,  3.57s/it][A
     46%|████▋     | 585/1261 [35:24<40:08,  3.56s/it][A
     46%|████▋     | 586/1261 [35:28<40:21,  3.59s/it][A
     47%|████▋     | 587/1261 [35:31<40:18,  3.59s/it][A
     47%|████▋     | 588/1261 [35:35<40:17,  3.59s/it][A
     47%|████▋     | 589/1261 [35:39<40:11,  3.59s/it][A
     47%|████▋     | 590/1261 [35:42<40:07,  3.59s/it][A
     47%|████▋     | 591/1261 [35:46<39:59,  3.58s/it][A
     47%|████▋     | 592/1261 [35:49<39:55,  3.58s/it][A
     47%|████▋     | 593/1261 [35:53<39:53,  3.58s/it][A
     47%|████▋     | 594/1261 [35:57<39:55,  3.59s/it][A
     47%|████▋     | 595/1261 [36:00<39:47,  3.59s/it][A
     47%|████▋     | 596/1261 [36:04<39:49,  3.59s/it][A
     47%|████▋     | 597/1261 [36:07<39:44,  3.59s/it][A
     47%|████▋     | 598/1261 [36:11<39:38,  3.59s/it][A
     48%|████▊     | 599/1261 [36:14<39:35,  3.59s/it][A
     48%|████▊     | 600/1261 [36:18<39:43,  3.61s/it][A
     48%|████▊     | 601/1261 [36:22<39:32,  3.59s/it][A
     48%|████▊     | 602/1261 [36:25<39:23,  3.59s/it][A
     48%|████▊     | 603/1261 [36:29<39:17,  3.58s/it][A
     48%|████▊     | 604/1261 [36:32<39:04,  3.57s/it][A
     48%|████▊     | 605/1261 [36:36<39:02,  3.57s/it][A
     48%|████▊     | 606/1261 [36:40<39:01,  3.57s/it][A
     48%|████▊     | 607/1261 [36:43<38:55,  3.57s/it][A
     48%|████▊     | 608/1261 [36:47<38:46,  3.56s/it][A
     48%|████▊     | 609/1261 [36:50<38:47,  3.57s/it][A
     48%|████▊     | 610/1261 [36:54<38:40,  3.56s/it][A
     48%|████▊     | 611/1261 [36:57<38:33,  3.56s/it][A
     49%|████▊     | 612/1261 [37:01<38:32,  3.56s/it][A
     49%|████▊     | 613/1261 [37:04<38:25,  3.56s/it][A
     49%|████▊     | 614/1261 [37:08<38:24,  3.56s/it][A
     49%|████▉     | 615/1261 [37:12<38:12,  3.55s/it][A
     49%|████▉     | 616/1261 [37:15<38:17,  3.56s/it][A
     49%|████▉     | 617/1261 [37:19<38:16,  3.57s/it][A
     49%|████▉     | 618/1261 [37:22<38:07,  3.56s/it][A
     49%|████▉     | 619/1261 [37:26<38:07,  3.56s/it][A
     49%|████▉     | 620/1261 [37:29<38:07,  3.57s/it][A
     49%|████▉     | 621/1261 [37:33<38:04,  3.57s/it][A
     49%|████▉     | 622/1261 [37:37<38:03,  3.57s/it][A
     49%|████▉     | 623/1261 [37:40<37:59,  3.57s/it][A
     49%|████▉     | 624/1261 [37:44<38:05,  3.59s/it][A
     50%|████▉     | 625/1261 [37:47<38:02,  3.59s/it][A
     50%|████▉     | 626/1261 [37:51<38:03,  3.60s/it][A
     50%|████▉     | 627/1261 [37:55<37:58,  3.59s/it][A
     50%|████▉     | 628/1261 [37:58<37:53,  3.59s/it][A
     50%|████▉     | 629/1261 [38:02<37:46,  3.59s/it][A
     50%|████▉     | 630/1261 [38:05<37:41,  3.58s/it][A
     50%|█████     | 631/1261 [38:09<37:31,  3.57s/it][A
     50%|█████     | 632/1261 [38:12<37:16,  3.56s/it][A
     50%|█████     | 633/1261 [38:16<37:25,  3.58s/it][A
     50%|█████     | 634/1261 [38:20<37:27,  3.58s/it][A
     50%|█████     | 635/1261 [38:23<37:19,  3.58s/it][A
     50%|█████     | 636/1261 [38:27<37:10,  3.57s/it][A
     51%|█████     | 637/1261 [38:30<37:00,  3.56s/it][A
     51%|█████     | 638/1261 [38:34<36:51,  3.55s/it][A
     51%|█████     | 639/1261 [38:37<36:49,  3.55s/it][A
     51%|█████     | 640/1261 [38:41<36:47,  3.55s/it][A
     51%|█████     | 641/1261 [38:44<36:42,  3.55s/it][A
     51%|█████     | 642/1261 [38:48<36:42,  3.56s/it][A
     51%|█████     | 643/1261 [38:51<36:30,  3.54s/it][A
     51%|█████     | 644/1261 [38:55<36:25,  3.54s/it][A
     51%|█████     | 645/1261 [38:59<36:18,  3.54s/it][A
     51%|█████     | 646/1261 [39:02<36:18,  3.54s/it][A
     51%|█████▏    | 647/1261 [39:06<36:09,  3.53s/it][A
     51%|█████▏    | 648/1261 [39:09<36:05,  3.53s/it][A
     51%|█████▏    | 649/1261 [39:13<36:04,  3.54s/it][A
     52%|█████▏    | 650/1261 [39:16<35:56,  3.53s/it][A
     52%|█████▏    | 651/1261 [39:20<36:01,  3.54s/it][A
     52%|█████▏    | 652/1261 [39:23<35:55,  3.54s/it][A
     52%|█████▏    | 653/1261 [39:27<35:45,  3.53s/it][A
     52%|█████▏    | 654/1261 [39:30<35:41,  3.53s/it][A
     52%|█████▏    | 655/1261 [39:34<35:27,  3.51s/it][A
     52%|█████▏    | 656/1261 [39:37<35:22,  3.51s/it][A
     52%|█████▏    | 657/1261 [39:41<35:17,  3.51s/it][A
     52%|█████▏    | 658/1261 [39:44<35:16,  3.51s/it][A
     52%|█████▏    | 659/1261 [39:48<35:21,  3.52s/it][A
     52%|█████▏    | 660/1261 [39:51<35:32,  3.55s/it][A
     52%|█████▏    | 661/1261 [39:55<35:34,  3.56s/it][A
     52%|█████▏    | 662/1261 [39:59<35:31,  3.56s/it][A
     53%|█████▎    | 663/1261 [40:02<34:46,  3.49s/it][A
     53%|█████▎    | 664/1261 [40:05<34:17,  3.45s/it][A
     53%|█████▎    | 665/1261 [40:09<33:56,  3.42s/it][A
     53%|█████▎    | 666/1261 [40:12<33:30,  3.38s/it][A
     53%|█████▎    | 667/1261 [40:15<33:24,  3.37s/it][A
     53%|█████▎    | 668/1261 [40:19<33:10,  3.36s/it][A
     53%|█████▎    | 669/1261 [40:22<33:11,  3.36s/it][A
     53%|█████▎    | 670/1261 [40:25<33:09,  3.37s/it][A
     53%|█████▎    | 671/1261 [40:29<33:08,  3.37s/it][A
     53%|█████▎    | 672/1261 [40:32<33:02,  3.37s/it][A
     53%|█████▎    | 673/1261 [40:35<32:54,  3.36s/it][A
     53%|█████▎    | 674/1261 [40:39<32:50,  3.36s/it][A
     54%|█████▎    | 675/1261 [40:42<32:41,  3.35s/it][A
     54%|█████▎    | 676/1261 [40:45<32:42,  3.35s/it][A
     54%|█████▎    | 677/1261 [40:49<32:39,  3.36s/it][A
     54%|█████▍    | 678/1261 [40:52<32:38,  3.36s/it][A
     54%|█████▍    | 679/1261 [40:56<32:30,  3.35s/it][A
     54%|█████▍    | 680/1261 [40:59<32:25,  3.35s/it][A
     54%|█████▍    | 681/1261 [41:02<32:13,  3.33s/it][A
     54%|█████▍    | 682/1261 [41:06<32:05,  3.33s/it][A
     54%|█████▍    | 683/1261 [41:09<32:03,  3.33s/it][A
     54%|█████▍    | 684/1261 [41:12<31:59,  3.33s/it][A
     54%|█████▍    | 685/1261 [41:16<31:59,  3.33s/it][A
     54%|█████▍    | 686/1261 [41:19<31:58,  3.34s/it][A
     54%|█████▍    | 687/1261 [41:22<31:55,  3.34s/it][A
     55%|█████▍    | 688/1261 [41:26<31:53,  3.34s/it][A
     55%|█████▍    | 689/1261 [41:29<31:44,  3.33s/it][A
     55%|█████▍    | 690/1261 [41:32<31:42,  3.33s/it][A
     55%|█████▍    | 691/1261 [41:36<31:43,  3.34s/it][A
     55%|█████▍    | 692/1261 [41:39<31:41,  3.34s/it][A
     55%|█████▍    | 693/1261 [41:42<31:35,  3.34s/it][A
     55%|█████▌    | 694/1261 [41:46<31:36,  3.34s/it][A
     55%|█████▌    | 695/1261 [41:49<31:38,  3.36s/it][A
     55%|█████▌    | 696/1261 [41:52<31:36,  3.36s/it][A
     55%|█████▌    | 697/1261 [41:56<31:30,  3.35s/it][A
     55%|█████▌    | 698/1261 [41:59<31:24,  3.35s/it][A
     55%|█████▌    | 699/1261 [42:02<31:23,  3.35s/it][A
     56%|█████▌    | 700/1261 [42:06<31:19,  3.35s/it][A
     56%|█████▌    | 701/1261 [42:09<31:16,  3.35s/it][A
     56%|█████▌    | 702/1261 [42:12<31:16,  3.36s/it][A
     56%|█████▌    | 703/1261 [42:16<31:15,  3.36s/it][A
     56%|█████▌    | 704/1261 [42:19<30:58,  3.34s/it][A
     56%|█████▌    | 705/1261 [42:22<30:56,  3.34s/it][A
     56%|█████▌    | 706/1261 [42:26<30:54,  3.34s/it][A
     56%|█████▌    | 707/1261 [42:29<30:51,  3.34s/it][A
     56%|█████▌    | 708/1261 [42:32<30:48,  3.34s/it][A
     56%|█████▌    | 709/1261 [42:36<30:42,  3.34s/it][A
     56%|█████▋    | 710/1261 [42:39<30:41,  3.34s/it][A
     56%|█████▋    | 711/1261 [42:42<30:29,  3.33s/it][A
     56%|█████▋    | 712/1261 [42:46<30:28,  3.33s/it][A
     57%|█████▋    | 713/1261 [42:49<30:30,  3.34s/it][A
     57%|█████▋    | 714/1261 [42:52<30:29,  3.35s/it][A
     57%|█████▋    | 715/1261 [42:56<30:29,  3.35s/it][A
     57%|█████▋    | 716/1261 [42:59<30:28,  3.35s/it][A
     57%|█████▋    | 717/1261 [43:03<30:23,  3.35s/it][A
     57%|█████▋    | 718/1261 [43:06<30:19,  3.35s/it][A
     57%|█████▋    | 719/1261 [43:09<30:11,  3.34s/it][A
     57%|█████▋    | 720/1261 [43:13<30:09,  3.35s/it][A
     57%|█████▋    | 721/1261 [43:16<30:06,  3.34s/it][A
     57%|█████▋    | 722/1261 [43:19<30:05,  3.35s/it][A
     57%|█████▋    | 723/1261 [43:23<29:59,  3.35s/it][A
     57%|█████▋    | 724/1261 [43:26<29:49,  3.33s/it][A
     57%|█████▋    | 725/1261 [43:29<29:48,  3.34s/it][A
     58%|█████▊    | 726/1261 [43:33<29:47,  3.34s/it][A
     58%|█████▊    | 727/1261 [43:36<29:47,  3.35s/it][A
     58%|█████▊    | 728/1261 [43:39<29:38,  3.34s/it][A
     58%|█████▊    | 729/1261 [43:43<29:38,  3.34s/it][A
     58%|█████▊    | 730/1261 [43:46<29:37,  3.35s/it][A
     58%|█████▊    | 731/1261 [43:49<29:33,  3.35s/it][A
     58%|█████▊    | 732/1261 [43:53<29:27,  3.34s/it][A
     58%|█████▊    | 733/1261 [43:56<29:17,  3.33s/it][A
     58%|█████▊    | 734/1261 [43:59<29:18,  3.34s/it][A
     58%|█████▊    | 735/1261 [44:03<29:23,  3.35s/it][A
     58%|█████▊    | 736/1261 [44:06<29:21,  3.35s/it][A
     58%|█████▊    | 737/1261 [44:09<29:19,  3.36s/it][A
     59%|█████▊    | 738/1261 [44:13<29:22,  3.37s/it][A
     59%|█████▊    | 739/1261 [44:16<29:15,  3.36s/it][A
     59%|█████▊    | 740/1261 [44:20<29:10,  3.36s/it][A
     59%|█████▉    | 741/1261 [44:23<29:06,  3.36s/it][A
     59%|█████▉    | 742/1261 [44:26<28:56,  3.35s/it][A
     59%|█████▉    | 743/1261 [44:30<28:49,  3.34s/it][A
     59%|█████▉    | 744/1261 [44:33<28:47,  3.34s/it][A
     59%|█████▉    | 745/1261 [44:36<28:48,  3.35s/it][A
     59%|█████▉    | 746/1261 [44:40<28:50,  3.36s/it][A
     59%|█████▉    | 747/1261 [44:43<28:49,  3.37s/it][A
     59%|█████▉    | 748/1261 [44:46<28:42,  3.36s/it][A
     59%|█████▉    | 749/1261 [44:50<28:43,  3.37s/it][A
     59%|█████▉    | 750/1261 [44:53<28:43,  3.37s/it][A
     60%|█████▉    | 751/1261 [44:57<28:43,  3.38s/it][A
     60%|█████▉    | 752/1261 [45:00<28:35,  3.37s/it][A
     60%|█████▉    | 753/1261 [45:03<28:30,  3.37s/it][A
     60%|█████▉    | 754/1261 [45:07<28:22,  3.36s/it][A
     60%|█████▉    | 755/1261 [45:10<28:19,  3.36s/it][A
     60%|█████▉    | 756/1261 [45:13<28:19,  3.37s/it][A
     60%|██████    | 757/1261 [45:17<28:15,  3.36s/it][A
     60%|██████    | 758/1261 [45:20<28:10,  3.36s/it][A
     60%|██████    | 759/1261 [45:23<27:59,  3.35s/it][A
     60%|██████    | 760/1261 [45:27<27:52,  3.34s/it][A
     60%|██████    | 761/1261 [45:30<27:49,  3.34s/it][A
     60%|██████    | 762/1261 [45:33<27:44,  3.34s/it][A
     61%|██████    | 763/1261 [45:37<27:40,  3.33s/it][A
     61%|██████    | 764/1261 [45:40<27:37,  3.33s/it][A
     61%|██████    | 765/1261 [45:43<27:38,  3.34s/it][A
     61%|██████    | 766/1261 [45:47<27:36,  3.35s/it][A
     61%|██████    | 767/1261 [45:50<27:33,  3.35s/it][A
     61%|██████    | 768/1261 [45:53<27:27,  3.34s/it][A
     61%|██████    | 769/1261 [45:57<27:26,  3.35s/it][A
     61%|██████    | 770/1261 [46:00<27:16,  3.33s/it][A
     61%|██████    | 771/1261 [46:03<27:17,  3.34s/it][A
     61%|██████    | 772/1261 [46:07<27:09,  3.33s/it][A
     61%|██████▏   | 773/1261 [46:10<27:09,  3.34s/it][A
     61%|██████▏   | 774/1261 [46:13<27:04,  3.34s/it][A
     61%|██████▏   | 775/1261 [46:17<27:05,  3.35s/it][A
     62%|██████▏   | 776/1261 [46:20<26:56,  3.33s/it][A
     62%|██████▏   | 777/1261 [46:23<26:55,  3.34s/it][A
     62%|██████▏   | 778/1261 [46:27<26:51,  3.34s/it][A
     62%|██████▏   | 779/1261 [46:30<26:51,  3.34s/it][A
     62%|██████▏   | 780/1261 [46:33<26:49,  3.35s/it][A
     62%|██████▏   | 781/1261 [46:37<26:43,  3.34s/it][A
     62%|██████▏   | 782/1261 [46:40<26:38,  3.34s/it][A
     62%|██████▏   | 783/1261 [46:43<26:34,  3.34s/it][A
     62%|██████▏   | 784/1261 [46:47<26:33,  3.34s/it][A
     62%|██████▏   | 785/1261 [46:50<26:28,  3.34s/it][A
     62%|██████▏   | 786/1261 [46:53<26:26,  3.34s/it][A
     62%|██████▏   | 787/1261 [46:57<26:24,  3.34s/it][A
     62%|██████▏   | 788/1261 [47:00<26:18,  3.34s/it][A
     63%|██████▎   | 789/1261 [47:03<26:12,  3.33s/it][A
     63%|██████▎   | 790/1261 [47:07<26:09,  3.33s/it][A
     63%|██████▎   | 791/1261 [47:10<26:03,  3.33s/it][A
     63%|██████▎   | 792/1261 [47:13<26:04,  3.34s/it][A
     63%|██████▎   | 793/1261 [47:17<26:04,  3.34s/it][A
     63%|██████▎   | 794/1261 [47:20<26:04,  3.35s/it][A
     63%|██████▎   | 795/1261 [47:24<26:00,  3.35s/it][A
     63%|██████▎   | 796/1261 [47:27<25:52,  3.34s/it][A
     63%|██████▎   | 797/1261 [47:30<25:54,  3.35s/it][A
     63%|██████▎   | 798/1261 [47:34<25:50,  3.35s/it][A
     63%|██████▎   | 799/1261 [47:37<25:43,  3.34s/it][A
     63%|██████▎   | 800/1261 [47:40<25:41,  3.34s/it][A
     64%|██████▎   | 801/1261 [47:44<25:35,  3.34s/it][A
     64%|██████▎   | 802/1261 [47:47<25:33,  3.34s/it][A
     64%|██████▎   | 803/1261 [47:50<25:27,  3.33s/it][A
     64%|██████▍   | 804/1261 [47:54<25:19,  3.32s/it][A
     64%|██████▍   | 805/1261 [47:57<25:17,  3.33s/it][A
     64%|██████▍   | 806/1261 [48:00<25:19,  3.34s/it][A
     64%|██████▍   | 807/1261 [48:04<25:13,  3.33s/it][A
     64%|██████▍   | 808/1261 [48:07<25:16,  3.35s/it][A
     64%|██████▍   | 809/1261 [48:10<25:14,  3.35s/it][A
     64%|██████▍   | 810/1261 [48:14<25:10,  3.35s/it][A
     64%|██████▍   | 811/1261 [48:17<25:04,  3.34s/it][A
     64%|██████▍   | 812/1261 [48:20<25:01,  3.34s/it][A
     64%|██████▍   | 813/1261 [48:24<25:00,  3.35s/it][A
     65%|██████▍   | 814/1261 [48:27<25:00,  3.36s/it][A
     65%|██████▍   | 815/1261 [48:30<24:55,  3.35s/it][A
     65%|██████▍   | 816/1261 [48:34<24:52,  3.35s/it][A
     65%|██████▍   | 817/1261 [48:37<24:48,  3.35s/it][A
     65%|██████▍   | 818/1261 [48:40<24:40,  3.34s/it][A
     65%|██████▍   | 819/1261 [48:44<24:39,  3.35s/it][A
     65%|██████▌   | 820/1261 [48:47<24:39,  3.36s/it][A
     65%|██████▌   | 821/1261 [48:51<24:35,  3.35s/it][A
     65%|██████▌   | 822/1261 [48:54<24:34,  3.36s/it][A
     65%|██████▌   | 823/1261 [48:57<24:28,  3.35s/it][A
     65%|██████▌   | 824/1261 [49:01<24:29,  3.36s/it][A
     65%|██████▌   | 825/1261 [49:04<24:23,  3.36s/it][A
     66%|██████▌   | 826/1261 [49:07<24:25,  3.37s/it][A
     66%|██████▌   | 827/1261 [49:11<24:22,  3.37s/it][A
     66%|██████▌   | 828/1261 [49:14<24:15,  3.36s/it][A
     66%|██████▌   | 829/1261 [49:17<24:10,  3.36s/it][A
     66%|██████▌   | 830/1261 [49:21<24:11,  3.37s/it][A
     66%|██████▌   | 831/1261 [49:24<24:02,  3.35s/it][A
     66%|██████▌   | 832/1261 [49:27<23:54,  3.34s/it][A
     66%|██████▌   | 833/1261 [49:31<23:50,  3.34s/it][A
     66%|██████▌   | 834/1261 [49:34<23:44,  3.34s/it][A
     66%|██████▌   | 835/1261 [49:37<23:35,  3.32s/it][A
     66%|██████▋   | 836/1261 [49:41<23:31,  3.32s/it][A
     66%|██████▋   | 837/1261 [49:44<23:29,  3.33s/it][A
     66%|██████▋   | 838/1261 [49:47<23:29,  3.33s/it][A
     67%|██████▋   | 839/1261 [49:51<23:27,  3.34s/it][A
     67%|██████▋   | 840/1261 [49:54<23:23,  3.33s/it][A
     67%|██████▋   | 841/1261 [49:57<23:20,  3.33s/it][A
     67%|██████▋   | 842/1261 [50:01<23:08,  3.31s/it][A
     67%|██████▋   | 843/1261 [50:04<23:06,  3.32s/it][A
     67%|██████▋   | 844/1261 [50:07<23:10,  3.34s/it][A
     67%|██████▋   | 845/1261 [50:11<23:08,  3.34s/it][A
     67%|██████▋   | 846/1261 [50:14<23:07,  3.34s/it][A
     67%|██████▋   | 847/1261 [50:17<23:00,  3.33s/it][A
     67%|██████▋   | 848/1261 [50:21<22:56,  3.33s/it][A
     67%|██████▋   | 849/1261 [50:24<22:54,  3.34s/it][A
     67%|██████▋   | 850/1261 [50:27<22:50,  3.33s/it][A
     67%|██████▋   | 851/1261 [50:31<22:49,  3.34s/it][A
     68%|██████▊   | 852/1261 [50:34<22:49,  3.35s/it][A
     68%|██████▊   | 853/1261 [50:37<22:35,  3.32s/it][A
     68%|██████▊   | 854/1261 [50:41<22:35,  3.33s/it][A
     68%|██████▊   | 855/1261 [50:44<22:32,  3.33s/it][A
     68%|██████▊   | 856/1261 [50:47<22:23,  3.32s/it][A
     68%|██████▊   | 857/1261 [50:51<22:20,  3.32s/it][A
     68%|██████▊   | 858/1261 [50:54<22:22,  3.33s/it][A
     68%|██████▊   | 859/1261 [50:57<22:20,  3.33s/it][A
     68%|██████▊   | 860/1261 [51:01<22:14,  3.33s/it][A
     68%|██████▊   | 861/1261 [51:04<22:10,  3.33s/it][A
     68%|██████▊   | 862/1261 [51:07<22:10,  3.33s/it][A
     68%|██████▊   | 863/1261 [51:11<22:03,  3.33s/it][A
     69%|██████▊   | 864/1261 [51:14<22:00,  3.32s/it][A
     69%|██████▊   | 865/1261 [51:17<21:57,  3.33s/it][A
     69%|██████▊   | 866/1261 [51:21<21:56,  3.33s/it][A
     69%|██████▉   | 867/1261 [51:24<21:55,  3.34s/it][A
     69%|██████▉   | 868/1261 [51:27<21:52,  3.34s/it][A
     69%|██████▉   | 869/1261 [51:31<21:50,  3.34s/it][A
     69%|██████▉   | 870/1261 [51:34<21:48,  3.35s/it][A
     69%|██████▉   | 871/1261 [51:37<21:42,  3.34s/it][A
     69%|██████▉   | 872/1261 [51:41<21:37,  3.34s/it][A
     69%|██████▉   | 873/1261 [51:44<21:30,  3.33s/it][A
     69%|██████▉   | 874/1261 [51:47<21:32,  3.34s/it][A
     69%|██████▉   | 875/1261 [51:51<21:22,  3.32s/it][A
     69%|██████▉   | 876/1261 [51:54<21:23,  3.33s/it][A
     70%|██████▉   | 877/1261 [51:57<21:21,  3.34s/it][A
     70%|██████▉   | 878/1261 [52:01<21:21,  3.35s/it][A
     70%|██████▉   | 879/1261 [52:04<21:18,  3.35s/it][A
     70%|██████▉   | 880/1261 [52:07<21:21,  3.36s/it][A
     70%|██████▉   | 881/1261 [52:11<21:16,  3.36s/it][A
     70%|██████▉   | 882/1261 [52:14<21:15,  3.37s/it][A
     70%|███████   | 883/1261 [52:18<21:08,  3.36s/it][A
     70%|███████   | 884/1261 [52:21<21:07,  3.36s/it][A
     70%|███████   | 885/1261 [52:24<21:01,  3.35s/it][A
     70%|███████   | 886/1261 [52:28<20:59,  3.36s/it][A
     70%|███████   | 887/1261 [52:31<20:52,  3.35s/it][A
     70%|███████   | 888/1261 [52:34<20:47,  3.35s/it][A
     70%|███████   | 889/1261 [52:38<20:44,  3.35s/it][A
     71%|███████   | 890/1261 [52:41<20:45,  3.36s/it][A
     71%|███████   | 891/1261 [52:44<20:43,  3.36s/it][A
     71%|███████   | 892/1261 [52:48<20:37,  3.35s/it][A
     71%|███████   | 893/1261 [52:51<20:36,  3.36s/it][A
     71%|███████   | 894/1261 [52:54<20:33,  3.36s/it][A
     71%|███████   | 895/1261 [52:58<20:30,  3.36s/it][A
     71%|███████   | 896/1261 [53:01<20:29,  3.37s/it][A
     71%|███████   | 897/1261 [53:05<20:25,  3.37s/it][A
     71%|███████   | 898/1261 [53:08<20:21,  3.37s/it][A
     71%|███████▏  | 899/1261 [53:11<20:18,  3.36s/it][A
     71%|███████▏  | 900/1261 [53:15<20:15,  3.37s/it][A
     71%|███████▏  | 901/1261 [53:18<20:05,  3.35s/it][A
     72%|███████▏  | 902/1261 [53:21<19:59,  3.34s/it][A
     72%|███████▏  | 903/1261 [53:25<20:01,  3.36s/it][A
     72%|███████▏  | 904/1261 [53:28<19:52,  3.34s/it][A
     72%|███████▏  | 905/1261 [53:31<19:47,  3.33s/it][A
     72%|███████▏  | 906/1261 [53:35<19:44,  3.34s/it][A
     72%|███████▏  | 907/1261 [53:38<19:42,  3.34s/it][A
     72%|███████▏  | 908/1261 [53:41<19:37,  3.34s/it][A
     72%|███████▏  | 909/1261 [53:45<19:34,  3.34s/it][A
     72%|███████▏  | 910/1261 [53:48<19:36,  3.35s/it][A
     72%|███████▏  | 911/1261 [53:51<19:32,  3.35s/it][A
     72%|███████▏  | 912/1261 [53:55<19:31,  3.36s/it][A
     72%|███████▏  | 913/1261 [53:58<19:26,  3.35s/it][A
     72%|███████▏  | 914/1261 [54:01<19:21,  3.35s/it][A
     73%|███████▎  | 915/1261 [54:05<19:18,  3.35s/it][A
     73%|███████▎  | 916/1261 [54:08<19:14,  3.35s/it][A
     73%|███████▎  | 917/1261 [54:12<19:14,  3.36s/it][A
     73%|███████▎  | 918/1261 [54:15<19:13,  3.36s/it][A
     73%|███████▎  | 919/1261 [54:18<19:11,  3.37s/it][A
     73%|███████▎  | 920/1261 [54:22<19:08,  3.37s/it][A
     73%|███████▎  | 921/1261 [54:25<19:05,  3.37s/it][A
     73%|███████▎  | 922/1261 [54:28<18:58,  3.36s/it][A
     73%|███████▎  | 923/1261 [54:32<18:52,  3.35s/it][A
     73%|███████▎  | 924/1261 [54:35<18:49,  3.35s/it][A
     73%|███████▎  | 925/1261 [54:38<18:45,  3.35s/it][A
     73%|███████▎  | 926/1261 [54:42<18:48,  3.37s/it][A
     74%|███████▎  | 927/1261 [54:45<18:41,  3.36s/it][A
     74%|███████▎  | 928/1261 [54:48<18:37,  3.35s/it][A
     74%|███████▎  | 929/1261 [54:52<18:37,  3.37s/it][A
     74%|███████▍  | 930/1261 [54:55<18:33,  3.36s/it][A
     74%|███████▍  | 931/1261 [54:59<18:30,  3.37s/it][A
     74%|███████▍  | 932/1261 [55:02<18:23,  3.35s/it][A
     74%|███████▍  | 933/1261 [55:05<18:18,  3.35s/it][A
     74%|███████▍  | 934/1261 [55:09<18:15,  3.35s/it][A
     74%|███████▍  | 935/1261 [55:12<18:11,  3.35s/it][A
     74%|███████▍  | 936/1261 [55:15<18:06,  3.34s/it][A
     74%|███████▍  | 937/1261 [55:19<18:04,  3.35s/it][A
     74%|███████▍  | 938/1261 [55:22<18:04,  3.36s/it][A
     74%|███████▍  | 939/1261 [55:25<18:02,  3.36s/it][A
     75%|███████▍  | 940/1261 [55:29<17:57,  3.36s/it][A
     75%|███████▍  | 941/1261 [55:32<17:52,  3.35s/it][A
     75%|███████▍  | 942/1261 [55:35<17:50,  3.36s/it][A
     75%|███████▍  | 943/1261 [55:39<17:46,  3.35s/it][A
     75%|███████▍  | 944/1261 [55:42<17:41,  3.35s/it][A
     75%|███████▍  | 945/1261 [55:46<17:38,  3.35s/it][A
     75%|███████▌  | 946/1261 [55:49<17:40,  3.37s/it][A
     75%|███████▌  | 947/1261 [55:52<17:34,  3.36s/it][A
     75%|███████▌  | 948/1261 [55:56<17:32,  3.36s/it][A
     75%|███████▌  | 949/1261 [55:59<17:26,  3.35s/it][A
     75%|███████▌  | 950/1261 [56:02<17:26,  3.37s/it][A
     75%|███████▌  | 951/1261 [56:06<17:22,  3.36s/it][A
     75%|███████▌  | 952/1261 [56:09<17:21,  3.37s/it][A
     76%|███████▌  | 953/1261 [56:12<17:17,  3.37s/it][A
     76%|███████▌  | 954/1261 [56:16<17:14,  3.37s/it][A
     76%|███████▌  | 955/1261 [56:19<17:12,  3.37s/it][A
     76%|███████▌  | 956/1261 [56:23<17:09,  3.37s/it][A
     76%|███████▌  | 957/1261 [56:26<17:03,  3.37s/it][A
     76%|███████▌  | 958/1261 [56:29<16:58,  3.36s/it][A
     76%|███████▌  | 959/1261 [56:33<16:51,  3.35s/it][A
     76%|███████▌  | 960/1261 [56:36<16:48,  3.35s/it][A
     76%|███████▌  | 961/1261 [56:39<16:47,  3.36s/it][A
     76%|███████▋  | 962/1261 [56:43<16:45,  3.36s/it][A
     76%|███████▋  | 963/1261 [56:46<16:42,  3.37s/it][A
     76%|███████▋  | 964/1261 [56:49<16:40,  3.37s/it][A
     77%|███████▋  | 965/1261 [56:53<16:33,  3.36s/it][A
     77%|███████▋  | 966/1261 [56:56<16:29,  3.35s/it][A
     77%|███████▋  | 967/1261 [56:59<16:25,  3.35s/it][A
     77%|███████▋  | 968/1261 [57:03<16:20,  3.35s/it][A
     77%|███████▋  | 969/1261 [57:06<16:14,  3.34s/it][A
     77%|███████▋  | 970/1261 [57:09<16:12,  3.34s/it][A
     77%|███████▋  | 971/1261 [57:13<16:07,  3.34s/it][A
     77%|███████▋  | 972/1261 [57:16<16:06,  3.34s/it][A
     77%|███████▋  | 973/1261 [57:20<16:02,  3.34s/it][A
     77%|███████▋  | 974/1261 [57:23<16:00,  3.35s/it][A
     77%|███████▋  | 975/1261 [57:26<15:55,  3.34s/it][A
     77%|███████▋  | 976/1261 [57:29<15:48,  3.33s/it][A
     77%|███████▋  | 977/1261 [57:33<15:47,  3.34s/it][A
     78%|███████▊  | 978/1261 [57:36<15:44,  3.34s/it][A
     78%|███████▊  | 979/1261 [57:39<15:38,  3.33s/it][A
     78%|███████▊  | 980/1261 [57:43<15:32,  3.32s/it][A
     78%|███████▊  | 981/1261 [57:46<15:31,  3.33s/it][A
     78%|███████▊  | 982/1261 [57:50<15:32,  3.34s/it][A
     78%|███████▊  | 983/1261 [57:53<15:28,  3.34s/it][A
     78%|███████▊  | 984/1261 [57:56<15:28,  3.35s/it][A
     78%|███████▊  | 985/1261 [58:00<15:27,  3.36s/it][A
     78%|███████▊  | 986/1261 [58:03<15:26,  3.37s/it][A
     78%|███████▊  | 987/1261 [58:06<15:23,  3.37s/it][A
     78%|███████▊  | 988/1261 [58:10<15:21,  3.38s/it][A
     78%|███████▊  | 989/1261 [58:13<15:19,  3.38s/it][A
     79%|███████▊  | 990/1261 [58:17<15:13,  3.37s/it][A
     79%|███████▊  | 991/1261 [58:20<15:07,  3.36s/it][A
     79%|███████▊  | 992/1261 [58:23<15:04,  3.36s/it][A
     79%|███████▊  | 993/1261 [58:27<14:59,  3.35s/it][A
     79%|███████▉  | 994/1261 [58:30<14:52,  3.34s/it][A
     79%|███████▉  | 995/1261 [58:33<14:51,  3.35s/it][A
     79%|███████▉  | 996/1261 [58:37<14:48,  3.35s/it][A
     79%|███████▉  | 997/1261 [58:40<14:46,  3.36s/it][A
     79%|███████▉  | 998/1261 [58:43<14:45,  3.37s/it][A
     79%|███████▉  | 999/1261 [58:47<14:41,  3.37s/it][A
     79%|███████▉  | 1000/1261 [58:50<14:42,  3.38s/it][A
     79%|███████▉  | 1001/1261 [58:54<14:41,  3.39s/it][A
     79%|███████▉  | 1002/1261 [58:57<14:35,  3.38s/it][A
     80%|███████▉  | 1003/1261 [59:00<14:30,  3.38s/it][A
     80%|███████▉  | 1004/1261 [59:04<14:26,  3.37s/it][A
     80%|███████▉  | 1005/1261 [59:07<14:22,  3.37s/it][A
     80%|███████▉  | 1006/1261 [59:10<14:20,  3.37s/it][A
     80%|███████▉  | 1007/1261 [59:14<14:16,  3.37s/it][A
     80%|███████▉  | 1008/1261 [59:17<14:14,  3.38s/it][A
     80%|████████  | 1009/1261 [59:20<14:10,  3.38s/it][A
     80%|████████  | 1010/1261 [59:24<14:06,  3.37s/it][A
     80%|████████  | 1011/1261 [59:27<14:05,  3.38s/it][A
     80%|████████  | 1012/1261 [59:31<14:01,  3.38s/it][A
     80%|████████  | 1013/1261 [59:34<14:01,  3.39s/it][A
     80%|████████  | 1014/1261 [59:37<13:52,  3.37s/it][A
     80%|████████  | 1015/1261 [59:41<13:47,  3.37s/it][A
     81%|████████  | 1016/1261 [59:44<13:43,  3.36s/it][A
     81%|████████  | 1017/1261 [59:47<13:36,  3.35s/it][A
     81%|████████  | 1018/1261 [59:51<13:33,  3.35s/it][A
     81%|████████  | 1019/1261 [59:54<13:28,  3.34s/it][A
     81%|████████  | 1020/1261 [59:57<13:21,  3.33s/it][A
     81%|████████  | 1021/1261 [1:00:01<13:19,  3.33s/it][A
     81%|████████  | 1022/1261 [1:00:04<13:17,  3.33s/it][A
     81%|████████  | 1023/1261 [1:00:07<13:15,  3.34s/it][A
     81%|████████  | 1024/1261 [1:00:11<13:13,  3.35s/it][A
     81%|████████▏ | 1025/1261 [1:00:14<13:09,  3.35s/it][A
     81%|████████▏ | 1026/1261 [1:00:17<13:07,  3.35s/it][A
     81%|████████▏ | 1027/1261 [1:00:21<13:05,  3.36s/it][A
     82%|████████▏ | 1028/1261 [1:00:24<13:01,  3.36s/it][A
     82%|████████▏ | 1029/1261 [1:00:28<12:58,  3.36s/it][A
     82%|████████▏ | 1030/1261 [1:00:31<12:53,  3.35s/it][A
     82%|████████▏ | 1031/1261 [1:00:34<12:50,  3.35s/it][A
     82%|████████▏ | 1032/1261 [1:00:38<12:46,  3.35s/it][A
     82%|████████▏ | 1033/1261 [1:00:41<12:44,  3.35s/it][A
     82%|████████▏ | 1034/1261 [1:00:44<12:40,  3.35s/it][A
     82%|████████▏ | 1035/1261 [1:00:48<12:38,  3.36s/it][A
     82%|████████▏ | 1036/1261 [1:00:51<12:35,  3.36s/it][A
     82%|████████▏ | 1037/1261 [1:00:54<12:30,  3.35s/it][A
     82%|████████▏ | 1038/1261 [1:00:58<12:28,  3.36s/it][A
     82%|████████▏ | 1039/1261 [1:01:01<12:25,  3.36s/it][A
     82%|████████▏ | 1040/1261 [1:01:04<12:21,  3.35s/it][A
     83%|████████▎ | 1041/1261 [1:01:08<12:24,  3.38s/it][A
     83%|████████▎ | 1042/1261 [1:01:11<12:16,  3.36s/it][A
     83%|████████▎ | 1043/1261 [1:01:15<12:12,  3.36s/it][A
     83%|████████▎ | 1044/1261 [1:01:18<12:08,  3.36s/it][A
     83%|████████▎ | 1045/1261 [1:01:21<12:01,  3.34s/it][A
     83%|████████▎ | 1046/1261 [1:01:25<11:58,  3.34s/it][A
     83%|████████▎ | 1047/1261 [1:01:28<11:54,  3.34s/it][A
     83%|████████▎ | 1048/1261 [1:01:31<11:51,  3.34s/it][A
     83%|████████▎ | 1049/1261 [1:01:35<11:49,  3.34s/it][A
     83%|████████▎ | 1050/1261 [1:01:38<11:49,  3.36s/it][A
     83%|████████▎ | 1051/1261 [1:01:41<11:43,  3.35s/it][A
     83%|████████▎ | 1052/1261 [1:01:45<11:39,  3.35s/it][A
     84%|████████▎ | 1053/1261 [1:01:48<11:35,  3.34s/it][A
     84%|████████▎ | 1054/1261 [1:01:51<11:31,  3.34s/it][A
     84%|████████▎ | 1055/1261 [1:01:55<11:29,  3.34s/it][A
     84%|████████▎ | 1056/1261 [1:01:58<11:25,  3.35s/it][A
     84%|████████▍ | 1057/1261 [1:02:01<11:23,  3.35s/it][A
     84%|████████▍ | 1058/1261 [1:02:05<11:19,  3.35s/it][A
     84%|████████▍ | 1059/1261 [1:02:08<11:16,  3.35s/it][A
     84%|████████▍ | 1060/1261 [1:02:11<11:13,  3.35s/it][A
     84%|████████▍ | 1061/1261 [1:02:15<11:11,  3.36s/it][A
     84%|████████▍ | 1062/1261 [1:02:18<11:09,  3.36s/it][A
     84%|████████▍ | 1063/1261 [1:02:22<11:06,  3.37s/it][A
     84%|████████▍ | 1064/1261 [1:02:25<11:02,  3.36s/it][A
     84%|████████▍ | 1065/1261 [1:02:28<10:57,  3.35s/it][A
     85%|████████▍ | 1066/1261 [1:02:32<10:53,  3.35s/it][A
     85%|████████▍ | 1067/1261 [1:02:35<10:48,  3.34s/it][A
     85%|████████▍ | 1068/1261 [1:02:38<10:44,  3.34s/it][A
     85%|████████▍ | 1069/1261 [1:02:42<10:40,  3.34s/it][A
     85%|████████▍ | 1070/1261 [1:02:45<10:39,  3.35s/it][A
     85%|████████▍ | 1071/1261 [1:02:48<10:35,  3.35s/it][A
     85%|████████▌ | 1072/1261 [1:02:52<10:33,  3.35s/it][A
     85%|████████▌ | 1073/1261 [1:02:55<10:30,  3.35s/it][A
     85%|████████▌ | 1074/1261 [1:02:58<10:24,  3.34s/it][A
     85%|████████▌ | 1075/1261 [1:03:02<10:23,  3.35s/it][A
     85%|████████▌ | 1076/1261 [1:03:05<10:20,  3.35s/it][A
     85%|████████▌ | 1077/1261 [1:03:08<10:17,  3.35s/it][A
     85%|████████▌ | 1078/1261 [1:03:12<10:13,  3.35s/it][A
     86%|████████▌ | 1079/1261 [1:03:15<10:06,  3.34s/it][A
     86%|████████▌ | 1080/1261 [1:03:18<10:03,  3.34s/it][A
     86%|████████▌ | 1081/1261 [1:03:22<09:59,  3.33s/it][A
     86%|████████▌ | 1082/1261 [1:03:25<09:55,  3.33s/it][A
     86%|████████▌ | 1083/1261 [1:03:28<09:53,  3.34s/it][A
     86%|████████▌ | 1084/1261 [1:03:32<09:52,  3.35s/it][A
     86%|████████▌ | 1085/1261 [1:03:35<09:48,  3.34s/it][A
     86%|████████▌ | 1086/1261 [1:03:38<09:43,  3.33s/it][A
     86%|████████▌ | 1087/1261 [1:03:42<09:41,  3.34s/it][A
     86%|████████▋ | 1088/1261 [1:03:45<09:36,  3.33s/it][A
     86%|████████▋ | 1089/1261 [1:03:48<09:32,  3.33s/it][A
     86%|████████▋ | 1090/1261 [1:03:52<09:29,  3.33s/it][A
     87%|████████▋ | 1091/1261 [1:03:55<09:26,  3.33s/it][A
     87%|████████▋ | 1092/1261 [1:03:58<09:24,  3.34s/it][A
     87%|████████▋ | 1093/1261 [1:04:02<09:20,  3.33s/it][A
     87%|████████▋ | 1094/1261 [1:04:05<09:19,  3.35s/it][A
     87%|████████▋ | 1095/1261 [1:04:09<09:17,  3.36s/it][A
     87%|████████▋ | 1096/1261 [1:04:12<09:14,  3.36s/it][A
     87%|████████▋ | 1097/1261 [1:04:15<09:07,  3.34s/it][A
     87%|████████▋ | 1098/1261 [1:04:18<09:04,  3.34s/it][A
     87%|████████▋ | 1099/1261 [1:04:22<09:01,  3.34s/it][A
     87%|████████▋ | 1100/1261 [1:04:25<08:57,  3.34s/it][A
     87%|████████▋ | 1101/1261 [1:04:28<08:53,  3.33s/it][A
     87%|████████▋ | 1102/1261 [1:04:32<08:49,  3.33s/it][A
     87%|████████▋ | 1103/1261 [1:04:35<08:47,  3.34s/it][A
     88%|████████▊ | 1104/1261 [1:04:39<08:44,  3.34s/it][A
     88%|████████▊ | 1105/1261 [1:04:42<08:40,  3.34s/it][A
     88%|████████▊ | 1106/1261 [1:04:45<08:36,  3.33s/it][A
     88%|████████▊ | 1107/1261 [1:04:49<08:33,  3.33s/it][A
     88%|████████▊ | 1108/1261 [1:04:52<08:31,  3.34s/it][A
     88%|████████▊ | 1109/1261 [1:04:55<08:27,  3.34s/it][A
     88%|████████▊ | 1110/1261 [1:04:59<08:22,  3.33s/it][A
     88%|████████▊ | 1111/1261 [1:05:02<08:20,  3.33s/it][A
     88%|████████▊ | 1112/1261 [1:05:05<08:15,  3.33s/it][A
     88%|████████▊ | 1113/1261 [1:05:08<08:12,  3.32s/it][A
     88%|████████▊ | 1114/1261 [1:05:12<08:09,  3.33s/it][A
     88%|████████▊ | 1115/1261 [1:05:15<08:07,  3.34s/it][A
     89%|████████▊ | 1116/1261 [1:05:19<08:03,  3.33s/it][A
     89%|████████▊ | 1117/1261 [1:05:22<08:01,  3.35s/it][A
     89%|████████▊ | 1118/1261 [1:05:25<07:59,  3.35s/it][A
     89%|████████▊ | 1119/1261 [1:05:29<07:56,  3.35s/it][A
     89%|████████▉ | 1120/1261 [1:05:32<07:54,  3.36s/it][A
     89%|████████▉ | 1121/1261 [1:05:35<07:50,  3.36s/it][A
     89%|████████▉ | 1122/1261 [1:05:39<07:45,  3.35s/it][A
     89%|████████▉ | 1123/1261 [1:05:42<07:41,  3.34s/it][A
     89%|████████▉ | 1124/1261 [1:05:45<07:38,  3.35s/it][A
     89%|████████▉ | 1125/1261 [1:05:49<07:34,  3.34s/it][A
     89%|████████▉ | 1126/1261 [1:05:52<07:31,  3.34s/it][A
     89%|████████▉ | 1127/1261 [1:05:55<07:27,  3.34s/it][A
     89%|████████▉ | 1128/1261 [1:05:59<07:25,  3.35s/it][A
     90%|████████▉ | 1129/1261 [1:06:02<07:21,  3.35s/it][A
     90%|████████▉ | 1130/1261 [1:06:05<07:17,  3.34s/it][A
     90%|████████▉ | 1131/1261 [1:06:09<07:15,  3.35s/it][A
     90%|████████▉ | 1132/1261 [1:06:12<07:12,  3.35s/it][A
     90%|████████▉ | 1133/1261 [1:06:16<07:10,  3.37s/it][A
     90%|████████▉ | 1134/1261 [1:06:19<07:06,  3.36s/it][A
     90%|█████████ | 1135/1261 [1:06:22<07:02,  3.35s/it][A
     90%|█████████ | 1136/1261 [1:06:26<06:59,  3.35s/it][A
     90%|█████████ | 1137/1261 [1:06:29<06:55,  3.35s/it][A
     90%|█████████ | 1138/1261 [1:06:32<06:51,  3.34s/it][A
     90%|█████████ | 1139/1261 [1:06:36<06:48,  3.35s/it][A
     90%|█████████ | 1140/1261 [1:06:39<06:44,  3.35s/it][A
     90%|█████████ | 1141/1261 [1:06:42<06:41,  3.34s/it][A
     91%|█████████ | 1142/1261 [1:06:46<06:37,  3.34s/it][A
     91%|█████████ | 1143/1261 [1:06:49<06:33,  3.33s/it][A
     91%|█████████ | 1144/1261 [1:06:52<06:30,  3.34s/it][A
     91%|█████████ | 1145/1261 [1:06:56<06:26,  3.34s/it][A
     91%|█████████ | 1146/1261 [1:06:59<06:22,  3.32s/it][A
     91%|█████████ | 1147/1261 [1:07:02<06:19,  3.33s/it][A
     91%|█████████ | 1148/1261 [1:07:06<06:16,  3.33s/it][A
     91%|█████████ | 1149/1261 [1:07:09<06:13,  3.33s/it][A
     91%|█████████ | 1150/1261 [1:07:12<06:09,  3.33s/it][A
     91%|█████████▏| 1151/1261 [1:07:16<06:06,  3.33s/it][A
     91%|█████████▏| 1152/1261 [1:07:19<06:02,  3.33s/it][A
     91%|█████████▏| 1153/1261 [1:07:22<06:00,  3.33s/it][A
     92%|█████████▏| 1154/1261 [1:07:26<05:55,  3.32s/it][A
     92%|█████████▏| 1155/1261 [1:07:29<05:52,  3.33s/it][A
     92%|█████████▏| 1156/1261 [1:07:32<05:50,  3.34s/it][A
     92%|█████████▏| 1157/1261 [1:07:36<05:48,  3.35s/it][A
     92%|█████████▏| 1158/1261 [1:07:39<05:45,  3.36s/it][A
     92%|█████████▏| 1159/1261 [1:07:42<05:42,  3.36s/it][A
     92%|█████████▏| 1160/1261 [1:07:46<05:39,  3.36s/it][A
     92%|█████████▏| 1161/1261 [1:07:49<05:35,  3.35s/it][A
     92%|█████████▏| 1162/1261 [1:07:52<05:31,  3.35s/it][A
     92%|█████████▏| 1163/1261 [1:07:56<05:27,  3.34s/it][A
     92%|█████████▏| 1164/1261 [1:07:59<05:23,  3.33s/it][A
     92%|█████████▏| 1165/1261 [1:08:02<05:20,  3.34s/it][A
     92%|█████████▏| 1166/1261 [1:08:06<05:17,  3.34s/it][A
     93%|█████████▎| 1167/1261 [1:08:09<05:15,  3.35s/it][A
     93%|█████████▎| 1168/1261 [1:08:12<05:11,  3.35s/it][A
     93%|█████████▎| 1169/1261 [1:08:16<05:09,  3.37s/it][A
     93%|█████████▎| 1170/1261 [1:08:19<05:06,  3.37s/it][A
     93%|█████████▎| 1171/1261 [1:08:23<05:02,  3.37s/it][A
     93%|█████████▎| 1172/1261 [1:08:26<04:58,  3.36s/it][A
     93%|█████████▎| 1173/1261 [1:08:29<04:55,  3.35s/it][A
     93%|█████████▎| 1174/1261 [1:08:33<04:52,  3.36s/it][A
     93%|█████████▎| 1175/1261 [1:08:36<04:49,  3.36s/it][A
     93%|█████████▎| 1176/1261 [1:08:39<04:45,  3.36s/it][A
     93%|█████████▎| 1177/1261 [1:08:43<04:41,  3.36s/it][A
     93%|█████████▎| 1178/1261 [1:08:46<04:38,  3.36s/it][A
     93%|█████████▎| 1179/1261 [1:08:49<04:35,  3.36s/it][A
     94%|█████████▎| 1180/1261 [1:08:53<04:32,  3.36s/it][A
     94%|█████████▎| 1181/1261 [1:08:56<04:28,  3.35s/it][A
     94%|█████████▎| 1182/1261 [1:08:59<04:25,  3.36s/it][A
     94%|█████████▍| 1183/1261 [1:09:03<04:21,  3.36s/it][A
     94%|█████████▍| 1184/1261 [1:09:06<04:19,  3.37s/it][A
     94%|█████████▍| 1185/1261 [1:09:10<04:16,  3.37s/it][A
     94%|█████████▍| 1186/1261 [1:09:13<04:12,  3.36s/it][A
     94%|█████████▍| 1187/1261 [1:09:16<04:07,  3.35s/it][A
     94%|█████████▍| 1188/1261 [1:09:20<04:03,  3.34s/it][A
     94%|█████████▍| 1189/1261 [1:09:23<04:01,  3.35s/it][A
     94%|█████████▍| 1190/1261 [1:09:26<03:57,  3.35s/it][A
     94%|█████████▍| 1191/1261 [1:09:30<03:54,  3.35s/it][A
     95%|█████████▍| 1192/1261 [1:09:33<03:50,  3.35s/it][A
     95%|█████████▍| 1193/1261 [1:09:36<03:48,  3.35s/it][A
     95%|█████████▍| 1194/1261 [1:09:40<03:44,  3.35s/it][A
     95%|█████████▍| 1195/1261 [1:09:43<03:40,  3.34s/it][A
     95%|█████████▍| 1196/1261 [1:09:46<03:38,  3.36s/it][A
     95%|█████████▍| 1197/1261 [1:09:50<03:34,  3.35s/it][A
     95%|█████████▌| 1198/1261 [1:09:53<03:30,  3.34s/it][A
     95%|█████████▌| 1199/1261 [1:09:56<03:27,  3.34s/it][A
     95%|█████████▌| 1200/1261 [1:10:00<03:23,  3.34s/it][A
     95%|█████████▌| 1201/1261 [1:10:03<03:20,  3.33s/it][A
     95%|█████████▌| 1202/1261 [1:10:06<03:16,  3.33s/it][A
     95%|█████████▌| 1203/1261 [1:10:10<03:13,  3.34s/it][A
     95%|█████████▌| 1204/1261 [1:10:13<03:10,  3.34s/it][A
     96%|█████████▌| 1205/1261 [1:10:16<03:07,  3.35s/it][A
     96%|█████████▌| 1206/1261 [1:10:20<03:04,  3.36s/it][A
     96%|█████████▌| 1207/1261 [1:10:23<03:00,  3.35s/it][A
     96%|█████████▌| 1208/1261 [1:10:27<02:57,  3.35s/it][A
     96%|█████████▌| 1209/1261 [1:10:30<02:54,  3.36s/it][A
     96%|█████████▌| 1210/1261 [1:10:33<02:51,  3.36s/it][A
     96%|█████████▌| 1211/1261 [1:10:37<02:47,  3.35s/it][A
     96%|█████████▌| 1212/1261 [1:10:40<02:44,  3.35s/it][A
     96%|█████████▌| 1213/1261 [1:10:43<02:40,  3.35s/it][A
     96%|█████████▋| 1214/1261 [1:10:47<02:37,  3.35s/it][A
     96%|█████████▋| 1215/1261 [1:10:50<02:34,  3.35s/it][A
     96%|█████████▋| 1216/1261 [1:10:53<02:31,  3.36s/it][A
     97%|█████████▋| 1217/1261 [1:10:57<02:27,  3.36s/it][A
     97%|█████████▋| 1218/1261 [1:11:00<02:23,  3.34s/it][A
     97%|█████████▋| 1219/1261 [1:11:03<02:20,  3.35s/it][A
     97%|█████████▋| 1220/1261 [1:11:07<02:17,  3.34s/it][A
     97%|█████████▋| 1221/1261 [1:11:10<02:13,  3.34s/it][A
     97%|█████████▋| 1222/1261 [1:11:13<02:10,  3.34s/it][A
     97%|█████████▋| 1223/1261 [1:11:17<02:07,  3.35s/it][A
     97%|█████████▋| 1224/1261 [1:11:20<02:03,  3.34s/it][A
     97%|█████████▋| 1225/1261 [1:11:24<02:00,  3.35s/it][A
     97%|█████████▋| 1226/1261 [1:11:27<01:57,  3.35s/it][A
     97%|█████████▋| 1227/1261 [1:11:30<01:53,  3.33s/it][A
     97%|█████████▋| 1228/1261 [1:11:33<01:50,  3.34s/it][A
     97%|█████████▋| 1229/1261 [1:11:37<01:47,  3.35s/it][A
     98%|█████████▊| 1230/1261 [1:11:40<01:43,  3.34s/it][A
     98%|█████████▊| 1231/1261 [1:11:43<01:39,  3.33s/it][A
     98%|█████████▊| 1232/1261 [1:11:47<01:36,  3.34s/it][A
     98%|█████████▊| 1233/1261 [1:11:50<01:33,  3.33s/it][A
     98%|█████████▊| 1234/1261 [1:11:53<01:29,  3.33s/it][A
     98%|█████████▊| 1235/1261 [1:11:57<01:26,  3.34s/it][A
     98%|█████████▊| 1236/1261 [1:12:00<01:23,  3.33s/it][A
     98%|█████████▊| 1237/1261 [1:12:04<01:20,  3.34s/it][A
     98%|█████████▊| 1238/1261 [1:12:07<01:16,  3.34s/it][A
     98%|█████████▊| 1239/1261 [1:12:10<01:13,  3.35s/it][A
     98%|█████████▊| 1240/1261 [1:12:14<01:10,  3.35s/it][A
     98%|█████████▊| 1241/1261 [1:12:17<01:06,  3.34s/it][A
     98%|█████████▊| 1242/1261 [1:12:20<01:03,  3.34s/it][A
     99%|█████████▊| 1243/1261 [1:12:24<01:00,  3.35s/it][A
     99%|█████████▊| 1244/1261 [1:12:27<00:56,  3.34s/it][A
     99%|█████████▊| 1245/1261 [1:12:30<00:53,  3.35s/it][A
     99%|█████████▉| 1246/1261 [1:12:34<00:50,  3.35s/it][A
     99%|█████████▉| 1247/1261 [1:12:37<00:46,  3.35s/it][A
     99%|█████████▉| 1248/1261 [1:12:40<00:43,  3.35s/it][A
     99%|█████████▉| 1249/1261 [1:12:44<00:40,  3.34s/it][A
     99%|█████████▉| 1250/1261 [1:12:47<00:36,  3.35s/it][A
     99%|█████████▉| 1251/1261 [1:12:50<00:33,  3.35s/it][A
     99%|█████████▉| 1252/1261 [1:12:54<00:30,  3.34s/it][A
     99%|█████████▉| 1253/1261 [1:12:57<00:26,  3.33s/it][A
     99%|█████████▉| 1254/1261 [1:13:00<00:23,  3.33s/it][A
    100%|█████████▉| 1255/1261 [1:13:04<00:20,  3.34s/it][A
    100%|█████████▉| 1256/1261 [1:13:07<00:16,  3.34s/it][A
    100%|█████████▉| 1257/1261 [1:13:10<00:13,  3.34s/it][A
    100%|█████████▉| 1258/1261 [1:13:14<00:10,  3.35s/it][A
    100%|█████████▉| 1259/1261 [1:13:17<00:06,  3.35s/it][A
    100%|█████████▉| 1260/1261 [1:13:20<00:03,  3.33s/it][A
    [A

    [MoviePy] Done.
    [MoviePy] >>>> Video ready: test_images/project_output.mp4 
    
    CPU times: user 1h 38min 38s, sys: 10.1 s, total: 1h 38min 48s
    Wall time: 1h 13min 21s



```python
output = "test_images/LDOOut.mp4"
clip = VideoFileClip("LDO.mp4")
clip = clip.fl_image(process_image)
%time clip.write_videofile(output, audio=False)
```

    [MoviePy] >>>> Building video test_images/LDOOut.mp4
    [MoviePy] Writing video test_images/LDOOut.mp4


    
      0%|          | 0/1261 [00:00<?, ?it/s][A
      0%|          | 1/1261 [00:03<1:09:40,  3.32s/it][A
      0%|          | 2/1261 [00:06<1:09:47,  3.33s/it][A
      0%|          | 3/1261 [00:10<1:10:02,  3.34s/it][A
      0%|          | 4/1261 [00:13<1:09:56,  3.34s/it][A
      0%|          | 5/1261 [00:16<1:09:50,  3.34s/it][A
      0%|          | 6/1261 [00:20<1:09:43,  3.33s/it][A
      1%|          | 7/1261 [00:23<1:09:34,  3.33s/it][A
      1%|          | 8/1261 [00:26<1:09:34,  3.33s/it][A
      1%|          | 9/1261 [00:29<1:09:22,  3.32s/it][A
      1%|          | 10/1261 [00:33<1:09:07,  3.32s/it][A
      1%|          | 11/1261 [00:36<1:09:08,  3.32s/it][A
      1%|          | 12/1261 [00:39<1:09:12,  3.32s/it][A
      1%|          | 13/1261 [00:43<1:09:14,  3.33s/it][A
      1%|          | 14/1261 [00:46<1:09:12,  3.33s/it][A
      1%|          | 15/1261 [00:50<1:09:34,  3.35s/it][A
      1%|▏         | 16/1261 [00:53<1:09:33,  3.35s/it][A
      1%|▏         | 17/1261 [00:56<1:09:28,  3.35s/it][A
      1%|▏         | 18/1261 [01:00<1:09:16,  3.34s/it][A
      2%|▏         | 19/1261 [01:03<1:09:19,  3.35s/it][A
      2%|▏         | 20/1261 [01:06<1:09:17,  3.35s/it][A
      2%|▏         | 21/1261 [01:10<1:09:09,  3.35s/it][A
      2%|▏         | 22/1261 [01:13<1:08:52,  3.33s/it][A
      2%|▏         | 23/1261 [01:16<1:08:54,  3.34s/it][A
      2%|▏         | 24/1261 [01:20<1:09:03,  3.35s/it][A
      2%|▏         | 25/1261 [01:23<1:08:53,  3.34s/it][A
      2%|▏         | 26/1261 [01:26<1:08:48,  3.34s/it][A
      2%|▏         | 27/1261 [01:30<1:08:43,  3.34s/it][A
      2%|▏         | 28/1261 [01:33<1:08:51,  3.35s/it][A
      2%|▏         | 29/1261 [01:36<1:08:40,  3.34s/it][A
      2%|▏         | 30/1261 [01:40<1:08:30,  3.34s/it][A
      2%|▏         | 31/1261 [01:43<1:08:30,  3.34s/it][A
      3%|▎         | 32/1261 [01:46<1:08:28,  3.34s/it][A
      3%|▎         | 33/1261 [01:50<1:08:24,  3.34s/it][A
      3%|▎         | 34/1261 [01:53<1:08:27,  3.35s/it][A
      3%|▎         | 35/1261 [01:56<1:08:35,  3.36s/it][A
      3%|▎         | 36/1261 [02:00<1:08:32,  3.36s/it][A
      3%|▎         | 37/1261 [02:03<1:08:24,  3.35s/it][A
      3%|▎         | 38/1261 [02:06<1:08:10,  3.35s/it][A
      3%|▎         | 39/1261 [02:10<1:08:10,  3.35s/it][A
      3%|▎         | 40/1261 [02:13<1:08:03,  3.34s/it][A
      3%|▎         | 41/1261 [02:16<1:07:54,  3.34s/it][A
      3%|▎         | 42/1261 [02:20<1:07:54,  3.34s/it][A
      3%|▎         | 43/1261 [02:23<1:08:07,  3.36s/it][A
      3%|▎         | 44/1261 [02:27<1:07:54,  3.35s/it][A
      4%|▎         | 45/1261 [02:30<1:07:49,  3.35s/it][A
      4%|▎         | 46/1261 [02:33<1:07:47,  3.35s/it][A
      4%|▎         | 47/1261 [02:37<1:07:50,  3.35s/it][A
      4%|▍         | 48/1261 [02:40<1:07:37,  3.34s/it][A
      4%|▍         | 49/1261 [02:43<1:07:17,  3.33s/it][A
      4%|▍         | 50/1261 [02:47<1:07:39,  3.35s/it][A
      4%|▍         | 51/1261 [02:50<1:07:47,  3.36s/it][A
      4%|▍         | 52/1261 [02:53<1:07:31,  3.35s/it][A
      4%|▍         | 53/1261 [02:57<1:07:19,  3.34s/it][A
      4%|▍         | 54/1261 [03:00<1:07:22,  3.35s/it][A
      4%|▍         | 55/1261 [03:03<1:07:11,  3.34s/it][A
      4%|▍         | 56/1261 [03:07<1:06:53,  3.33s/it][A
      5%|▍         | 57/1261 [03:10<1:06:51,  3.33s/it][A
      5%|▍         | 58/1261 [03:13<1:06:58,  3.34s/it][A
      5%|▍         | 59/1261 [03:17<1:06:55,  3.34s/it][A
      5%|▍         | 60/1261 [03:20<1:07:03,  3.35s/it][A
      5%|▍         | 61/1261 [03:23<1:06:59,  3.35s/it][A
      5%|▍         | 62/1261 [03:27<1:06:51,  3.35s/it][A
      5%|▍         | 63/1261 [03:30<1:06:50,  3.35s/it][A
      5%|▌         | 64/1261 [03:33<1:06:47,  3.35s/it][A
      5%|▌         | 65/1261 [03:37<1:06:44,  3.35s/it][A
      5%|▌         | 66/1261 [03:40<1:06:33,  3.34s/it][A
      5%|▌         | 67/1261 [03:44<1:06:47,  3.36s/it][A
      5%|▌         | 68/1261 [03:47<1:06:49,  3.36s/it][A
      5%|▌         | 69/1261 [03:50<1:07:04,  3.38s/it][A
      6%|▌         | 70/1261 [03:54<1:06:55,  3.37s/it][A
      6%|▌         | 71/1261 [03:57<1:06:47,  3.37s/it][A
      6%|▌         | 72/1261 [04:00<1:06:48,  3.37s/it][A
      6%|▌         | 73/1261 [04:04<1:06:48,  3.37s/it][A
      6%|▌         | 74/1261 [04:07<1:06:47,  3.38s/it][A
      6%|▌         | 75/1261 [04:11<1:06:39,  3.37s/it][A
      6%|▌         | 76/1261 [04:14<1:06:36,  3.37s/it][A
      6%|▌         | 77/1261 [04:17<1:06:31,  3.37s/it][A
      6%|▌         | 78/1261 [04:21<1:06:41,  3.38s/it][A
      6%|▋         | 79/1261 [04:24<1:06:24,  3.37s/it][A
      6%|▋         | 80/1261 [04:27<1:06:21,  3.37s/it][A
      6%|▋         | 81/1261 [04:31<1:06:22,  3.38s/it][A
      7%|▋         | 82/1261 [04:34<1:06:19,  3.38s/it][A
      7%|▋         | 83/1261 [04:38<1:06:12,  3.37s/it][A
      7%|▋         | 84/1261 [04:41<1:06:01,  3.37s/it][A
      7%|▋         | 85/1261 [04:44<1:05:47,  3.36s/it][A
      7%|▋         | 86/1261 [04:48<1:05:50,  3.36s/it][A
      7%|▋         | 87/1261 [04:51<1:05:47,  3.36s/it][A
      7%|▋         | 88/1261 [04:54<1:05:47,  3.37s/it][A
      7%|▋         | 89/1261 [04:58<1:05:47,  3.37s/it][A
      7%|▋         | 90/1261 [05:01<1:05:17,  3.35s/it][A
      7%|▋         | 91/1261 [05:04<1:04:52,  3.33s/it][A
      7%|▋         | 92/1261 [05:08<1:04:50,  3.33s/it][A
      7%|▋         | 93/1261 [05:11<1:04:49,  3.33s/it][A
      7%|▋         | 94/1261 [05:14<1:04:55,  3.34s/it][A
      8%|▊         | 95/1261 [05:18<1:04:54,  3.34s/it][A
      8%|▊         | 96/1261 [05:21<1:04:49,  3.34s/it][A
      8%|▊         | 97/1261 [05:24<1:04:46,  3.34s/it][A
      8%|▊         | 98/1261 [05:28<1:04:41,  3.34s/it][A
      8%|▊         | 99/1261 [05:31<1:04:51,  3.35s/it][A
      8%|▊         | 100/1261 [05:34<1:04:45,  3.35s/it][A
      8%|▊         | 101/1261 [05:38<1:04:36,  3.34s/it][A
      8%|▊         | 102/1261 [05:41<1:04:22,  3.33s/it][A
      8%|▊         | 103/1261 [05:44<1:04:38,  3.35s/it][A
      8%|▊         | 104/1261 [05:48<1:04:38,  3.35s/it][A
      8%|▊         | 105/1261 [05:51<1:04:25,  3.34s/it][A
      8%|▊         | 106/1261 [05:54<1:04:36,  3.36s/it][A
      8%|▊         | 107/1261 [05:58<1:04:37,  3.36s/it][A
      9%|▊         | 108/1261 [06:01<1:04:27,  3.35s/it][A
      9%|▊         | 109/1261 [06:05<1:04:33,  3.36s/it][A
      9%|▊         | 110/1261 [06:08<1:04:33,  3.37s/it][A
      9%|▉         | 111/1261 [06:11<1:04:26,  3.36s/it][A
      9%|▉         | 112/1261 [06:15<1:04:29,  3.37s/it][A
      9%|▉         | 113/1261 [06:18<1:04:09,  3.35s/it][A
      9%|▉         | 114/1261 [06:21<1:04:21,  3.37s/it][A
      9%|▉         | 115/1261 [06:25<1:04:20,  3.37s/it][A
      9%|▉         | 116/1261 [06:28<1:03:59,  3.35s/it][A
      9%|▉         | 117/1261 [06:31<1:03:53,  3.35s/it][A
      9%|▉         | 118/1261 [06:35<1:03:49,  3.35s/it][A
      9%|▉         | 119/1261 [06:38<1:03:41,  3.35s/it][A
     10%|▉         | 120/1261 [06:41<1:03:45,  3.35s/it][A
     10%|▉         | 121/1261 [06:45<1:04:06,  3.37s/it][A
     10%|▉         | 122/1261 [06:48<1:03:59,  3.37s/it][A
     10%|▉         | 123/1261 [06:52<1:04:00,  3.37s/it][A
     10%|▉         | 124/1261 [06:55<1:03:44,  3.36s/it][A
     10%|▉         | 125/1261 [06:58<1:03:40,  3.36s/it][A
     10%|▉         | 126/1261 [07:02<1:03:29,  3.36s/it][A
     10%|█         | 127/1261 [07:05<1:03:32,  3.36s/it][A
     10%|█         | 128/1261 [07:08<1:03:36,  3.37s/it][A
     10%|█         | 129/1261 [07:12<1:03:22,  3.36s/it][A
     10%|█         | 130/1261 [07:15<1:03:30,  3.37s/it][A
     10%|█         | 131/1261 [07:19<1:03:29,  3.37s/it][A
     10%|█         | 132/1261 [07:22<1:03:22,  3.37s/it][A
     11%|█         | 133/1261 [07:25<1:02:58,  3.35s/it][A
     11%|█         | 134/1261 [07:29<1:03:00,  3.35s/it][A
     11%|█         | 135/1261 [07:32<1:02:45,  3.34s/it][A
     11%|█         | 136/1261 [07:35<1:02:55,  3.36s/it][A
     11%|█         | 137/1261 [07:39<1:02:55,  3.36s/it][A
     11%|█         | 138/1261 [07:42<1:02:43,  3.35s/it][A
     11%|█         | 139/1261 [07:45<1:02:45,  3.36s/it][A
     11%|█         | 140/1261 [07:49<1:02:41,  3.36s/it][A
     11%|█         | 141/1261 [07:52<1:02:36,  3.35s/it][A
     11%|█▏        | 142/1261 [07:55<1:02:34,  3.36s/it][A
     11%|█▏        | 143/1261 [07:59<1:02:33,  3.36s/it][A
     11%|█▏        | 144/1261 [08:02<1:02:35,  3.36s/it][A
     11%|█▏        | 145/1261 [08:06<1:02:35,  3.37s/it][A
     12%|█▏        | 146/1261 [08:09<1:02:27,  3.36s/it][A
     12%|█▏        | 147/1261 [08:12<1:02:35,  3.37s/it][A
     12%|█▏        | 148/1261 [08:16<1:02:25,  3.37s/it][A
     12%|█▏        | 149/1261 [08:19<1:02:23,  3.37s/it][A
     12%|█▏        | 150/1261 [08:22<1:02:31,  3.38s/it][A
     12%|█▏        | 151/1261 [08:26<1:02:32,  3.38s/it][A
     12%|█▏        | 152/1261 [08:29<1:02:27,  3.38s/it][A
     12%|█▏        | 153/1261 [08:32<1:02:09,  3.37s/it][A
     12%|█▏        | 154/1261 [08:36<1:02:07,  3.37s/it][A
     12%|█▏        | 155/1261 [08:39<1:02:08,  3.37s/it][A
     12%|█▏        | 156/1261 [08:43<1:02:06,  3.37s/it][A
     12%|█▏        | 157/1261 [08:46<1:01:58,  3.37s/it][A
     13%|█▎        | 158/1261 [08:49<1:02:05,  3.38s/it][A
     13%|█▎        | 159/1261 [08:53<1:01:47,  3.36s/it][A
     13%|█▎        | 160/1261 [08:56<1:01:51,  3.37s/it][A
     13%|█▎        | 161/1261 [08:59<1:01:51,  3.37s/it][A
     13%|█▎        | 162/1261 [09:03<1:02:09,  3.39s/it][A
     13%|█▎        | 163/1261 [09:06<1:02:01,  3.39s/it][A
     13%|█▎        | 164/1261 [09:10<1:02:00,  3.39s/it][A
     13%|█▎        | 165/1261 [09:13<1:01:43,  3.38s/it][A
     13%|█▎        | 166/1261 [09:16<1:01:25,  3.37s/it][A
     13%|█▎        | 167/1261 [09:20<1:01:10,  3.36s/it][A
     13%|█▎        | 168/1261 [09:23<1:01:02,  3.35s/it][A
     13%|█▎        | 169/1261 [09:26<1:00:57,  3.35s/it][A
     13%|█▎        | 170/1261 [09:30<1:00:54,  3.35s/it][A
     14%|█▎        | 171/1261 [09:33<1:01:05,  3.36s/it][A
     14%|█▎        | 172/1261 [09:36<1:01:00,  3.36s/it][A
     14%|█▎        | 173/1261 [09:40<1:00:49,  3.35s/it][A
     14%|█▍        | 174/1261 [09:43<1:00:37,  3.35s/it][A
     14%|█▍        | 175/1261 [09:46<1:00:28,  3.34s/it][A
     14%|█▍        | 176/1261 [09:50<1:00:21,  3.34s/it][A
     14%|█▍        | 177/1261 [09:53<1:00:24,  3.34s/it][A
     14%|█▍        | 178/1261 [09:57<1:00:17,  3.34s/it][A
     14%|█▍        | 179/1261 [10:00<1:00:19,  3.35s/it][A
     14%|█▍        | 180/1261 [10:03<1:00:20,  3.35s/it][A
     14%|█▍        | 181/1261 [10:07<1:00:33,  3.36s/it][A
     14%|█▍        | 182/1261 [10:10<1:00:26,  3.36s/it][A
     15%|█▍        | 183/1261 [10:13<1:00:13,  3.35s/it][A
     15%|█▍        | 184/1261 [10:17<1:00:19,  3.36s/it][A
     15%|█▍        | 185/1261 [10:20<1:00:08,  3.35s/it][A
     15%|█▍        | 186/1261 [10:23<1:00:11,  3.36s/it][A
     15%|█▍        | 187/1261 [10:27<1:00:20,  3.37s/it][A
     15%|█▍        | 188/1261 [10:30<1:00:19,  3.37s/it][A
     15%|█▍        | 189/1261 [10:34<1:00:17,  3.37s/it][A
     15%|█▌        | 190/1261 [10:37<1:00:07,  3.37s/it][A
     15%|█▌        | 191/1261 [10:40<59:53,  3.36s/it]  [A
     15%|█▌        | 192/1261 [10:44<59:51,  3.36s/it][A
     15%|█▌        | 193/1261 [10:47<59:44,  3.36s/it][A
     15%|█▌        | 194/1261 [10:50<59:58,  3.37s/it][A
     15%|█▌        | 195/1261 [10:54<59:51,  3.37s/it][A
     16%|█▌        | 196/1261 [10:57<59:39,  3.36s/it][A
     16%|█▌        | 197/1261 [11:00<59:24,  3.35s/it][A
     16%|█▌        | 198/1261 [11:04<59:16,  3.35s/it][A
     16%|█▌        | 199/1261 [11:07<59:05,  3.34s/it][A
     16%|█▌        | 200/1261 [11:10<59:00,  3.34s/it][A
     16%|█▌        | 201/1261 [11:14<59:07,  3.35s/it][A
     16%|█▌        | 202/1261 [11:17<58:57,  3.34s/it][A
     16%|█▌        | 203/1261 [11:20<58:54,  3.34s/it][A
     16%|█▌        | 204/1261 [11:24<58:56,  3.35s/it][A
     16%|█▋        | 205/1261 [11:27<59:00,  3.35s/it][A
     16%|█▋        | 206/1261 [11:30<58:46,  3.34s/it][A
     16%|█▋        | 207/1261 [11:34<58:56,  3.35s/it][A
     16%|█▋        | 208/1261 [11:37<58:47,  3.35s/it][A
     17%|█▋        | 209/1261 [11:41<58:47,  3.35s/it][A
     17%|█▋        | 210/1261 [11:44<58:58,  3.37s/it][A
     17%|█▋        | 211/1261 [11:47<59:01,  3.37s/it][A
     17%|█▋        | 212/1261 [11:51<59:15,  3.39s/it][A
     17%|█▋        | 213/1261 [11:54<58:59,  3.38s/it][A
     17%|█▋        | 214/1261 [11:57<58:45,  3.37s/it][A
     17%|█▋        | 215/1261 [12:01<58:36,  3.36s/it][A
     17%|█▋        | 216/1261 [12:04<58:27,  3.36s/it][A
     17%|█▋        | 217/1261 [12:08<58:34,  3.37s/it][A
     17%|█▋        | 218/1261 [12:11<58:20,  3.36s/it][A
     17%|█▋        | 219/1261 [12:14<58:06,  3.35s/it][A
     17%|█▋        | 220/1261 [12:18<57:56,  3.34s/it][A
     18%|█▊        | 221/1261 [12:21<57:57,  3.34s/it][A
     18%|█▊        | 222/1261 [12:24<58:00,  3.35s/it][A
     18%|█▊        | 223/1261 [12:28<57:54,  3.35s/it][A
     18%|█▊        | 224/1261 [12:31<57:59,  3.36s/it][A
     18%|█▊        | 225/1261 [12:34<57:59,  3.36s/it][A
     18%|█▊        | 226/1261 [12:38<58:04,  3.37s/it][A
     18%|█▊        | 227/1261 [12:41<57:51,  3.36s/it][A
     18%|█▊        | 228/1261 [12:44<58:03,  3.37s/it][A
     18%|█▊        | 229/1261 [12:48<57:54,  3.37s/it][A
     18%|█▊        | 230/1261 [12:51<57:39,  3.36s/it][A
     18%|█▊        | 231/1261 [12:54<57:37,  3.36s/it][A
     18%|█▊        | 232/1261 [12:58<57:14,  3.34s/it][A
     18%|█▊        | 233/1261 [13:01<57:06,  3.33s/it][A
     19%|█▊        | 234/1261 [13:04<57:09,  3.34s/it][A
     19%|█▊        | 235/1261 [13:08<57:10,  3.34s/it][A
     19%|█▊        | 236/1261 [13:11<57:01,  3.34s/it][A
     19%|█▉        | 237/1261 [13:14<56:51,  3.33s/it][A
     19%|█▉        | 238/1261 [13:18<56:36,  3.32s/it][A
     19%|█▉        | 239/1261 [13:21<56:41,  3.33s/it][A
     19%|█▉        | 240/1261 [13:24<56:49,  3.34s/it][A
     19%|█▉        | 241/1261 [13:28<56:57,  3.35s/it][A
     19%|█▉        | 242/1261 [13:31<56:54,  3.35s/it][A
     19%|█▉        | 243/1261 [13:35<57:06,  3.37s/it][A
     19%|█▉        | 244/1261 [13:38<56:52,  3.36s/it][A
     19%|█▉        | 245/1261 [13:41<56:57,  3.36s/it][A
     20%|█▉        | 246/1261 [13:45<56:49,  3.36s/it][A
     20%|█▉        | 247/1261 [13:48<56:42,  3.36s/it][A
     20%|█▉        | 248/1261 [13:51<56:29,  3.35s/it][A
     20%|█▉        | 249/1261 [13:55<56:31,  3.35s/it][A
     20%|█▉        | 250/1261 [13:58<56:28,  3.35s/it][A
     20%|█▉        | 251/1261 [14:01<56:29,  3.36s/it][A
     20%|█▉        | 252/1261 [14:05<56:26,  3.36s/it][A
     20%|██        | 253/1261 [14:08<56:25,  3.36s/it][A
     20%|██        | 254/1261 [14:11<56:15,  3.35s/it][A
     20%|██        | 255/1261 [14:15<56:09,  3.35s/it][A
     20%|██        | 256/1261 [14:18<56:05,  3.35s/it][A
     20%|██        | 257/1261 [14:22<56:04,  3.35s/it][A
     20%|██        | 258/1261 [14:25<55:55,  3.35s/it][A
     21%|██        | 259/1261 [14:28<55:34,  3.33s/it][A
     21%|██        | 260/1261 [14:32<55:46,  3.34s/it][A
     21%|██        | 261/1261 [14:35<55:47,  3.35s/it][A
     21%|██        | 262/1261 [14:38<55:49,  3.35s/it][A
     21%|██        | 263/1261 [14:42<55:46,  3.35s/it][A
     21%|██        | 264/1261 [14:45<55:41,  3.35s/it][A
     21%|██        | 265/1261 [14:48<55:34,  3.35s/it][A
     21%|██        | 266/1261 [14:52<55:27,  3.34s/it][A
     21%|██        | 267/1261 [14:55<55:18,  3.34s/it][A
     21%|██▏       | 268/1261 [14:58<55:12,  3.34s/it][A
     21%|██▏       | 269/1261 [15:02<55:15,  3.34s/it][A
     21%|██▏       | 270/1261 [15:05<55:14,  3.34s/it][A
     21%|██▏       | 271/1261 [15:08<55:02,  3.34s/it][A
     22%|██▏       | 272/1261 [15:12<55:04,  3.34s/it][A
     22%|██▏       | 273/1261 [15:15<55:10,  3.35s/it][A
     22%|██▏       | 274/1261 [15:18<55:18,  3.36s/it][A
     22%|██▏       | 275/1261 [15:22<55:24,  3.37s/it][A
     22%|██▏       | 276/1261 [15:25<55:17,  3.37s/it][A
     22%|██▏       | 277/1261 [15:29<55:16,  3.37s/it][A
     22%|██▏       | 278/1261 [15:32<54:52,  3.35s/it][A
     22%|██▏       | 279/1261 [15:35<54:37,  3.34s/it][A
     22%|██▏       | 280/1261 [15:39<54:48,  3.35s/it][A
     22%|██▏       | 281/1261 [15:42<54:44,  3.35s/it][A
     22%|██▏       | 282/1261 [15:45<54:52,  3.36s/it][A
     22%|██▏       | 283/1261 [15:49<54:49,  3.36s/it][A
     23%|██▎       | 284/1261 [15:52<54:50,  3.37s/it][A
     23%|██▎       | 285/1261 [15:55<54:47,  3.37s/it][A
     23%|██▎       | 286/1261 [15:59<54:39,  3.36s/it][A
     23%|██▎       | 287/1261 [16:02<54:32,  3.36s/it][A
     23%|██▎       | 288/1261 [16:05<54:28,  3.36s/it][A
     23%|██▎       | 289/1261 [16:09<54:16,  3.35s/it][A
     23%|██▎       | 290/1261 [16:12<54:08,  3.35s/it][A
     23%|██▎       | 291/1261 [16:16<54:20,  3.36s/it][A
     23%|██▎       | 292/1261 [16:19<54:27,  3.37s/it][A
     23%|██▎       | 293/1261 [16:22<54:28,  3.38s/it][A
     23%|██▎       | 294/1261 [16:26<54:29,  3.38s/it][A
     23%|██▎       | 295/1261 [16:29<54:26,  3.38s/it][A
     23%|██▎       | 296/1261 [16:32<54:18,  3.38s/it][A
     24%|██▎       | 297/1261 [16:36<54:17,  3.38s/it][A
     24%|██▎       | 298/1261 [16:39<54:19,  3.38s/it][A
     24%|██▎       | 299/1261 [16:43<54:12,  3.38s/it][A
     24%|██▍       | 300/1261 [16:46<54:15,  3.39s/it][A
     24%|██▍       | 301/1261 [16:49<54:26,  3.40s/it][A
     24%|██▍       | 302/1261 [16:53<54:18,  3.40s/it][A
     24%|██▍       | 303/1261 [16:56<54:11,  3.39s/it][A
     24%|██▍       | 304/1261 [17:00<53:54,  3.38s/it][A
     24%|██▍       | 305/1261 [17:03<54:04,  3.39s/it][A
     24%|██▍       | 306/1261 [17:06<53:48,  3.38s/it][A
     24%|██▍       | 307/1261 [17:10<53:34,  3.37s/it][A
     24%|██▍       | 308/1261 [17:13<53:26,  3.36s/it][A
     25%|██▍       | 309/1261 [17:16<53:20,  3.36s/it][A
     25%|██▍       | 310/1261 [17:20<53:23,  3.37s/it][A
     25%|██▍       | 311/1261 [17:23<53:12,  3.36s/it][A
     25%|██▍       | 312/1261 [17:26<53:18,  3.37s/it][A
     25%|██▍       | 313/1261 [17:30<53:01,  3.36s/it][A
     25%|██▍       | 314/1261 [17:33<52:55,  3.35s/it][A
     25%|██▍       | 315/1261 [17:37<52:55,  3.36s/it][A
     25%|██▌       | 316/1261 [17:40<52:56,  3.36s/it][A
     25%|██▌       | 317/1261 [17:43<52:59,  3.37s/it][A
     25%|██▌       | 318/1261 [17:47<52:45,  3.36s/it][A
     25%|██▌       | 319/1261 [17:50<52:51,  3.37s/it][A
     25%|██▌       | 320/1261 [17:53<52:47,  3.37s/it][A
     25%|██▌       | 321/1261 [17:57<52:52,  3.38s/it][A
     26%|██▌       | 322/1261 [18:00<52:37,  3.36s/it][A
     26%|██▌       | 323/1261 [18:03<52:41,  3.37s/it][A
     26%|██▌       | 324/1261 [18:07<52:53,  3.39s/it][A
     26%|██▌       | 325/1261 [18:10<52:53,  3.39s/it][A
     26%|██▌       | 326/1261 [18:14<52:46,  3.39s/it][A
     26%|██▌       | 327/1261 [18:17<52:32,  3.38s/it][A
     26%|██▌       | 328/1261 [18:20<52:28,  3.37s/it][A
     26%|██▌       | 329/1261 [18:24<52:21,  3.37s/it][A
     26%|██▌       | 330/1261 [18:27<52:22,  3.37s/it][A
     26%|██▌       | 331/1261 [18:31<52:14,  3.37s/it][A
     26%|██▋       | 332/1261 [18:34<52:02,  3.36s/it][A
     26%|██▋       | 333/1261 [18:37<52:00,  3.36s/it][A
     26%|██▋       | 334/1261 [18:41<51:56,  3.36s/it][A
     27%|██▋       | 335/1261 [18:44<51:53,  3.36s/it][A
     27%|██▋       | 336/1261 [18:47<51:55,  3.37s/it][A
     27%|██▋       | 337/1261 [18:51<51:58,  3.38s/it][A
     27%|██▋       | 338/1261 [18:54<51:47,  3.37s/it][A
     27%|██▋       | 339/1261 [18:57<51:42,  3.37s/it][A
     27%|██▋       | 340/1261 [19:01<51:46,  3.37s/it][A
     27%|██▋       | 341/1261 [19:04<51:32,  3.36s/it][A
     27%|██▋       | 342/1261 [19:08<51:27,  3.36s/it][A
     27%|██▋       | 343/1261 [19:11<51:24,  3.36s/it][A
     27%|██▋       | 344/1261 [19:14<51:22,  3.36s/it][A
     27%|██▋       | 345/1261 [19:18<51:26,  3.37s/it][A
     27%|██▋       | 346/1261 [19:21<51:18,  3.36s/it][A
     28%|██▊       | 347/1261 [19:24<51:19,  3.37s/it][A
     28%|██▊       | 348/1261 [19:28<51:18,  3.37s/it][A
     28%|██▊       | 349/1261 [19:31<51:13,  3.37s/it][A
     28%|██▊       | 350/1261 [19:34<51:14,  3.37s/it][A
     28%|██▊       | 351/1261 [19:38<51:06,  3.37s/it][A
     28%|██▊       | 352/1261 [19:41<50:55,  3.36s/it][A
     28%|██▊       | 353/1261 [19:45<50:57,  3.37s/it][A
     28%|██▊       | 354/1261 [19:48<50:51,  3.36s/it][A
     28%|██▊       | 355/1261 [19:51<50:47,  3.36s/it][A
     28%|██▊       | 356/1261 [19:55<50:30,  3.35s/it][A
     28%|██▊       | 357/1261 [19:58<50:12,  3.33s/it][A
     28%|██▊       | 358/1261 [20:01<50:09,  3.33s/it][A
     28%|██▊       | 359/1261 [20:05<50:08,  3.34s/it][A
     29%|██▊       | 360/1261 [20:08<50:06,  3.34s/it][A
     29%|██▊       | 361/1261 [20:11<50:14,  3.35s/it][A
     29%|██▊       | 362/1261 [20:15<50:08,  3.35s/it][A
     29%|██▉       | 363/1261 [20:18<50:05,  3.35s/it][A
     29%|██▉       | 364/1261 [20:21<50:06,  3.35s/it][A
     29%|██▉       | 365/1261 [20:25<50:02,  3.35s/it][A
     29%|██▉       | 366/1261 [20:28<49:56,  3.35s/it][A
     29%|██▉       | 367/1261 [20:31<49:57,  3.35s/it][A
     29%|██▉       | 368/1261 [20:35<49:56,  3.36s/it][A
     29%|██▉       | 369/1261 [20:38<49:48,  3.35s/it][A
     29%|██▉       | 370/1261 [20:42<50:03,  3.37s/it][A
     29%|██▉       | 371/1261 [20:45<50:03,  3.37s/it][A
     30%|██▉       | 372/1261 [20:48<50:01,  3.38s/it][A
     30%|██▉       | 373/1261 [20:52<50:02,  3.38s/it][A
     30%|██▉       | 374/1261 [20:55<50:05,  3.39s/it][A
     30%|██▉       | 375/1261 [20:58<49:42,  3.37s/it][A
     30%|██▉       | 376/1261 [21:02<49:47,  3.38s/it][A
     30%|██▉       | 377/1261 [21:05<49:32,  3.36s/it][A
     30%|██▉       | 378/1261 [21:09<49:37,  3.37s/it][A
     30%|███       | 379/1261 [21:12<49:33,  3.37s/it][A
     30%|███       | 380/1261 [21:15<49:25,  3.37s/it][A
     30%|███       | 381/1261 [21:19<49:20,  3.36s/it][A
     30%|███       | 382/1261 [21:22<49:12,  3.36s/it][A
     30%|███       | 383/1261 [21:25<49:05,  3.35s/it][A
     30%|███       | 384/1261 [21:29<49:00,  3.35s/it][A
     31%|███       | 385/1261 [21:32<48:53,  3.35s/it][A
     31%|███       | 386/1261 [21:35<48:54,  3.35s/it][A
     31%|███       | 387/1261 [21:39<48:38,  3.34s/it][A
     31%|███       | 388/1261 [21:42<48:45,  3.35s/it][A
     31%|███       | 389/1261 [21:45<48:48,  3.36s/it][A
     31%|███       | 390/1261 [21:49<48:46,  3.36s/it][A
     31%|███       | 391/1261 [21:52<48:33,  3.35s/it][A
     31%|███       | 392/1261 [21:55<48:24,  3.34s/it][A
     31%|███       | 393/1261 [21:59<48:23,  3.35s/it][A
     31%|███       | 394/1261 [22:02<48:23,  3.35s/it][A
     31%|███▏      | 395/1261 [22:05<48:20,  3.35s/it][A
     31%|███▏      | 396/1261 [22:09<48:26,  3.36s/it][A
     31%|███▏      | 397/1261 [22:12<48:19,  3.36s/it][A
     32%|███▏      | 398/1261 [22:16<48:05,  3.34s/it][A
     32%|███▏      | 399/1261 [22:19<48:10,  3.35s/it][A
     32%|███▏      | 400/1261 [22:22<48:07,  3.35s/it][A
     32%|███▏      | 401/1261 [22:26<48:08,  3.36s/it][A
     32%|███▏      | 402/1261 [22:29<47:50,  3.34s/it][A
     32%|███▏      | 403/1261 [22:32<47:51,  3.35s/it][A
     32%|███▏      | 404/1261 [22:36<47:53,  3.35s/it][A
     32%|███▏      | 405/1261 [22:39<47:38,  3.34s/it][A
     32%|███▏      | 406/1261 [22:42<47:34,  3.34s/it][A
     32%|███▏      | 407/1261 [22:46<47:38,  3.35s/it][A
     32%|███▏      | 408/1261 [22:49<47:51,  3.37s/it][A
     32%|███▏      | 409/1261 [22:52<47:55,  3.37s/it][A
     33%|███▎      | 410/1261 [22:56<47:51,  3.37s/it][A
     33%|███▎      | 411/1261 [22:59<47:43,  3.37s/it][A
     33%|███▎      | 412/1261 [23:03<47:44,  3.37s/it][A
     33%|███▎      | 413/1261 [23:06<47:39,  3.37s/it][A
     33%|███▎      | 414/1261 [23:09<47:35,  3.37s/it][A
     33%|███▎      | 415/1261 [23:13<47:26,  3.36s/it][A
     33%|███▎      | 416/1261 [23:16<47:18,  3.36s/it][A
     33%|███▎      | 417/1261 [23:19<47:14,  3.36s/it][A
     33%|███▎      | 418/1261 [23:23<47:09,  3.36s/it][A
     33%|███▎      | 419/1261 [23:26<47:27,  3.38s/it][A
     33%|███▎      | 420/1261 [23:30<47:36,  3.40s/it][A
     33%|███▎      | 421/1261 [23:33<47:31,  3.39s/it][A
     33%|███▎      | 422/1261 [23:36<47:18,  3.38s/it][A
     34%|███▎      | 423/1261 [23:40<47:06,  3.37s/it][A
     34%|███▎      | 424/1261 [23:43<47:08,  3.38s/it][A
     34%|███▎      | 425/1261 [23:46<46:56,  3.37s/it][A
     34%|███▍      | 426/1261 [23:50<46:56,  3.37s/it][A
     34%|███▍      | 427/1261 [23:53<46:48,  3.37s/it][A
     34%|███▍      | 428/1261 [23:57<46:43,  3.37s/it][A
     34%|███▍      | 429/1261 [24:00<46:35,  3.36s/it][A
     34%|███▍      | 430/1261 [24:03<46:31,  3.36s/it][A
     34%|███▍      | 431/1261 [24:07<46:23,  3.35s/it][A
     34%|███▍      | 432/1261 [24:10<46:13,  3.35s/it][A
     34%|███▍      | 433/1261 [24:13<46:03,  3.34s/it][A
     34%|███▍      | 434/1261 [24:17<46:00,  3.34s/it][A
     34%|███▍      | 435/1261 [24:20<46:03,  3.35s/it][A
     35%|███▍      | 436/1261 [24:23<46:11,  3.36s/it][A
     35%|███▍      | 437/1261 [24:27<46:19,  3.37s/it][A
     35%|███▍      | 438/1261 [24:30<46:18,  3.38s/it][A
     35%|███▍      | 439/1261 [24:33<46:14,  3.38s/it][A
     35%|███▍      | 440/1261 [24:37<46:02,  3.37s/it][A
     35%|███▍      | 441/1261 [24:40<45:55,  3.36s/it][A
     35%|███▌      | 442/1261 [24:44<45:51,  3.36s/it][A
     35%|███▌      | 443/1261 [24:47<45:47,  3.36s/it][A
     35%|███▌      | 444/1261 [24:50<45:48,  3.36s/it][A
     35%|███▌      | 445/1261 [24:54<45:48,  3.37s/it][A
     35%|███▌      | 446/1261 [24:57<45:44,  3.37s/it][A
     35%|███▌      | 447/1261 [25:00<45:34,  3.36s/it][A
     36%|███▌      | 448/1261 [25:04<45:29,  3.36s/it][A
     36%|███▌      | 449/1261 [25:07<45:28,  3.36s/it][A
     36%|███▌      | 450/1261 [25:10<45:24,  3.36s/it][A
     36%|███▌      | 451/1261 [25:14<45:26,  3.37s/it][A
     36%|███▌      | 452/1261 [25:17<45:26,  3.37s/it][A
     36%|███▌      | 453/1261 [25:21<45:16,  3.36s/it][A
     36%|███▌      | 454/1261 [25:24<45:04,  3.35s/it][A
     36%|███▌      | 455/1261 [25:27<45:00,  3.35s/it][A
     36%|███▌      | 456/1261 [25:31<45:02,  3.36s/it][A
     36%|███▌      | 457/1261 [25:34<45:03,  3.36s/it][A
     36%|███▋      | 458/1261 [25:37<45:02,  3.37s/it][A
     36%|███▋      | 459/1261 [25:41<44:57,  3.36s/it][A
     36%|███▋      | 460/1261 [25:44<44:51,  3.36s/it][A
     37%|███▋      | 461/1261 [25:47<44:51,  3.36s/it][A
     37%|███▋      | 462/1261 [25:51<44:50,  3.37s/it][A
     37%|███▋      | 463/1261 [25:54<44:42,  3.36s/it][A
     37%|███▋      | 464/1261 [25:57<44:30,  3.35s/it][A
     37%|███▋      | 465/1261 [26:01<44:21,  3.34s/it][A
     37%|███▋      | 466/1261 [26:04<44:14,  3.34s/it][A
     37%|███▋      | 467/1261 [26:07<44:24,  3.36s/it][A
     37%|███▋      | 468/1261 [26:11<44:29,  3.37s/it][A
     37%|███▋      | 469/1261 [26:14<44:25,  3.37s/it][A
     37%|███▋      | 470/1261 [26:18<44:19,  3.36s/it][A
     37%|███▋      | 471/1261 [26:21<44:17,  3.36s/it][A
     37%|███▋      | 472/1261 [26:24<44:15,  3.37s/it][A
     38%|███▊      | 473/1261 [26:28<44:08,  3.36s/it][A
     38%|███▊      | 474/1261 [26:31<44:13,  3.37s/it][A
     38%|███▊      | 475/1261 [26:34<44:15,  3.38s/it][A
     38%|███▊      | 476/1261 [26:38<44:15,  3.38s/it][A
     38%|███▊      | 477/1261 [26:41<44:13,  3.39s/it][A
     38%|███▊      | 478/1261 [26:45<43:58,  3.37s/it][A
     38%|███▊      | 479/1261 [26:48<44:08,  3.39s/it][A
     38%|███▊      | 480/1261 [26:51<44:04,  3.39s/it][A
     38%|███▊      | 481/1261 [26:55<43:59,  3.38s/it][A
     38%|███▊      | 482/1261 [26:58<43:47,  3.37s/it][A
     38%|███▊      | 483/1261 [27:02<43:46,  3.38s/it][A
     38%|███▊      | 484/1261 [27:05<43:43,  3.38s/it][A
     38%|███▊      | 485/1261 [27:08<43:41,  3.38s/it][A
     39%|███▊      | 486/1261 [27:12<43:37,  3.38s/it][A
     39%|███▊      | 487/1261 [27:15<43:21,  3.36s/it][A
     39%|███▊      | 488/1261 [27:18<43:14,  3.36s/it][A
     39%|███▉      | 489/1261 [27:22<43:19,  3.37s/it][A
     39%|███▉      | 490/1261 [27:25<43:14,  3.37s/it][A
     39%|███▉      | 491/1261 [27:28<43:04,  3.36s/it][A
     39%|███▉      | 492/1261 [27:32<43:11,  3.37s/it][A
     39%|███▉      | 493/1261 [27:35<43:02,  3.36s/it][A
     39%|███▉      | 494/1261 [27:39<43:03,  3.37s/it][A
     39%|███▉      | 495/1261 [27:42<43:06,  3.38s/it][A
     39%|███▉      | 496/1261 [27:45<43:05,  3.38s/it][A
     39%|███▉      | 497/1261 [27:49<42:55,  3.37s/it][A
     39%|███▉      | 498/1261 [27:52<42:48,  3.37s/it][A
     40%|███▉      | 499/1261 [27:55<42:43,  3.36s/it][A
     40%|███▉      | 500/1261 [27:59<42:45,  3.37s/it][A
     40%|███▉      | 501/1261 [28:02<42:39,  3.37s/it][A
     40%|███▉      | 502/1261 [28:05<42:32,  3.36s/it][A
     40%|███▉      | 503/1261 [28:09<42:23,  3.36s/it][A
     40%|███▉      | 504/1261 [28:12<42:18,  3.35s/it][A
     40%|████      | 505/1261 [28:16<42:07,  3.34s/it][A
     40%|████      | 506/1261 [28:19<42:06,  3.35s/it][A
     40%|████      | 507/1261 [28:22<42:00,  3.34s/it][A
     40%|████      | 508/1261 [28:25<41:49,  3.33s/it][A
     40%|████      | 509/1261 [28:29<41:39,  3.32s/it][A
     40%|████      | 510/1261 [28:32<41:43,  3.33s/it][A
     41%|████      | 511/1261 [28:35<41:40,  3.33s/it][A
     41%|████      | 512/1261 [28:39<41:40,  3.34s/it][A
     41%|████      | 513/1261 [28:42<41:39,  3.34s/it][A
     41%|████      | 514/1261 [28:46<41:34,  3.34s/it][A
     41%|████      | 515/1261 [28:49<41:46,  3.36s/it][A
     41%|████      | 516/1261 [28:52<41:40,  3.36s/it][A
     41%|████      | 517/1261 [28:56<41:32,  3.35s/it][A
     41%|████      | 518/1261 [28:59<41:13,  3.33s/it][A
     41%|████      | 519/1261 [29:02<41:21,  3.34s/it][A
     41%|████      | 520/1261 [29:06<41:23,  3.35s/it][A
     41%|████▏     | 521/1261 [29:09<41:25,  3.36s/it][A
     41%|████▏     | 522/1261 [29:12<41:19,  3.36s/it][A
     41%|████▏     | 523/1261 [29:16<41:20,  3.36s/it][A
     42%|████▏     | 524/1261 [29:19<41:14,  3.36s/it][A
     42%|████▏     | 525/1261 [29:22<41:11,  3.36s/it][A
     42%|████▏     | 526/1261 [29:26<41:06,  3.36s/it][A
     42%|████▏     | 527/1261 [29:29<41:03,  3.36s/it][A
     42%|████▏     | 528/1261 [29:32<40:48,  3.34s/it][A
     42%|████▏     | 529/1261 [29:36<40:44,  3.34s/it][A
     42%|████▏     | 530/1261 [29:39<40:40,  3.34s/it][A
     42%|████▏     | 531/1261 [29:42<40:41,  3.34s/it][A
     42%|████▏     | 532/1261 [29:46<40:34,  3.34s/it][A
     42%|████▏     | 533/1261 [29:49<40:28,  3.34s/it][A
     42%|████▏     | 534/1261 [29:52<40:19,  3.33s/it][A
     42%|████▏     | 535/1261 [29:56<40:16,  3.33s/it][A
     43%|████▎     | 536/1261 [29:59<40:10,  3.32s/it][A
     43%|████▎     | 537/1261 [30:02<40:12,  3.33s/it][A
     43%|████▎     | 538/1261 [30:06<40:15,  3.34s/it][A
     43%|████▎     | 539/1261 [30:09<40:11,  3.34s/it][A
     43%|████▎     | 540/1261 [30:13<40:11,  3.34s/it][A
     43%|████▎     | 541/1261 [30:16<40:10,  3.35s/it][A
     43%|████▎     | 542/1261 [30:19<40:05,  3.35s/it][A
     43%|████▎     | 543/1261 [30:23<40:03,  3.35s/it][A
     43%|████▎     | 544/1261 [30:26<40:07,  3.36s/it][A
     43%|████▎     | 545/1261 [30:29<40:01,  3.35s/it][A
     43%|████▎     | 546/1261 [30:33<39:57,  3.35s/it][A
     43%|████▎     | 547/1261 [30:36<39:44,  3.34s/it][A
     43%|████▎     | 548/1261 [30:39<39:43,  3.34s/it][A
     44%|████▎     | 549/1261 [30:43<39:40,  3.34s/it][A
     44%|████▎     | 550/1261 [30:46<39:33,  3.34s/it][A
     44%|████▎     | 551/1261 [30:49<39:38,  3.35s/it][A
     44%|████▍     | 552/1261 [30:53<39:39,  3.36s/it][A
     44%|████▍     | 553/1261 [30:56<39:32,  3.35s/it][A
     44%|████▍     | 554/1261 [30:59<39:38,  3.36s/it][A
     44%|████▍     | 555/1261 [31:03<39:26,  3.35s/it][A
     44%|████▍     | 556/1261 [31:06<39:28,  3.36s/it][A
     44%|████▍     | 557/1261 [31:10<39:27,  3.36s/it][A
     44%|████▍     | 558/1261 [31:13<39:26,  3.37s/it][A
     44%|████▍     | 559/1261 [31:16<39:22,  3.37s/it][A
     44%|████▍     | 560/1261 [31:20<39:21,  3.37s/it][A
     44%|████▍     | 561/1261 [31:23<39:17,  3.37s/it][A
     45%|████▍     | 562/1261 [31:26<39:15,  3.37s/it][A
     45%|████▍     | 563/1261 [31:30<39:12,  3.37s/it][A
     45%|████▍     | 564/1261 [31:33<39:10,  3.37s/it][A
     45%|████▍     | 565/1261 [31:36<38:54,  3.35s/it][A
     45%|████▍     | 566/1261 [31:40<38:52,  3.36s/it][A
     45%|████▍     | 567/1261 [31:43<38:45,  3.35s/it][A
     45%|████▌     | 568/1261 [31:46<38:43,  3.35s/it][A
     45%|████▌     | 569/1261 [31:50<38:39,  3.35s/it][A
     45%|████▌     | 570/1261 [31:53<38:41,  3.36s/it][A
     45%|████▌     | 571/1261 [31:57<38:41,  3.36s/it][A
     45%|████▌     | 572/1261 [32:00<38:42,  3.37s/it][A
     45%|████▌     | 573/1261 [32:03<38:25,  3.35s/it][A
     46%|████▌     | 574/1261 [32:07<38:23,  3.35s/it][A
     46%|████▌     | 575/1261 [32:10<38:11,  3.34s/it][A
     46%|████▌     | 576/1261 [32:13<38:12,  3.35s/it][A
     46%|████▌     | 577/1261 [32:17<38:01,  3.34s/it][A
     46%|████▌     | 578/1261 [32:20<37:55,  3.33s/it][A
     46%|████▌     | 579/1261 [32:23<37:58,  3.34s/it][A
     46%|████▌     | 580/1261 [32:27<37:51,  3.34s/it][A
     46%|████▌     | 581/1261 [32:30<37:50,  3.34s/it][A
     46%|████▌     | 582/1261 [32:33<37:52,  3.35s/it][A
     46%|████▌     | 583/1261 [32:37<37:51,  3.35s/it][A
     46%|████▋     | 584/1261 [32:40<37:53,  3.36s/it][A
     46%|████▋     | 585/1261 [32:43<37:47,  3.35s/it][A
     46%|████▋     | 586/1261 [32:47<37:44,  3.35s/it][A
     47%|████▋     | 587/1261 [32:50<37:45,  3.36s/it][A
     47%|████▋     | 588/1261 [32:54<37:46,  3.37s/it][A
     47%|████▋     | 589/1261 [32:57<37:44,  3.37s/it][A
     47%|████▋     | 590/1261 [33:00<37:33,  3.36s/it][A
     47%|████▋     | 591/1261 [33:04<37:32,  3.36s/it][A
     47%|████▋     | 592/1261 [33:07<37:31,  3.37s/it][A
     47%|████▋     | 593/1261 [33:10<37:30,  3.37s/it][A
     47%|████▋     | 594/1261 [33:14<37:23,  3.36s/it][A
     47%|████▋     | 595/1261 [33:17<37:18,  3.36s/it][A
     47%|████▋     | 596/1261 [33:20<37:18,  3.37s/it][A
     47%|████▋     | 597/1261 [33:24<37:15,  3.37s/it][A
     47%|████▋     | 598/1261 [33:27<37:03,  3.35s/it][A
     48%|████▊     | 599/1261 [33:30<36:55,  3.35s/it][A
     48%|████▊     | 600/1261 [33:34<36:57,  3.35s/it][A
     48%|████▊     | 601/1261 [33:37<36:45,  3.34s/it][A
     48%|████▊     | 602/1261 [33:40<36:39,  3.34s/it][A
     48%|████▊     | 603/1261 [33:44<36:37,  3.34s/it][A
     48%|████▊     | 604/1261 [33:47<36:32,  3.34s/it][A
     48%|████▊     | 605/1261 [33:51<36:46,  3.36s/it][A
     48%|████▊     | 606/1261 [33:54<36:44,  3.37s/it][A
     48%|████▊     | 607/1261 [33:57<36:38,  3.36s/it][A
     48%|████▊     | 608/1261 [34:01<36:32,  3.36s/it][A
     48%|████▊     | 609/1261 [34:04<36:27,  3.36s/it][A
     48%|████▊     | 610/1261 [34:07<36:15,  3.34s/it][A
     48%|████▊     | 611/1261 [34:11<36:15,  3.35s/it][A
     49%|████▊     | 612/1261 [34:14<36:07,  3.34s/it][A
     49%|████▊     | 613/1261 [34:17<36:08,  3.35s/it][A
     49%|████▊     | 614/1261 [34:21<36:08,  3.35s/it][A
     49%|████▉     | 615/1261 [34:24<36:08,  3.36s/it][A
     49%|████▉     | 616/1261 [34:27<35:55,  3.34s/it][A
     49%|████▉     | 617/1261 [34:31<35:45,  3.33s/it][A
     49%|████▉     | 618/1261 [34:34<35:45,  3.34s/it][A
     49%|████▉     | 619/1261 [34:37<35:43,  3.34s/it][A
     49%|████▉     | 620/1261 [34:41<35:46,  3.35s/it][A
     49%|████▉     | 621/1261 [34:44<35:39,  3.34s/it][A
     49%|████▉     | 622/1261 [34:47<35:44,  3.36s/it][A
     49%|████▉     | 623/1261 [34:51<35:47,  3.37s/it][A
     49%|████▉     | 624/1261 [34:54<35:48,  3.37s/it][A
     50%|████▉     | 625/1261 [34:58<35:36,  3.36s/it][A
     50%|████▉     | 626/1261 [35:01<35:31,  3.36s/it][A
     50%|████▉     | 627/1261 [35:04<35:23,  3.35s/it][A
     50%|████▉     | 628/1261 [35:08<35:20,  3.35s/it][A
     50%|████▉     | 629/1261 [35:11<35:14,  3.35s/it][A
     50%|████▉     | 630/1261 [35:14<35:18,  3.36s/it][A
     50%|█████     | 631/1261 [35:18<35:13,  3.35s/it][A
     50%|█████     | 632/1261 [35:21<35:07,  3.35s/it][A
     50%|█████     | 633/1261 [35:24<35:03,  3.35s/it][A
     50%|█████     | 634/1261 [35:28<35:00,  3.35s/it][A
     50%|█████     | 635/1261 [35:31<34:53,  3.34s/it][A
     50%|█████     | 636/1261 [35:34<34:46,  3.34s/it][A
     51%|█████     | 637/1261 [35:38<34:40,  3.33s/it][A
     51%|█████     | 638/1261 [35:41<34:36,  3.33s/it][A
     51%|█████     | 639/1261 [35:44<34:29,  3.33s/it][A
     51%|█████     | 640/1261 [35:48<34:24,  3.32s/it][A
     51%|█████     | 641/1261 [35:51<34:22,  3.33s/it][A
     51%|█████     | 642/1261 [35:54<34:24,  3.34s/it][A
     51%|█████     | 643/1261 [35:58<34:23,  3.34s/it][A
     51%|█████     | 644/1261 [36:01<34:17,  3.33s/it][A
     51%|█████     | 645/1261 [36:04<34:15,  3.34s/it][A
     51%|█████     | 646/1261 [36:08<34:20,  3.35s/it][A
     51%|█████▏    | 647/1261 [36:11<34:16,  3.35s/it][A
     51%|█████▏    | 648/1261 [36:14<34:08,  3.34s/it][A
     51%|█████▏    | 649/1261 [36:18<34:08,  3.35s/it][A
     52%|█████▏    | 650/1261 [36:21<34:11,  3.36s/it][A
     52%|█████▏    | 651/1261 [36:25<34:03,  3.35s/it][A
     52%|█████▏    | 652/1261 [36:28<34:04,  3.36s/it][A
     52%|█████▏    | 653/1261 [36:31<34:07,  3.37s/it][A
     52%|█████▏    | 654/1261 [36:35<34:02,  3.37s/it][A
     52%|█████▏    | 655/1261 [36:38<33:59,  3.36s/it][A
     52%|█████▏    | 656/1261 [36:41<33:54,  3.36s/it][A
     52%|█████▏    | 657/1261 [36:45<33:53,  3.37s/it][A
     52%|█████▏    | 658/1261 [36:48<33:47,  3.36s/it][A
     52%|█████▏    | 659/1261 [36:51<33:39,  3.35s/it][A
     52%|█████▏    | 660/1261 [36:55<33:29,  3.34s/it][A
     52%|█████▏    | 661/1261 [36:58<33:32,  3.35s/it][A
     52%|█████▏    | 662/1261 [37:01<33:25,  3.35s/it][A
     53%|█████▎    | 663/1261 [37:05<33:20,  3.35s/it][A
     53%|█████▎    | 664/1261 [37:08<33:14,  3.34s/it][A
     53%|█████▎    | 665/1261 [37:11<33:12,  3.34s/it][A
     53%|█████▎    | 666/1261 [37:15<33:08,  3.34s/it][A
     53%|█████▎    | 667/1261 [37:18<33:09,  3.35s/it][A
     53%|█████▎    | 668/1261 [37:21<32:59,  3.34s/it][A
     53%|█████▎    | 669/1261 [37:25<32:55,  3.34s/it][A
     53%|█████▎    | 670/1261 [37:28<32:48,  3.33s/it][A
     53%|█████▎    | 671/1261 [37:31<32:49,  3.34s/it][A
     53%|█████▎    | 672/1261 [37:35<32:45,  3.34s/it][A
     53%|█████▎    | 673/1261 [37:38<32:48,  3.35s/it][A
     53%|█████▎    | 674/1261 [37:42<32:42,  3.34s/it][A
     54%|█████▎    | 675/1261 [37:45<32:45,  3.35s/it][A
     54%|█████▎    | 676/1261 [37:48<32:51,  3.37s/it][A
     54%|█████▎    | 677/1261 [37:52<32:40,  3.36s/it][A
     54%|█████▍    | 678/1261 [37:55<32:36,  3.36s/it][A
     54%|█████▍    | 679/1261 [37:58<32:38,  3.36s/it][A
     54%|█████▍    | 680/1261 [38:02<32:31,  3.36s/it][A
     54%|█████▍    | 681/1261 [38:05<32:22,  3.35s/it][A
     54%|█████▍    | 682/1261 [38:08<32:15,  3.34s/it][A
     54%|█████▍    | 683/1261 [38:12<32:16,  3.35s/it][A
     54%|█████▍    | 684/1261 [38:15<32:09,  3.34s/it][A
     54%|█████▍    | 685/1261 [38:18<31:57,  3.33s/it][A
     54%|█████▍    | 686/1261 [38:22<31:56,  3.33s/it][A
     54%|█████▍    | 687/1261 [38:25<31:48,  3.32s/it][A
     55%|█████▍    | 688/1261 [38:28<31:43,  3.32s/it][A
     55%|█████▍    | 689/1261 [38:32<31:45,  3.33s/it][A
     55%|█████▍    | 690/1261 [38:35<31:46,  3.34s/it][A
     55%|█████▍    | 691/1261 [38:38<31:39,  3.33s/it][A
     55%|█████▍    | 692/1261 [38:42<31:42,  3.34s/it][A
     55%|█████▍    | 693/1261 [38:45<31:42,  3.35s/it][A
     55%|█████▌    | 694/1261 [38:49<31:50,  3.37s/it][A
     55%|█████▌    | 695/1261 [38:52<31:47,  3.37s/it][A
     55%|█████▌    | 696/1261 [38:55<31:35,  3.36s/it][A
     55%|█████▌    | 697/1261 [38:59<31:35,  3.36s/it][A
     55%|█████▌    | 698/1261 [39:02<31:28,  3.35s/it][A
     55%|█████▌    | 699/1261 [39:05<31:24,  3.35s/it][A
     56%|█████▌    | 700/1261 [39:09<31:11,  3.34s/it][A
     56%|█████▌    | 701/1261 [39:12<31:09,  3.34s/it][A
     56%|█████▌    | 702/1261 [39:15<31:00,  3.33s/it][A
     56%|█████▌    | 703/1261 [39:19<31:05,  3.34s/it][A
     56%|█████▌    | 704/1261 [39:22<30:55,  3.33s/it][A
     56%|█████▌    | 705/1261 [39:25<31:02,  3.35s/it][A
     56%|█████▌    | 706/1261 [39:29<31:01,  3.35s/it][A
     56%|█████▌    | 707/1261 [39:32<31:03,  3.36s/it][A
     56%|█████▌    | 708/1261 [39:35<31:00,  3.37s/it][A
     56%|█████▌    | 709/1261 [39:39<30:57,  3.37s/it][A
     56%|█████▋    | 710/1261 [39:42<30:56,  3.37s/it][A
     56%|█████▋    | 711/1261 [39:45<30:47,  3.36s/it][A
     56%|█████▋    | 712/1261 [39:49<30:40,  3.35s/it][A
     57%|█████▋    | 713/1261 [39:52<30:32,  3.34s/it][A
     57%|█████▋    | 714/1261 [39:56<30:30,  3.35s/it][A
     57%|█████▋    | 715/1261 [39:59<30:19,  3.33s/it][A
     57%|█████▋    | 716/1261 [40:02<30:17,  3.33s/it][A
     57%|█████▋    | 717/1261 [40:06<30:22,  3.35s/it][A
     57%|█████▋    | 718/1261 [40:09<30:23,  3.36s/it][A
     57%|█████▋    | 719/1261 [40:12<30:18,  3.36s/it][A
     57%|█████▋    | 720/1261 [40:16<30:03,  3.33s/it][A
     57%|█████▋    | 721/1261 [40:19<29:58,  3.33s/it][A
     57%|█████▋    | 722/1261 [40:22<29:50,  3.32s/it][A
     57%|█████▋    | 723/1261 [40:26<29:56,  3.34s/it][A
     57%|█████▋    | 724/1261 [40:29<29:50,  3.33s/it][A
     57%|█████▋    | 725/1261 [40:32<29:39,  3.32s/it][A
     58%|█████▊    | 726/1261 [40:35<29:38,  3.32s/it][A
     58%|█████▊    | 727/1261 [40:39<29:41,  3.34s/it][A
     58%|█████▊    | 728/1261 [40:42<29:42,  3.34s/it][A
     58%|█████▊    | 729/1261 [40:46<29:40,  3.35s/it][A
     58%|█████▊    | 730/1261 [40:49<29:43,  3.36s/it][A
     58%|█████▊    | 731/1261 [40:52<29:39,  3.36s/it][A
     58%|█████▊    | 732/1261 [40:56<29:34,  3.35s/it][A
     58%|█████▊    | 733/1261 [40:59<29:35,  3.36s/it][A
     58%|█████▊    | 734/1261 [41:02<29:28,  3.36s/it][A
     58%|█████▊    | 735/1261 [41:06<29:28,  3.36s/it][A
     58%|█████▊    | 736/1261 [41:09<29:17,  3.35s/it][A
     58%|█████▊    | 737/1261 [41:12<29:14,  3.35s/it][A
     59%|█████▊    | 738/1261 [41:16<29:09,  3.35s/it][A
     59%|█████▊    | 739/1261 [41:19<29:03,  3.34s/it][A
     59%|█████▊    | 740/1261 [41:22<28:59,  3.34s/it][A
     59%|█████▉    | 741/1261 [41:26<28:57,  3.34s/it][A
     59%|█████▉    | 742/1261 [41:29<28:52,  3.34s/it][A
     59%|█████▉    | 743/1261 [41:32<28:48,  3.34s/it][A
     59%|█████▉    | 744/1261 [41:36<28:43,  3.33s/it][A
     59%|█████▉    | 745/1261 [41:39<28:40,  3.33s/it][A
     59%|█████▉    | 746/1261 [41:42<28:36,  3.33s/it][A
     59%|█████▉    | 747/1261 [41:46<28:38,  3.34s/it][A
     59%|█████▉    | 748/1261 [41:49<28:33,  3.34s/it][A
     59%|█████▉    | 749/1261 [41:52<28:26,  3.33s/it][A
     59%|█████▉    | 750/1261 [41:56<28:28,  3.34s/it][A
     60%|█████▉    | 751/1261 [41:59<28:28,  3.35s/it][A
     60%|█████▉    | 752/1261 [42:02<28:18,  3.34s/it][A
     60%|█████▉    | 753/1261 [42:06<28:19,  3.35s/it][A
     60%|█████▉    | 754/1261 [42:09<28:15,  3.34s/it][A
     60%|█████▉    | 755/1261 [42:13<28:16,  3.35s/it][A
     60%|█████▉    | 756/1261 [42:16<28:09,  3.35s/it][A
     60%|██████    | 757/1261 [42:19<28:07,  3.35s/it][A
     60%|██████    | 758/1261 [42:23<28:07,  3.36s/it][A
     60%|██████    | 759/1261 [42:26<28:00,  3.35s/it][A
     60%|██████    | 760/1261 [42:29<28:02,  3.36s/it][A
     60%|██████    | 761/1261 [42:33<27:57,  3.35s/it][A
     60%|██████    | 762/1261 [42:36<27:59,  3.37s/it][A
     61%|██████    | 763/1261 [42:39<27:51,  3.36s/it][A
     61%|██████    | 764/1261 [42:43<27:48,  3.36s/it][A
     61%|██████    | 765/1261 [42:46<27:45,  3.36s/it][A
     61%|██████    | 766/1261 [42:49<27:44,  3.36s/it][A
     61%|██████    | 767/1261 [42:53<27:40,  3.36s/it][A
     61%|██████    | 768/1261 [42:56<27:32,  3.35s/it][A
     61%|██████    | 769/1261 [42:59<27:24,  3.34s/it][A
     61%|██████    | 770/1261 [43:03<27:24,  3.35s/it][A
     61%|██████    | 771/1261 [43:06<27:19,  3.35s/it][A
     61%|██████    | 772/1261 [43:10<27:17,  3.35s/it][A
     61%|██████▏   | 773/1261 [43:13<27:10,  3.34s/it][A
     61%|██████▏   | 774/1261 [43:16<27:07,  3.34s/it][A
     61%|██████▏   | 775/1261 [43:20<27:00,  3.33s/it][A
     62%|██████▏   | 776/1261 [43:23<27:00,  3.34s/it][A
     62%|██████▏   | 777/1261 [43:26<26:51,  3.33s/it][A
     62%|██████▏   | 778/1261 [43:30<26:52,  3.34s/it][A
     62%|██████▏   | 779/1261 [43:33<26:49,  3.34s/it][A
     62%|██████▏   | 780/1261 [43:36<26:48,  3.34s/it][A
     62%|██████▏   | 781/1261 [43:40<26:44,  3.34s/it][A
     62%|██████▏   | 782/1261 [43:43<26:36,  3.33s/it][A
     62%|██████▏   | 783/1261 [43:46<26:39,  3.35s/it][A
     62%|██████▏   | 784/1261 [43:50<26:44,  3.36s/it][A
     62%|██████▏   | 785/1261 [43:53<26:35,  3.35s/it][A
     62%|██████▏   | 786/1261 [43:56<26:31,  3.35s/it][A
     62%|██████▏   | 787/1261 [44:00<26:21,  3.34s/it][A
     62%|██████▏   | 788/1261 [44:03<26:15,  3.33s/it][A
     63%|██████▎   | 789/1261 [44:06<26:18,  3.34s/it][A
     63%|██████▎   | 790/1261 [44:10<26:19,  3.35s/it][A
     63%|██████▎   | 791/1261 [44:13<26:16,  3.35s/it][A
     63%|██████▎   | 792/1261 [44:16<26:14,  3.36s/it][A
     63%|██████▎   | 793/1261 [44:20<26:13,  3.36s/it][A
     63%|██████▎   | 794/1261 [44:23<26:10,  3.36s/it][A
     63%|██████▎   | 795/1261 [44:27<26:05,  3.36s/it][A
     63%|██████▎   | 796/1261 [44:30<25:52,  3.34s/it][A
     63%|██████▎   | 797/1261 [44:33<25:48,  3.34s/it][A
     63%|██████▎   | 798/1261 [44:36<25:44,  3.34s/it][A
     63%|██████▎   | 799/1261 [44:40<25:47,  3.35s/it][A
     63%|██████▎   | 800/1261 [44:43<25:47,  3.36s/it][A
     64%|██████▎   | 801/1261 [44:47<25:47,  3.36s/it][A
     64%|██████▎   | 802/1261 [44:50<25:50,  3.38s/it][A
     64%|██████▎   | 803/1261 [44:53<25:45,  3.38s/it][A
     64%|██████▍   | 804/1261 [44:57<25:40,  3.37s/it][A
     64%|██████▍   | 805/1261 [45:00<25:35,  3.37s/it][A
     64%|██████▍   | 806/1261 [45:04<25:33,  3.37s/it][A
     64%|██████▍   | 807/1261 [45:07<25:34,  3.38s/it][A
     64%|██████▍   | 808/1261 [45:10<25:25,  3.37s/it][A
     64%|██████▍   | 809/1261 [45:14<25:22,  3.37s/it][A
     64%|██████▍   | 810/1261 [45:17<25:20,  3.37s/it][A
     64%|██████▍   | 811/1261 [45:20<25:16,  3.37s/it][A
     64%|██████▍   | 812/1261 [45:24<25:11,  3.37s/it][A
     64%|██████▍   | 813/1261 [45:27<25:05,  3.36s/it][A
     65%|██████▍   | 814/1261 [45:30<25:00,  3.36s/it][A
     65%|██████▍   | 815/1261 [45:34<24:54,  3.35s/it][A
     65%|██████▍   | 816/1261 [45:37<24:47,  3.34s/it][A
     65%|██████▍   | 817/1261 [45:40<24:45,  3.35s/it][A
     65%|██████▍   | 818/1261 [45:44<24:44,  3.35s/it][A
     65%|██████▍   | 819/1261 [45:47<24:34,  3.34s/it][A
     65%|██████▌   | 820/1261 [45:50<24:32,  3.34s/it][A
     65%|██████▌   | 821/1261 [45:54<24:33,  3.35s/it][A
     65%|██████▌   | 822/1261 [45:57<24:24,  3.34s/it][A
     65%|██████▌   | 823/1261 [46:00<24:25,  3.35s/it][A
     65%|██████▌   | 824/1261 [46:04<24:25,  3.35s/it][A
     65%|██████▌   | 825/1261 [46:07<24:15,  3.34s/it][A
     66%|██████▌   | 826/1261 [46:10<24:10,  3.33s/it][A
     66%|██████▌   | 827/1261 [46:14<24:05,  3.33s/it][A
     66%|██████▌   | 828/1261 [46:17<24:05,  3.34s/it][A
     66%|██████▌   | 829/1261 [46:20<23:52,  3.32s/it][A
     66%|██████▌   | 830/1261 [46:24<23:53,  3.33s/it][A
     66%|██████▌   | 831/1261 [46:27<23:50,  3.33s/it][A
     66%|██████▌   | 832/1261 [46:30<23:47,  3.33s/it][A
     66%|██████▌   | 833/1261 [46:34<23:44,  3.33s/it][A
     66%|██████▌   | 834/1261 [46:37<23:44,  3.34s/it][A
     66%|██████▌   | 835/1261 [46:40<23:45,  3.35s/it][A
     66%|██████▋   | 836/1261 [46:44<23:44,  3.35s/it][A
     66%|██████▋   | 837/1261 [46:47<23:44,  3.36s/it][A
     66%|██████▋   | 838/1261 [46:51<23:47,  3.37s/it][A
     67%|██████▋   | 839/1261 [46:54<23:40,  3.37s/it][A
     67%|██████▋   | 840/1261 [46:57<23:42,  3.38s/it][A
     67%|██████▋   | 841/1261 [47:01<23:36,  3.37s/it][A
     67%|██████▋   | 842/1261 [47:04<23:33,  3.37s/it][A
     67%|██████▋   | 843/1261 [47:08<23:32,  3.38s/it][A
     67%|██████▋   | 844/1261 [47:11<23:31,  3.38s/it][A
     67%|██████▋   | 845/1261 [47:14<23:23,  3.37s/it][A
     67%|██████▋   | 846/1261 [47:18<23:16,  3.37s/it][A
     67%|██████▋   | 847/1261 [47:21<23:11,  3.36s/it][A
     67%|██████▋   | 848/1261 [47:24<23:11,  3.37s/it][A
     67%|██████▋   | 849/1261 [47:28<23:05,  3.36s/it][A
     67%|██████▋   | 850/1261 [47:31<23:01,  3.36s/it][A
     67%|██████▋   | 851/1261 [47:34<22:57,  3.36s/it][A
     68%|██████▊   | 852/1261 [47:38<22:51,  3.35s/it][A
     68%|██████▊   | 853/1261 [47:41<22:46,  3.35s/it][A
     68%|██████▊   | 854/1261 [47:44<22:44,  3.35s/it][A
     68%|██████▊   | 855/1261 [47:48<22:45,  3.36s/it][A
     68%|██████▊   | 856/1261 [47:51<22:42,  3.36s/it][A
     68%|██████▊   | 857/1261 [47:55<22:39,  3.37s/it][A
     68%|██████▊   | 858/1261 [47:58<22:39,  3.37s/it][A
     68%|██████▊   | 859/1261 [48:01<22:37,  3.38s/it][A
     68%|██████▊   | 860/1261 [48:05<22:33,  3.38s/it][A
     68%|██████▊   | 861/1261 [48:08<22:26,  3.37s/it][A
     68%|██████▊   | 862/1261 [48:11<22:20,  3.36s/it][A
     68%|██████▊   | 863/1261 [48:15<22:15,  3.36s/it][A
     69%|██████▊   | 864/1261 [48:18<22:14,  3.36s/it][A
     69%|██████▊   | 865/1261 [48:21<22:10,  3.36s/it][A
     69%|██████▊   | 866/1261 [48:25<22:07,  3.36s/it][A
     69%|██████▉   | 867/1261 [48:28<22:02,  3.36s/it][A
     69%|██████▉   | 868/1261 [48:32<22:00,  3.36s/it][A
     69%|██████▉   | 869/1261 [48:35<21:54,  3.35s/it][A
     69%|██████▉   | 870/1261 [48:38<21:51,  3.35s/it][A
     69%|██████▉   | 871/1261 [48:42<21:48,  3.36s/it][A
     69%|██████▉   | 872/1261 [48:45<21:42,  3.35s/it][A
     69%|██████▉   | 873/1261 [48:48<21:48,  3.37s/it][A
     69%|██████▉   | 874/1261 [48:52<21:49,  3.38s/it][A
     69%|██████▉   | 875/1261 [48:55<21:45,  3.38s/it][A
     69%|██████▉   | 876/1261 [48:59<21:40,  3.38s/it][A
     70%|██████▉   | 877/1261 [49:02<21:35,  3.37s/it][A
     70%|██████▉   | 878/1261 [49:05<21:31,  3.37s/it][A
     70%|██████▉   | 879/1261 [49:09<21:32,  3.38s/it][A
     70%|██████▉   | 880/1261 [49:12<21:22,  3.37s/it][A
     70%|██████▉   | 881/1261 [49:15<21:16,  3.36s/it][A
     70%|██████▉   | 882/1261 [49:19<21:15,  3.37s/it][A
     70%|███████   | 883/1261 [49:22<21:12,  3.37s/it][A
     70%|███████   | 884/1261 [49:25<21:09,  3.37s/it][A
     70%|███████   | 885/1261 [49:29<21:04,  3.36s/it][A
     70%|███████   | 886/1261 [49:32<20:51,  3.34s/it][A
     70%|███████   | 887/1261 [49:35<20:50,  3.34s/it][A
     70%|███████   | 888/1261 [49:39<20:45,  3.34s/it][A
     70%|███████   | 889/1261 [49:42<20:45,  3.35s/it][A
     71%|███████   | 890/1261 [49:45<20:40,  3.34s/it][A
     71%|███████   | 891/1261 [49:49<20:40,  3.35s/it][A
     71%|███████   | 892/1261 [49:52<20:38,  3.36s/it][A
     71%|███████   | 893/1261 [49:56<20:35,  3.36s/it][A
     71%|███████   | 894/1261 [49:59<20:28,  3.35s/it][A
     71%|███████   | 895/1261 [50:02<20:28,  3.36s/it][A
     71%|███████   | 896/1261 [50:06<20:27,  3.36s/it][A
     71%|███████   | 897/1261 [50:09<20:25,  3.37s/it][A
     71%|███████   | 898/1261 [50:12<20:22,  3.37s/it][A
     71%|███████▏  | 899/1261 [50:16<20:17,  3.36s/it][A
     71%|███████▏  | 900/1261 [50:19<20:10,  3.35s/it][A
     71%|███████▏  | 901/1261 [50:23<20:14,  3.37s/it][A
     72%|███████▏  | 902/1261 [50:26<20:13,  3.38s/it][A
     72%|███████▏  | 903/1261 [50:29<20:13,  3.39s/it][A
     72%|███████▏  | 904/1261 [50:33<20:03,  3.37s/it][A
     72%|███████▏  | 905/1261 [50:36<19:57,  3.36s/it][A
     72%|███████▏  | 906/1261 [50:39<19:55,  3.37s/it][A
     72%|███████▏  | 907/1261 [50:43<19:48,  3.36s/it][A
     72%|███████▏  | 908/1261 [50:46<19:47,  3.36s/it][A
     72%|███████▏  | 909/1261 [50:49<19:48,  3.38s/it][A
     72%|███████▏  | 910/1261 [50:53<19:38,  3.36s/it][A
     72%|███████▏  | 911/1261 [50:56<19:33,  3.35s/it][A
     72%|███████▏  | 912/1261 [50:59<19:30,  3.35s/it][A
     72%|███████▏  | 913/1261 [51:03<19:34,  3.38s/it][A
     72%|███████▏  | 914/1261 [51:06<19:30,  3.37s/it][A
     73%|███████▎  | 915/1261 [51:10<19:26,  3.37s/it][A
     73%|███████▎  | 916/1261 [51:13<19:17,  3.36s/it][A
     73%|███████▎  | 917/1261 [51:16<19:16,  3.36s/it][A
     73%|███████▎  | 918/1261 [51:20<19:13,  3.36s/it][A
     73%|███████▎  | 919/1261 [51:23<19:08,  3.36s/it][A
     73%|███████▎  | 920/1261 [51:26<19:06,  3.36s/it][A
     73%|███████▎  | 921/1261 [51:30<19:05,  3.37s/it][A
     73%|███████▎  | 922/1261 [51:33<19:04,  3.38s/it][A
     73%|███████▎  | 923/1261 [51:37<19:00,  3.38s/it][A
     73%|███████▎  | 924/1261 [51:40<18:51,  3.36s/it][A
     73%|███████▎  | 925/1261 [51:43<18:48,  3.36s/it][A
     73%|███████▎  | 926/1261 [51:47<18:42,  3.35s/it][A
     74%|███████▎  | 927/1261 [51:50<18:40,  3.35s/it][A
     74%|███████▎  | 928/1261 [51:53<18:39,  3.36s/it][A
     74%|███████▎  | 929/1261 [51:57<18:29,  3.34s/it][A
     74%|███████▍  | 930/1261 [52:00<18:25,  3.34s/it][A
     74%|███████▍  | 931/1261 [52:03<18:20,  3.34s/it][A
     74%|███████▍  | 932/1261 [52:07<18:21,  3.35s/it][A
     74%|███████▍  | 933/1261 [52:10<18:20,  3.36s/it][A
     74%|███████▍  | 934/1261 [52:13<18:16,  3.35s/it][A
     74%|███████▍  | 935/1261 [52:17<18:12,  3.35s/it][A
     74%|███████▍  | 936/1261 [52:20<18:07,  3.35s/it][A
     74%|███████▍  | 937/1261 [52:23<18:06,  3.35s/it][A
     74%|███████▍  | 938/1261 [52:27<18:03,  3.35s/it][A
     74%|███████▍  | 939/1261 [52:30<17:58,  3.35s/it][A
     75%|███████▍  | 940/1261 [52:33<17:55,  3.35s/it][A
     75%|███████▍  | 941/1261 [52:37<17:51,  3.35s/it][A
     75%|███████▍  | 942/1261 [52:40<17:49,  3.35s/it][A
     75%|███████▍  | 943/1261 [52:44<17:45,  3.35s/it][A
     75%|███████▍  | 944/1261 [52:47<17:43,  3.35s/it][A
     75%|███████▍  | 945/1261 [52:50<17:45,  3.37s/it][A
     75%|███████▌  | 946/1261 [52:54<17:43,  3.37s/it][A
     75%|███████▌  | 947/1261 [52:57<17:37,  3.37s/it][A
     75%|███████▌  | 948/1261 [53:00<17:32,  3.36s/it][A
     75%|███████▌  | 949/1261 [53:04<17:29,  3.36s/it][A
     75%|███████▌  | 950/1261 [53:07<17:26,  3.37s/it][A
     75%|███████▌  | 951/1261 [53:10<17:20,  3.36s/it][A
     75%|███████▌  | 952/1261 [53:14<17:15,  3.35s/it][A
     76%|███████▌  | 953/1261 [53:17<17:14,  3.36s/it][A
     76%|███████▌  | 954/1261 [53:21<17:14,  3.37s/it][A
     76%|███████▌  | 955/1261 [53:24<17:06,  3.35s/it][A
     76%|███████▌  | 956/1261 [53:27<17:02,  3.35s/it][A
     76%|███████▌  | 957/1261 [53:31<17:01,  3.36s/it][A
     76%|███████▌  | 958/1261 [53:34<17:00,  3.37s/it][A
     76%|███████▌  | 959/1261 [53:37<16:59,  3.37s/it][A
     76%|███████▌  | 960/1261 [53:41<16:52,  3.36s/it][A
     76%|███████▌  | 961/1261 [53:44<16:48,  3.36s/it][A
     76%|███████▋  | 962/1261 [53:47<16:46,  3.37s/it][A
     76%|███████▋  | 963/1261 [53:51<16:38,  3.35s/it][A
     76%|███████▋  | 964/1261 [53:54<16:38,  3.36s/it][A
     77%|███████▋  | 965/1261 [53:58<16:35,  3.36s/it][A
     77%|███████▋  | 966/1261 [54:01<16:32,  3.36s/it][A
     77%|███████▋  | 967/1261 [54:04<16:26,  3.36s/it][A
     77%|███████▋  | 968/1261 [54:08<16:21,  3.35s/it][A
     77%|███████▋  | 969/1261 [54:11<16:13,  3.33s/it][A
     77%|███████▋  | 970/1261 [54:14<16:16,  3.36s/it][A
     77%|███████▋  | 971/1261 [54:18<16:10,  3.34s/it][A
     77%|███████▋  | 972/1261 [54:21<16:07,  3.35s/it][A
     77%|███████▋  | 973/1261 [54:24<16:08,  3.36s/it][A
     77%|███████▋  | 974/1261 [54:28<16:05,  3.36s/it][A
     77%|███████▋  | 975/1261 [54:31<16:01,  3.36s/it][A
     77%|███████▋  | 976/1261 [54:34<15:56,  3.36s/it][A
     77%|███████▋  | 977/1261 [54:38<15:54,  3.36s/it][A
     78%|███████▊  | 978/1261 [54:41<15:51,  3.36s/it][A
     78%|███████▊  | 979/1261 [54:45<15:47,  3.36s/it][A
     78%|███████▊  | 980/1261 [54:48<15:46,  3.37s/it][A
     78%|███████▊  | 981/1261 [54:51<15:40,  3.36s/it][A
     78%|███████▊  | 982/1261 [54:55<15:37,  3.36s/it][A
     78%|███████▊  | 983/1261 [54:58<15:32,  3.35s/it][A
     78%|███████▊  | 984/1261 [55:01<15:28,  3.35s/it][A
     78%|███████▊  | 985/1261 [55:05<15:23,  3.35s/it][A
     78%|███████▊  | 986/1261 [55:08<15:21,  3.35s/it][A
     78%|███████▊  | 987/1261 [55:11<15:19,  3.36s/it][A
     78%|███████▊  | 988/1261 [55:15<15:18,  3.37s/it][A
     78%|███████▊  | 989/1261 [55:18<15:14,  3.36s/it][A
     79%|███████▊  | 990/1261 [55:21<15:09,  3.35s/it][A
     79%|███████▊  | 991/1261 [55:25<15:06,  3.36s/it][A
     79%|███████▊  | 992/1261 [55:28<15:00,  3.35s/it][A
     79%|███████▊  | 993/1261 [55:31<14:55,  3.34s/it][A
     79%|███████▉  | 994/1261 [55:35<14:52,  3.34s/it][A
     79%|███████▉  | 995/1261 [55:38<14:51,  3.35s/it][A
     79%|███████▉  | 996/1261 [55:42<14:50,  3.36s/it][A
     79%|███████▉  | 997/1261 [55:45<14:47,  3.36s/it][A
     79%|███████▉  | 998/1261 [55:48<14:47,  3.37s/it][A
     79%|███████▉  | 999/1261 [55:52<14:43,  3.37s/it][A
     79%|███████▉  | 1000/1261 [55:55<14:37,  3.36s/it][A
     79%|███████▉  | 1001/1261 [55:58<14:34,  3.36s/it][A
     79%|███████▉  | 1002/1261 [56:02<14:28,  3.35s/it][A
     80%|███████▉  | 1003/1261 [56:05<14:22,  3.34s/it][A
     80%|███████▉  | 1004/1261 [56:08<14:18,  3.34s/it][A
     80%|███████▉  | 1005/1261 [56:12<14:14,  3.34s/it][A
     80%|███████▉  | 1006/1261 [56:15<14:11,  3.34s/it][A
     80%|███████▉  | 1007/1261 [56:18<14:08,  3.34s/it][A
     80%|███████▉  | 1008/1261 [56:22<14:08,  3.35s/it][A
     80%|████████  | 1009/1261 [56:25<14:07,  3.36s/it][A
     80%|████████  | 1010/1261 [56:28<14:02,  3.36s/it][A
     80%|████████  | 1011/1261 [56:32<13:55,  3.34s/it][A
     80%|████████  | 1012/1261 [56:35<13:51,  3.34s/it][A
     80%|████████  | 1013/1261 [56:38<13:48,  3.34s/it][A
     80%|████████  | 1014/1261 [56:42<13:44,  3.34s/it][A
     80%|████████  | 1015/1261 [56:45<13:42,  3.34s/it][A
     81%|████████  | 1016/1261 [56:49<13:41,  3.35s/it][A
     81%|████████  | 1017/1261 [56:52<13:40,  3.36s/it][A
     81%|████████  | 1018/1261 [56:55<13:36,  3.36s/it][A
     81%|████████  | 1019/1261 [56:59<13:35,  3.37s/it][A
     81%|████████  | 1020/1261 [57:02<13:30,  3.37s/it][A
     81%|████████  | 1021/1261 [57:05<13:27,  3.37s/it][A
     81%|████████  | 1022/1261 [57:09<13:23,  3.36s/it][A
     81%|████████  | 1023/1261 [57:12<13:20,  3.36s/it][A
     81%|████████  | 1024/1261 [57:16<13:22,  3.39s/it][A
     81%|████████▏ | 1025/1261 [57:19<13:17,  3.38s/it][A
     81%|████████▏ | 1026/1261 [57:22<13:11,  3.37s/it][A
     81%|████████▏ | 1027/1261 [57:26<13:08,  3.37s/it][A
     82%|████████▏ | 1028/1261 [57:29<13:04,  3.37s/it][A
     82%|████████▏ | 1029/1261 [57:32<13:02,  3.37s/it][A
     82%|████████▏ | 1030/1261 [57:36<12:58,  3.37s/it][A
     82%|████████▏ | 1031/1261 [57:39<12:56,  3.37s/it][A
     82%|████████▏ | 1032/1261 [57:42<12:50,  3.37s/it][A
     82%|████████▏ | 1033/1261 [57:46<12:44,  3.35s/it][A
     82%|████████▏ | 1034/1261 [57:49<12:43,  3.36s/it][A
     82%|████████▏ | 1035/1261 [57:53<12:39,  3.36s/it][A
     82%|████████▏ | 1036/1261 [57:56<12:35,  3.36s/it][A
     82%|████████▏ | 1037/1261 [57:59<12:30,  3.35s/it][A
     82%|████████▏ | 1038/1261 [58:03<12:28,  3.36s/it][A
     82%|████████▏ | 1039/1261 [58:06<12:24,  3.35s/it][A
     82%|████████▏ | 1040/1261 [58:09<12:20,  3.35s/it][A
     83%|████████▎ | 1041/1261 [58:13<12:19,  3.36s/it][A
     83%|████████▎ | 1042/1261 [58:16<12:12,  3.35s/it][A
     83%|████████▎ | 1043/1261 [58:19<12:10,  3.35s/it][A
     83%|████████▎ | 1044/1261 [58:23<12:09,  3.36s/it][A
     83%|████████▎ | 1045/1261 [58:26<12:03,  3.35s/it][A
     83%|████████▎ | 1046/1261 [58:29<11:59,  3.35s/it][A
     83%|████████▎ | 1047/1261 [58:33<11:55,  3.34s/it][A
     83%|████████▎ | 1048/1261 [58:36<11:54,  3.36s/it][A
     83%|████████▎ | 1049/1261 [58:39<11:50,  3.35s/it][A
     83%|████████▎ | 1050/1261 [58:43<11:47,  3.35s/it][A
     83%|████████▎ | 1051/1261 [58:46<11:46,  3.37s/it][A
     83%|████████▎ | 1052/1261 [58:50<11:45,  3.37s/it][A
     84%|████████▎ | 1053/1261 [58:53<11:39,  3.36s/it][A
     84%|████████▎ | 1054/1261 [58:56<11:33,  3.35s/it][A
     84%|████████▎ | 1055/1261 [59:00<11:29,  3.35s/it][A
     84%|████████▎ | 1056/1261 [59:03<11:25,  3.35s/it][A
     84%|████████▍ | 1057/1261 [59:06<11:22,  3.35s/it][A
     84%|████████▍ | 1058/1261 [59:10<11:18,  3.34s/it][A
     84%|████████▍ | 1059/1261 [59:13<11:14,  3.34s/it][A
     84%|████████▍ | 1060/1261 [59:16<11:11,  3.34s/it][A
     84%|████████▍ | 1061/1261 [59:20<11:08,  3.34s/it][A
     84%|████████▍ | 1062/1261 [59:23<11:04,  3.34s/it][A
     84%|████████▍ | 1063/1261 [59:26<11:03,  3.35s/it][A
     84%|████████▍ | 1064/1261 [59:30<11:02,  3.36s/it][A
     84%|████████▍ | 1065/1261 [59:33<10:59,  3.36s/it][A
     85%|████████▍ | 1066/1261 [59:36<10:53,  3.35s/it][A
     85%|████████▍ | 1067/1261 [59:40<10:52,  3.36s/it][A
     85%|████████▍ | 1068/1261 [59:43<10:49,  3.37s/it][A
     85%|████████▍ | 1069/1261 [59:47<10:48,  3.38s/it][A
     85%|████████▍ | 1070/1261 [59:50<10:44,  3.38s/it][A
     85%|████████▍ | 1071/1261 [59:53<10:41,  3.37s/it][A
     85%|████████▌ | 1072/1261 [59:57<10:35,  3.36s/it][A
     85%|████████▌ | 1073/1261 [1:00:00<10:32,  3.37s/it][A
     85%|████████▌ | 1074/1261 [1:00:03<10:29,  3.36s/it][A
     85%|████████▌ | 1075/1261 [1:00:07<10:25,  3.36s/it][A
     85%|████████▌ | 1076/1261 [1:00:10<10:25,  3.38s/it][A
     85%|████████▌ | 1077/1261 [1:00:14<10:21,  3.38s/it][A
     85%|████████▌ | 1078/1261 [1:00:17<10:13,  3.35s/it][A
     86%|████████▌ | 1079/1261 [1:00:20<10:09,  3.35s/it][A
     86%|████████▌ | 1080/1261 [1:00:24<10:08,  3.36s/it][A
     86%|████████▌ | 1081/1261 [1:00:27<10:03,  3.35s/it][A
     86%|████████▌ | 1082/1261 [1:00:30<10:00,  3.35s/it][A
     86%|████████▌ | 1083/1261 [1:00:34<09:56,  3.35s/it][A
     86%|████████▌ | 1084/1261 [1:00:37<09:52,  3.35s/it][A
     86%|████████▌ | 1085/1261 [1:00:40<09:49,  3.35s/it][A
     86%|████████▌ | 1086/1261 [1:00:44<09:46,  3.35s/it][A
     86%|████████▌ | 1087/1261 [1:00:47<09:43,  3.35s/it][A
     86%|████████▋ | 1088/1261 [1:00:50<09:40,  3.36s/it][A
     86%|████████▋ | 1089/1261 [1:00:54<09:37,  3.35s/it][A
     86%|████████▋ | 1090/1261 [1:00:57<09:32,  3.35s/it][A
     87%|████████▋ | 1091/1261 [1:01:00<09:29,  3.35s/it][A
     87%|████████▋ | 1092/1261 [1:01:04<09:22,  3.33s/it][A
     87%|████████▋ | 1093/1261 [1:01:07<09:18,  3.32s/it][A
     87%|████████▋ | 1094/1261 [1:01:10<09:16,  3.33s/it][A
     87%|████████▋ | 1095/1261 [1:01:14<09:14,  3.34s/it][A
     87%|████████▋ | 1096/1261 [1:01:17<09:11,  3.34s/it][A
     87%|████████▋ | 1097/1261 [1:01:20<09:10,  3.36s/it][A
     87%|████████▋ | 1098/1261 [1:01:24<09:06,  3.35s/it][A
     87%|████████▋ | 1099/1261 [1:01:27<09:01,  3.34s/it][A
     87%|████████▋ | 1100/1261 [1:01:31<08:59,  3.35s/it][A
     87%|████████▋ | 1101/1261 [1:01:34<08:56,  3.35s/it][A
     87%|████████▋ | 1102/1261 [1:01:37<08:54,  3.36s/it][A
     87%|████████▋ | 1103/1261 [1:01:41<08:51,  3.36s/it][A
     88%|████████▊ | 1104/1261 [1:01:44<08:46,  3.35s/it][A
     88%|████████▊ | 1105/1261 [1:01:47<08:43,  3.36s/it][A
     88%|████████▊ | 1106/1261 [1:01:51<08:40,  3.36s/it][A
     88%|████████▊ | 1107/1261 [1:01:54<08:35,  3.35s/it][A
     88%|████████▊ | 1108/1261 [1:01:57<08:33,  3.36s/it][A
     88%|████████▊ | 1109/1261 [1:02:01<08:29,  3.35s/it][A
     88%|████████▊ | 1110/1261 [1:02:04<08:26,  3.35s/it][A
     88%|████████▊ | 1111/1261 [1:02:07<08:22,  3.35s/it][A
     88%|████████▊ | 1112/1261 [1:02:11<08:19,  3.35s/it][A
     88%|████████▊ | 1113/1261 [1:02:14<08:16,  3.36s/it][A
     88%|████████▊ | 1114/1261 [1:02:17<08:12,  3.35s/it][A
     88%|████████▊ | 1115/1261 [1:02:21<08:09,  3.35s/it][A
     89%|████████▊ | 1116/1261 [1:02:24<08:06,  3.35s/it][A
     89%|████████▊ | 1117/1261 [1:02:28<08:02,  3.35s/it][A
     89%|████████▊ | 1118/1261 [1:02:31<07:59,  3.36s/it][A
     89%|████████▊ | 1119/1261 [1:02:34<07:57,  3.36s/it][A
     89%|████████▉ | 1120/1261 [1:02:38<07:53,  3.36s/it][A
     89%|████████▉ | 1121/1261 [1:02:41<07:51,  3.36s/it][A
     89%|████████▉ | 1122/1261 [1:02:44<07:47,  3.37s/it][A
     89%|████████▉ | 1123/1261 [1:02:48<07:44,  3.37s/it][A
     89%|████████▉ | 1124/1261 [1:02:51<07:41,  3.37s/it][A
     89%|████████▉ | 1125/1261 [1:02:54<07:36,  3.36s/it][A
     89%|████████▉ | 1126/1261 [1:02:58<07:34,  3.37s/it][A
     89%|████████▉ | 1127/1261 [1:03:01<07:30,  3.36s/it][A
     89%|████████▉ | 1128/1261 [1:03:05<07:28,  3.37s/it][A
     90%|████████▉ | 1129/1261 [1:03:08<07:25,  3.37s/it][A
     90%|████████▉ | 1130/1261 [1:03:11<07:21,  3.37s/it][A
     90%|████████▉ | 1131/1261 [1:03:15<07:19,  3.38s/it][A
     90%|████████▉ | 1132/1261 [1:03:18<07:14,  3.37s/it][A
     90%|████████▉ | 1133/1261 [1:03:21<07:11,  3.37s/it][A
     90%|████████▉ | 1134/1261 [1:03:25<07:08,  3.37s/it][A
     90%|█████████ | 1135/1261 [1:03:28<07:04,  3.37s/it][A
     90%|█████████ | 1136/1261 [1:03:32<07:01,  3.38s/it][A
     90%|█████████ | 1137/1261 [1:03:35<06:59,  3.38s/it][A
     90%|█████████ | 1138/1261 [1:03:38<06:55,  3.38s/it][A
     90%|█████████ | 1139/1261 [1:03:42<06:52,  3.38s/it][A
     90%|█████████ | 1140/1261 [1:03:45<06:49,  3.38s/it][A
     90%|█████████ | 1141/1261 [1:03:48<06:43,  3.36s/it][A
     91%|█████████ | 1142/1261 [1:03:52<06:40,  3.36s/it][A
     91%|█████████ | 1143/1261 [1:03:55<06:36,  3.36s/it][A
     91%|█████████ | 1144/1261 [1:03:59<06:34,  3.37s/it][A
     91%|█████████ | 1145/1261 [1:04:02<06:30,  3.37s/it][A
     91%|█████████ | 1146/1261 [1:04:05<06:27,  3.37s/it][A
     91%|█████████ | 1147/1261 [1:04:09<06:23,  3.36s/it][A
     91%|█████████ | 1148/1261 [1:04:12<06:19,  3.36s/it][A
     91%|█████████ | 1149/1261 [1:04:15<06:16,  3.36s/it][A
     91%|█████████ | 1150/1261 [1:04:19<06:13,  3.36s/it][A
     91%|█████████▏| 1151/1261 [1:04:22<06:09,  3.36s/it][A
     91%|█████████▏| 1152/1261 [1:04:25<06:05,  3.35s/it][A
     91%|█████████▏| 1153/1261 [1:04:29<06:01,  3.34s/it][A
     92%|█████████▏| 1154/1261 [1:04:32<05:56,  3.34s/it][A
     92%|█████████▏| 1155/1261 [1:04:35<05:53,  3.34s/it][A
     92%|█████████▏| 1156/1261 [1:04:39<05:50,  3.34s/it][A
     92%|█████████▏| 1157/1261 [1:04:42<05:47,  3.34s/it][A
     92%|█████████▏| 1158/1261 [1:04:45<05:44,  3.35s/it][A
     92%|█████████▏| 1159/1261 [1:04:49<05:41,  3.35s/it][A
     92%|█████████▏| 1160/1261 [1:04:52<05:39,  3.36s/it][A
     92%|█████████▏| 1161/1261 [1:04:56<05:36,  3.36s/it][A
     92%|█████████▏| 1162/1261 [1:04:59<05:33,  3.36s/it][A
     92%|█████████▏| 1163/1261 [1:05:02<05:28,  3.35s/it][A
     92%|█████████▏| 1164/1261 [1:05:06<05:24,  3.35s/it][A
     92%|█████████▏| 1165/1261 [1:05:09<05:22,  3.36s/it][A
     92%|█████████▏| 1166/1261 [1:05:12<05:19,  3.36s/it][A
     93%|█████████▎| 1167/1261 [1:05:16<05:15,  3.36s/it][A
     93%|█████████▎| 1168/1261 [1:05:19<05:10,  3.34s/it][A
     93%|█████████▎| 1169/1261 [1:05:22<05:07,  3.34s/it][A
     93%|█████████▎| 1170/1261 [1:05:26<05:05,  3.35s/it][A
     93%|█████████▎| 1171/1261 [1:05:29<05:01,  3.35s/it][A
     93%|█████████▎| 1172/1261 [1:05:32<04:57,  3.35s/it][A
     93%|█████████▎| 1173/1261 [1:05:36<04:54,  3.34s/it][A
     93%|█████████▎| 1174/1261 [1:05:39<04:51,  3.35s/it][A
     93%|█████████▎| 1175/1261 [1:05:42<04:48,  3.35s/it][A
     93%|█████████▎| 1176/1261 [1:05:46<04:45,  3.36s/it][A
     93%|█████████▎| 1177/1261 [1:05:49<04:40,  3.34s/it][A
     93%|█████████▎| 1178/1261 [1:05:52<04:37,  3.34s/it][A
     93%|█████████▎| 1179/1261 [1:05:56<04:34,  3.35s/it][A
     94%|█████████▎| 1180/1261 [1:05:59<04:30,  3.34s/it][A
     94%|█████████▎| 1181/1261 [1:06:02<04:27,  3.34s/it][A
     94%|█████████▎| 1182/1261 [1:06:06<04:23,  3.34s/it][A
     94%|█████████▍| 1183/1261 [1:06:09<04:20,  3.33s/it][A
     94%|█████████▍| 1184/1261 [1:06:12<04:16,  3.33s/it][A
     94%|█████████▍| 1185/1261 [1:06:16<04:14,  3.35s/it][A
     94%|█████████▍| 1186/1261 [1:06:19<04:11,  3.35s/it][A
     94%|█████████▍| 1187/1261 [1:06:23<04:08,  3.36s/it][A
     94%|█████████▍| 1188/1261 [1:06:26<04:05,  3.36s/it][A
     94%|█████████▍| 1189/1261 [1:06:29<04:01,  3.36s/it][A
     94%|█████████▍| 1190/1261 [1:06:33<03:59,  3.37s/it][A
     94%|█████████▍| 1191/1261 [1:06:36<03:56,  3.38s/it][A
     95%|█████████▍| 1192/1261 [1:06:39<03:53,  3.38s/it][A
     95%|█████████▍| 1193/1261 [1:06:43<03:49,  3.37s/it][A
     95%|█████████▍| 1194/1261 [1:06:46<03:45,  3.37s/it][A
     95%|█████████▍| 1195/1261 [1:06:50<03:42,  3.37s/it][A
     95%|█████████▍| 1196/1261 [1:06:53<03:39,  3.37s/it][A
     95%|█████████▍| 1197/1261 [1:06:56<03:35,  3.37s/it][A
     95%|█████████▌| 1198/1261 [1:07:00<03:32,  3.38s/it][A
     95%|█████████▌| 1199/1261 [1:07:03<03:28,  3.37s/it][A
     95%|█████████▌| 1200/1261 [1:07:06<03:25,  3.37s/it][A
     95%|█████████▌| 1201/1261 [1:07:10<03:21,  3.36s/it][A
     95%|█████████▌| 1202/1261 [1:07:13<03:18,  3.36s/it][A
     95%|█████████▌| 1203/1261 [1:07:16<03:14,  3.36s/it][A
     95%|█████████▌| 1204/1261 [1:07:20<03:11,  3.37s/it][A
     96%|█████████▌| 1205/1261 [1:07:23<03:07,  3.35s/it][A
     96%|█████████▌| 1206/1261 [1:07:27<03:05,  3.37s/it][A
     96%|█████████▌| 1207/1261 [1:07:30<03:02,  3.37s/it][A
     96%|█████████▌| 1208/1261 [1:07:33<02:58,  3.37s/it][A
     96%|█████████▌| 1209/1261 [1:07:37<02:54,  3.35s/it][A
     96%|█████████▌| 1210/1261 [1:07:40<02:51,  3.35s/it][A
     96%|█████████▌| 1211/1261 [1:07:43<02:47,  3.35s/it][A
     96%|█████████▌| 1212/1261 [1:07:47<02:44,  3.35s/it][A
     96%|█████████▌| 1213/1261 [1:07:50<02:40,  3.35s/it][A
     96%|█████████▋| 1214/1261 [1:07:53<02:37,  3.36s/it][A
     96%|█████████▋| 1215/1261 [1:07:57<02:34,  3.35s/it][A
     96%|█████████▋| 1216/1261 [1:08:00<02:31,  3.36s/it][A
     97%|█████████▋| 1217/1261 [1:08:04<02:28,  3.37s/it][A
     97%|█████████▋| 1218/1261 [1:08:07<02:24,  3.36s/it][A
     97%|█████████▋| 1219/1261 [1:08:10<02:20,  3.36s/it][A
     97%|█████████▋| 1220/1261 [1:08:14<02:17,  3.36s/it][A
     97%|█████████▋| 1221/1261 [1:08:17<02:14,  3.36s/it][A
     97%|█████████▋| 1222/1261 [1:08:20<02:10,  3.36s/it][A
     97%|█████████▋| 1223/1261 [1:08:24<02:07,  3.35s/it][A
     97%|█████████▋| 1224/1261 [1:08:27<02:03,  3.35s/it][A
     97%|█████████▋| 1225/1261 [1:08:30<02:00,  3.35s/it][A
     97%|█████████▋| 1226/1261 [1:08:34<01:56,  3.34s/it][A
     97%|█████████▋| 1227/1261 [1:08:37<01:53,  3.34s/it][A
     97%|█████████▋| 1228/1261 [1:08:40<01:50,  3.35s/it][A
     97%|█████████▋| 1229/1261 [1:08:44<01:47,  3.37s/it][A
     98%|█████████▊| 1230/1261 [1:08:47<01:44,  3.36s/it][A
     98%|█████████▊| 1231/1261 [1:08:51<01:41,  3.38s/it][A
     98%|█████████▊| 1232/1261 [1:08:54<01:38,  3.38s/it][A
     98%|█████████▊| 1233/1261 [1:08:57<01:34,  3.37s/it][A
     98%|█████████▊| 1234/1261 [1:09:01<01:30,  3.37s/it][A
     98%|█████████▊| 1235/1261 [1:09:04<01:27,  3.37s/it][A
     98%|█████████▊| 1236/1261 [1:09:07<01:24,  3.38s/it][A
     98%|█████████▊| 1237/1261 [1:09:11<01:20,  3.37s/it][A
     98%|█████████▊| 1238/1261 [1:09:14<01:17,  3.38s/it][A
     98%|█████████▊| 1239/1261 [1:09:18<01:14,  3.38s/it][A
     98%|█████████▊| 1240/1261 [1:09:21<01:11,  3.38s/it][A
     98%|█████████▊| 1241/1261 [1:09:24<01:07,  3.39s/it][A
     98%|█████████▊| 1242/1261 [1:09:28<01:04,  3.39s/it][A
     99%|█████████▊| 1243/1261 [1:09:31<01:00,  3.39s/it][A
     99%|█████████▊| 1244/1261 [1:09:34<00:57,  3.38s/it][A
     99%|█████████▊| 1245/1261 [1:09:38<00:54,  3.38s/it][A
     99%|█████████▉| 1246/1261 [1:09:41<00:50,  3.39s/it][A
     99%|█████████▉| 1247/1261 [1:09:45<00:47,  3.39s/it][A
     99%|█████████▉| 1248/1261 [1:09:48<00:43,  3.38s/it][A
     99%|█████████▉| 1249/1261 [1:09:51<00:40,  3.37s/it][A
     99%|█████████▉| 1250/1261 [1:09:55<00:37,  3.38s/it][A
     99%|█████████▉| 1251/1261 [1:09:58<00:33,  3.37s/it][A
     99%|█████████▉| 1252/1261 [1:10:01<00:30,  3.37s/it][A
     99%|█████████▉| 1253/1261 [1:10:05<00:26,  3.35s/it][A
     99%|█████████▉| 1254/1261 [1:10:08<00:23,  3.34s/it][A
    100%|█████████▉| 1255/1261 [1:10:11<00:19,  3.33s/it][A
    100%|█████████▉| 1256/1261 [1:10:15<00:16,  3.32s/it][A
    100%|█████████▉| 1257/1261 [1:10:18<00:13,  3.32s/it][A
    100%|█████████▉| 1258/1261 [1:10:21<00:09,  3.33s/it][A
    100%|█████████▉| 1259/1261 [1:10:25<00:06,  3.34s/it][A
    100%|█████████▉| 1260/1261 [1:10:28<00:03,  3.33s/it][A
    [A

    [MoviePy] Done.
    [MoviePy] >>>> Video ready: test_images/LDOOut.mp4 
    
    CPU times: user 1h 35min 50s, sys: 8.73 s, total: 1h 35min 59s
    Wall time: 1h 10min 29s


# Discussion

## 1. Briefly discuss any problems / issues you faced in your implementation of this project.  Where will your pipeline likely fail?  What could you do to make it more robust?


I have learned a lot in this project about object detection in images. 
The histogram of orientated gradients and spatial binning of features provides a reliable way of representing a car for later use in scanning an image. 

The colour representation, has a remarkable effect in the accuracy of classification. It was found that YCrCb performed better than the others. In the examples. the detection of white cars performed poorly This could perhaps be improved with experimenting with other reporesentations in addition to increasing the sample size of white cars.

The methods could be further improved to improve the accuracy of detection. I hope to improve on these methods by using kalman filters between scenes.
The approaches used in this script are in the form of computer vision and support vector machines. These could be further improved by means of the test accuracy by using deep learning methods convolutional neural network methods.
